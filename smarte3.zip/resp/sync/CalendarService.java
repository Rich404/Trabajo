/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yum.e3.server.development.apps.it.sync;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.tomcat.util.collections.MultiMap;
import yum.e3.server.generals.DBAccess;
import yum.e3.server.generals.utils.RESTWSClient;

/**
 *
 * @author richie
 */
public class CalendarService extends HttpServlet {
    
    public LinkedHashMap<String ,String > moMapMin ;
    public String msStoreSyncPath;    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(final HttpServletRequest request, final HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        moMapMin = fillHourLinkedMap();
        msStoreSyncPath = request.getRequestURL().toString().replace("CalendarService","StoreSyncServlet"); 
        Timer loTimer = new Timer("CheckTimer");
        try 
        {
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CalendarService</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet CalendarService at " + request.getContextPath() + "</h1>");
           
            TimerTask loRunTimerTask = new TimerTask() {

                @Override
                public void run() {
                    SimpleDateFormat lodateFormat = new SimpleDateFormat("EEE MMMM d HH:mm:ss z yyyy");
                    String [] loCurrentDate =  lodateFormat.format(new Date()).split(" ");
                    String [] loTime = loCurrentDate[3].split(":");
                    loCurrentDate[0] =  String.valueOf(getNumberDay(new Date()));
                    //System.out.println("Numero de D�a"+getNumberDay(new Date()));
                   // if(moMapMin.containsValue(loTime[1])==true)
                    //{
                        System.out.println("---- Execute Request "+loCurrentDate[3] +"----");
                        //System.out.println(loCurrentDate[3]+" Execute Request : "+moMapMin.containsValue(loTime[1]));
                        String [][] lsQueuesResult = getQueuesFromCurrentTime(new String[]{loCurrentDate[0],loTime[0],loTime[1]});
                        if (lsQueuesResult.length == 0) 
                        {
                            System.out.println("Current Date:"+ "Numero de d�a:"+loCurrentDate[0]+"--"+loCurrentDate[3] +"\n"+" * regreso vacio as 0, No hay nada para  Ejecutar * ");
                           
                        }
                        else
                        {
                            
                           ArrayList<ListsByQueue> loListsWithQueue = getListsFromQueues(lsQueuesResult, new String[]{loCurrentDate[0],loTime[0],loTime[1]});
                           ArrayList<StoresByList> loStoresWithList =  getStoresByList(new String[]{loCurrentDate[0],loTime[0],loTime[1]}, loListsWithQueue);
                           for (int i = 0; i < loStoresWithList.size(); i++) 
                           {
                               LinkedHashMap<String,String> lsLinkedParams = new LinkedHashMap<String, String>();
                               lsLinkedParams.put("SubmitType","Automatic");
                               lsLinkedParams.put("comboDemandCola",loStoresWithList.get(i).lsQueue);
                               lsLinkedParams.put("comboDemandList",loStoresWithList.get(i).lsList);
                               lsLinkedParams.put("currentTime",loCurrentDate[0]+":"+loTime[0]+":"+loTime[1]);
                               lsLinkedParams.put("Storeslength",String.valueOf(loStoresWithList.get(i).lsStores.length));
                               for (int j = 0; j < loStoresWithList.get(i).lsStores.length; j++) {
                                   lsLinkedParams.put("ST"+j, loStoresWithList.get(i).lsStores[j][0]);
                               }
                               
                               Thread loThreadSubmit =  new Thread(new InvokeStoreSync(lsLinkedParams, msStoreSyncPath),"CS"+i);
                               loThreadSubmit.start(); 
                               
                          }
                            
                           
                          
                        }
                        
                    //}
                    //else
                    //{
                      //  System.out.println("Current Date:"+ loCurrentDate[0]+"--"+loCurrentDate[3] );
                    //}
                    
                    
                };
            };
            loTimer.schedule(loRunTimerTask,0,60000);
          
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
           
        }
        
    }
    public  String cleanString(String lstexto) {
        lstexto = Normalizer.normalize(lstexto, Normalizer.Form.NFD);
        lstexto = lstexto.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
        return lstexto;
    }
    public int getNumberDay(Date loDate)
    {
        GregorianCalendar cal = new GregorianCalendar();
	cal.setTime(loDate);
	return cal.get(Calendar.DAY_OF_WEEK);
    }
    public  LinkedHashMap<String,String> fillHourLinkedMap()
    {
        LinkedHashMap<String ,String > loMapMinutes = new LinkedHashMap<String, String>();
        int jii =0;
        while (jii < 60)
        {
            if(String.valueOf(jii).length() < 2){loMapMinutes.put("M"+String.valueOf(jii),"0"+String.valueOf(jii));}else{loMapMinutes.put("M"+String.valueOf(jii),String.valueOf(jii));}
            jii = jii +5;
        }
        return loMapMinutes;
    }
    
    
    public String[][] getQueuesFromCurrentTime(String[] lsDateForExecute)
    {
        String [] lsQueues = null;
        DBAccess loRequest = new DBAccess("jdbc/masterStoreDBConnectionPool");
        String[][] loQueryResult = loRequest.queryToMatrix("SELECT DISTINCT queue_id FROM it_snc_execute_scheduled_submit WHERE submit_day = '"+lsDateForExecute[0] +"' and submit_hour ='"+lsDateForExecute[1]+"' and submit_minute='"+lsDateForExecute[2]+"';");
            /*for (int lii = 0; lii < loQueryResult.length; lii++) {
                lsQueues[lii] = loQueryResult[lii][0];
            }*/
        return loQueryResult;
    }
    public ArrayList<ListsByQueue> getListsFromQueues(String[][] lsQueues,String[] lsDateForExecute)
    {
        ArrayList<ListsByQueue> loQueueWithLists =  new ArrayList<ListsByQueue>();
        DBAccess loRequest = new DBAccess("jdbc/masterStoreDBConnectionPool");
        for (int i = 0; i < lsQueues.length; i++) {
            String[][] loQueryResult = loRequest.queryToMatrix("SELECT DISTINCT list_id FROM it_snc_execute_scheduled_submit WHERE submit_day = '"+lsDateForExecute[0] +"' AND submit_hour ='"+lsDateForExecute[1]+"' AND submit_minute='"+lsDateForExecute[2]+"' AND queue_id = '"+ lsQueues[i][0] +"';");
            ListsByQueue lotmoList = new ListsByQueue(lsQueues[i][0], loQueryResult);
            loQueueWithLists.add(lotmoList);
        }
        
        return loQueueWithLists;
    }
    public ArrayList<StoresByList> getStoresByList(String[] lsDateForExecute,ArrayList<ListsByQueue> loDistribList)
    {
        
        ArrayList<StoresByList> loStoresWithList = new ArrayList<StoresByList>();
        DBAccess loRequest = new DBAccess("jdbc/masterStoreDBConnectionPool");
        for (int j = 0; j < loDistribList.size(); j++) {
            for (int i = 0; i < loDistribList.get(j).loDistributionList.length; i++) {
                String[][] loQueryResult = loRequest.queryToMatrix("SELECT DISTINCT  store_id FROM it_snc_execute_scheduled_submit WHERE submit_day = '"+ lsDateForExecute[0] +"' AND submit_hour ='"+lsDateForExecute[1]+"' AND submit_minute='"+lsDateForExecute[2]+"' AND queue_id = '"+ loDistribList.get(j).getLoQueue() +"' AND list_id = "+ loDistribList.get(j).loDistributionList[i][0] +" ;");
                StoresByList loTmpStoresBylist = new StoresByList(loDistribList.get(j).loDistributionList[i][0],loQueryResult,loDistribList.get(j).getLoQueue());
                loStoresWithList.add(loTmpStoresBylist);
            }
        }
        return loStoresWithList;
    }
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
    public class  ListsByQueue
    {
        String loQueue;
        String [][] loDistributionList;
        public ListsByQueue(String loQueue,String [][] loDistributionList) {
            this.loQueue = loQueue;
            this.loDistributionList = loDistributionList;
        }
        public void viewData()
        {
            System.out.println("Cola:" + loQueue +" \nListas de distribici�n:" + loDistributionList.length);
            
            int i = 0; 
            while(i < loDistributionList.length)  
            {
                System.out.println(loDistributionList[i][0]);
                i++;
            }
            
        }

        public String getLoQueue() {
            return loQueue;
        }

        public void setLoQueue(String loQueue) {
            this.loQueue = loQueue;
        }

        public String[][] getLoDistributionList() {
            return loDistributionList;
        }

        public void setLoDistributionList(String[][] loDistributionList) {
            this.loDistributionList = loDistributionList;
        }
    }
    public class StoresByList
    {
        String lsList;
        String [][] lsStores;
        String lsQueue;
        
        public StoresByList(String lsList,String [][] lsStores,String loQueue) {
            this.lsList = lsList;
            this.lsStores = lsStores;
            this.lsQueue = loQueue;
            
        }
        public void viewData()
        {
            
            System.out.println("\n Cola: "+ lsQueue +"\nLista de Distribuci�n:" + lsList +" \n Stores:" + lsStores.length);
            
            int i = 0; 
            while(i < lsStores.length)  
            {
                System.out.println(lsStores[i][0]);
                i++;
            }
            
        }
        /*
        private String [] MatrixToVactor(String [][]lsMatrix)
        {
            String []lsVec = null;
            for (int lii = 0; lii < lsMatrix.length; lii++) {
               lsVec [lii] = lsMatrix[lii][0];
            }
            return lsVec;
        }*/
        
    }
    public class InvokeStoreSync extends  Thread
    {
        LinkedHashMap<String,String> lsLinkedParams;
        String lsHttpUrl;
        public InvokeStoreSync(LinkedHashMap<String,String> lsLinkedHashMap,String lsHttpUrl) {
            this.lsLinkedParams = lsLinkedHashMap;
            this.lsHttpUrl = lsHttpUrl;
        }
        
        @Override
        public void run() {
            RESTWSClient loRequest =  new RESTWSClient();
            //Cambiar la manera en la se enviara la solicitud, ya que LINKEDMAP de RESTWSClient solo recibe <String,String> y se necesita <String,String[]>
            String lsResultHttp = loRequest.sendHttpRequest("POST",msStoreSyncPath, lsLinkedParams,"");
            System.out.println(lsResultHttp);
            
        }
        
    }
    
    
}
