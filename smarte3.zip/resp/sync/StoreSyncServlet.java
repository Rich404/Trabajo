/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yum.e3.server.development.apps.it.sync;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.Document;
import static yum.e3.server.development.apps.it.sync.StoreSync.getValidNodeValue;
import yum.e3.server.generals.DBAccess;
import yum.e3.server.generals.utils.DataUtils;

/**
 *
 * @author richie
 */
public class StoreSyncServlet extends HttpServlet {
    
    public ArrayList<TaskCommandAtributes> moTCArray = new ArrayList<TaskCommandAtributes>();
    public String msDemandList ="";
    public String msDemandQueue ="";
    public String msTypeSubmit="";
    
    /**
     * Processes requests for both HTTP <code>GET /code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, Throwable {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        msDemandList = request.getParameter("comboDemandList");
        msDemandQueue =  request.getParameter("comboDemandCola");
        msTypeSubmit = request.getParameter("SubmitType");
        
        try {
            if (msTypeSubmit.equals("Manual")) {
                        /* TODO output your page here. You may use following sample code. */
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Servlet StoreSyncServlet</title>");            
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>Servlet StoreSyncServlet at " + request.getContextPath() +"</h1>");
                out.println("<h1> Metodo: "+ request.getMethod() +"</h1>");
                out.println("<h1> Lista: "+ msDemandList +"</h1>");
                out.println("<h1>  Cola: "+ msDemandQueue +"</h1>");
                out.println("<h1> Tipo: "+ msTypeSubmit +"</h1>");
                String [][] lsStores = getStoresFromDB(out, msDemandList);
                for(int lii=0;lii < moTCArray.size() ;lii ++)
                {
                    System.out.println(moTCArray.get(lii).getLsSource());
                }
                String [] lsIps = getIpsByStores(lsStores,out);


                Session loSession;
                Thread loThread = null ;
                out.println("* Establecer Conexion Remota *");
                for(int jii=0 ; jii < lsIps.length ; jii++)
                {
                   /*loSession =  establishSession(out,lsIps[jii], 22,"admin","admin");
                    try 
                    {
                        for (int i = 0; i < moTCArray.size(); i++) {
                            boolean c = executeCommand(loSession,moTCArray.get(i).getLsSource());
                            out.println("Retorno de Comando :" + c );
                        }

                    } 
                    catch (Exception e) 
                    {
                        System.out.println(e.toString());
                    }
                    endSession(loSession);*/

                     loThread = new Thread(new executeCommandsByStore(lsIps[jii],moTCArray,out,jii,msDemandQueue),"A"+jii);
                     loThread.start();
                }
               
                //establishSession(out, "192.168.110.233", 22,"phi1","pt8BybLSr");            
               /* loSession = establishSession(out,"192.168.110.233", 22, "admin","admin");
                try {
                                       //PathHostLocal //PathDestino 
                    boolean lbSendFileResult = sendFile(loSession,"/tmp/ls.txt","/tmp/ls.txt");
                    System.out.println("Proceso de Envio de Archivo: " + lbSendFileResult);
                    boolean lbReciveFile = receiveFile(loSession,"/tmp/ls.txt","/tmp/ls.txt");
                    System.out.println("Proceso de Recivo de Archivo: " + lbReciveFile);

                } catch (Exception e) {
                    System.out.println("Error al enviar: "+e.toString());
                }

                endSession(loSession);*/

                out.println("</body>");
                out.println("</html>");
                //System.out.println("FUE INVOCADO EL SERVLET ****************");
                moTCArray =  new ArrayList<TaskCommandAtributes>();
            }
            else if (msTypeSubmit.equals("Automatic")) 
            {
                out.println("<h1>Servlet StoreSyncServlet at " + request.getContextPath() +"</h1>");
                out.println("<h1> Metodo: "+ request.getMethod() +"</h1>");
                out.println("<h1> Lista: "+ msDemandList +"</h1>");
                out.println("<h1>  Cola: "+ msDemandQueue +"</h1>");
                out.println("<h1> Tipo: "+ msTypeSubmit +"</h1>");
                out.println("<h1> Time: "+request.getParameter("currentTime")+"</h1>");
                out.println("<h1> ArrayStores: "+ request.getParameter("Storeslength") +"</h1>");
                String [][] lsStores =  new String[Integer.parseInt(request.getParameter("Storeslength"))][1];
                Map loMap = request.getParameterMap();
                for (int i = 0; i < request.getParameterMap().size(); i++) {
                    if (loMap.containsKey("ST"+i)==true)
                    {
                        System.out.println("<h1>OKOK : "+request.getParameter("ST"+i)+"</h1>");
                        lsStores[i][0] = request.getParameter("ST"+i);
                    }
                }
                
                out.println("<h1> Tiendas: "+ lsStores.length+"</h1>");
                String[] lsips = getIpsByStores(lsStores, out);
                
                for (int i = 0; i < lsips.length; i++) {
                    ArrayList<TaskCommandAtributes> loCmdTask = getXCalendarXMLCommands(request.getParameter("currentTime").split(":"), request.getParameter("comboDemandCola"), request.getParameter("comboDemandList"),lsStores[i][0], out);
                    System.out.println(" -*- Ip: "+ lsips[i] + " -*- Comandos:" + loCmdTask.size());
                    
                    Thread loThread = new Thread(new executeCommandsByStore(lsips[i],loCmdTask,out,i,request.getParameter("comboDemandCola")),"C"+i);
                    loThread.start();
                }
            }
            else
            {}
            
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Throwable ex) {
            Logger.getLogger(StoreSyncServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (Throwable ex) {
            Logger.getLogger(StoreSyncServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
    public String[][] getStoresFromDB(PrintWriter out, String lsList)
    {
         DBAccess loRequest = new DBAccess("jdbc/masterStoreDBConnectionPool");
         String lsQuery = "SELECT  store_id FROM it_snc_distribution_list_store WHERE list_id = (SELECT list_id FROM it_snc_cat_distribution_list WHERE list_name = '"+ lsList +"');";
         String[][] loQueryResult = loRequest.queryToMatrix(lsQuery);
         out.print("<h1> * Tiendas *</h1>");
         System.out.println("<h1> * Tiendas *</h1>");
         for(int lii=0;lii<loQueryResult.length;lii++)
         {
             out.print("<p>"+ loQueryResult[lii][0]+"</p>");
             System.out.println(loQueryResult[lii][0]);
         }
         getXMLFromDB(out, loQueryResult, msDemandQueue);
         return loQueryResult;
    }
    public void getXMLFromDB(PrintWriter out,String[][] lsStores,String lsQueue)
    {
        DBAccess loRequest = new DBAccess("jdbc/masterStoreDBConnectionPool");
        String[][] loQueryResult = null;
       // for(int jii=0;jii < lsStores.length;jii++)
       // {
            String lsQuery = "SELECT command FROM it_snc_execute_submit WHERE store_id = "+ lsStores[0][0]+" AND queue_id = (SELECT queue_id FROM it_snc_cat_task_queue WHERE queue_desc = '"+ lsQueue +"') ORDER BY row_control ASC;";
            loQueryResult = loRequest.queryToMatrix(lsQuery);
            //out.print("<h1> * Comandos *</h1>");
            System.out.println("<h1> * Comandos *</h1>");
            for(int lii=0;lii<loQueryResult.length;lii++)
            {
                out.print("<p>"+ loQueryResult[lii][0]+"</p>");
                System.out.println(loQueryResult[lii][0]);
            }
        //}
        try {
            out.println("Comandos: "+ loQueryResult.length);//COMANDOS
            parseXML(loQueryResult);
        } catch (Exception e) {
            System.out.println("Error la Leer xml de comandos" +  e.toString());
        }
        
    }
    
    public  Document loadXMLFromString(String lsXML) throws Exception{
        DocumentBuilderFactory loDocumentFactory = DocumentBuilderFactory.newInstance();
        loDocumentFactory.setNamespaceAware(true);
        DocumentBuilder loDocumentBuilder = loDocumentFactory.newDocumentBuilder();
        return loDocumentBuilder.parse(new ByteArrayInputStream(lsXML.getBytes()));
    }
    
    public void parseXML(String[][] lsTaskCommand) throws Exception{
        for(int lii = 0 ; lii < lsTaskCommand.length ; lii++ )
        {
            Document moDOMData = loadXMLFromString(lsTaskCommand[lii][0]);
            if(moDOMData != null){
                Node loAttribute;
                Node loTreeOption;
                TaskCommandAtributes loTaskCommand;
                NamedNodeMap loAttributes;
                NodeList loTreeOptionChildren;

                NodeList loTreeOptions = moDOMData.getElementsByTagName("tree_option");
                for(int i = 0; i < loTreeOptions.getLength(); i++){
                    loTaskCommand = new TaskCommandAtributes();
                    loTreeOption = loTreeOptions.item(i);
                    loAttributes = loTreeOption.getAttributes();
                    for(int j = 0; j < loAttributes.getLength(); j++){
                        loAttribute = loAttributes.item(j);
                        if(loAttribute.getLocalName().contentEquals("tipo"))
                            loTaskCommand.lsType = loAttribute.getNodeValue();
                        if(loAttribute.getLocalName().contentEquals("option_id"))
                            loTaskCommand.lsOptionId = loAttribute.getNodeValue();
                        if(loAttribute.getLocalName().contentEquals("parent_id"))
                            loTaskCommand.lsParentId = loAttribute.getNodeValue();
                    }
                    loTreeOptionChildren = loTreeOption.getChildNodes();
                    loTaskCommand.lsSource = getValidNodeValue(loTreeOptionChildren.item(0).getFirstChild(),"");
                    loTaskCommand.lsDestination = getValidNodeValue(loTreeOptionChildren.item(1).getFirstChild(),"");
                    loTaskCommand.loExecuted = false;
                    moTCArray.add(loTaskCommand);
                }
            }
        }
    }
    public ArrayList<TaskCommandAtributes>  getXCalendarXMLCommands(String[] lsDateForExecute,String lsQueue,String lsList,String lsAnStore,PrintWriter out)
    {
        
        ArrayList<TaskCommandAtributes> loCmdTask = new ArrayList<TaskCommandAtributes>();
        DBAccess loRequest = new DBAccess("jdbc/masterStoreDBConnectionPool");
        String[][] loQueryResult = null;
       
           String lsQuery = "SELECT command FROM it_snc_execute_scheduled_submit WHERE submit_day = '"+ lsDateForExecute[0]+"' AND submit_hour ='"+lsDateForExecute[1]+"' AND submit_minute='"+lsDateForExecute[2]+"' AND queue_id = '"+ lsQueue +"' AND list_id = "+ lsList +" AND store_id = "+ lsAnStore+"   ORDER BY row_control ASC;";
           loQueryResult = loRequest.queryToMatrix(lsQuery);
            try {
            out.println("Comandos: "+ loQueryResult.length);//COMANDOS
            loCmdTask = parseCalendarXML(loQueryResult);
            } catch (Exception e) {
                System.out.println("Error la Leer xml de comandos" +  e.toString());
            }
            return loCmdTask;
    }
    public ArrayList<TaskCommandAtributes>  parseCalendarXML(String[][] lsTaskCommand) throws Exception{
        ArrayList<TaskCommandAtributes> loCmdTask = new ArrayList<TaskCommandAtributes>();
        for(int lii = 0 ; lii < lsTaskCommand.length ; lii++ )
        {
            Document moDOMData = loadXMLFromString(lsTaskCommand[lii][0]);
            if(moDOMData != null){
                Node loAttribute;
                Node loTreeOption;
                TaskCommandAtributes loTaskCommand;
                NamedNodeMap loAttributes;
                NodeList loTreeOptionChildren;

                NodeList loTreeOptions = moDOMData.getElementsByTagName("tree_option");
                for(int i = 0; i < loTreeOptions.getLength(); i++){
                    loTaskCommand = new TaskCommandAtributes();
                    loTreeOption = loTreeOptions.item(i);
                    loAttributes = loTreeOption.getAttributes();
                    for(int j = 0; j < loAttributes.getLength(); j++){
                        loAttribute = loAttributes.item(j);
                        if(loAttribute.getLocalName().contentEquals("tipo"))
                            loTaskCommand.lsType = loAttribute.getNodeValue();
                        if(loAttribute.getLocalName().contentEquals("option_id"))
                            loTaskCommand.lsOptionId = loAttribute.getNodeValue();
                        if(loAttribute.getLocalName().contentEquals("parent_id"))
                            loTaskCommand.lsParentId = loAttribute.getNodeValue();
                    }
                    loTreeOptionChildren = loTreeOption.getChildNodes();
                    loTaskCommand.lsSource = getValidNodeValue(loTreeOptionChildren.item(0).getFirstChild(),"");
                    loTaskCommand.lsDestination = getValidNodeValue(loTreeOptionChildren.item(1).getFirstChild(),"");
                    loTaskCommand.loExecuted = false;
                    loCmdTask.add(loTaskCommand);
                }
            }
        }
        return loCmdTask;
    }
    /*public Session establishSession(PrintWriter out, String lsHostname,int liPort, String lsUsername, String lsPassword){
        Session loSession = null;
        try{
            System.out.println("ESTABLECIENDO SESION.. IP: "+ lsHostname);
            JSch loJSch = new JSch();
            loSession = loJSch.getSession(lsUsername, lsHostname, liPort);
            loSession.setPassword(lsPassword);update it_snc_execute_scheduled_submit set
submit_day = 'jue', submit_hour ='14' , submit_minute='35';

            Properties loConfig = new Properties();
            loConfig.put("StrictHostKeyChecking", "no");
            loSession.setConfig(loConfig);
            loSession.connect();
            System.out.println("\nSesi�n establecida\n");
            out.println("\nSesi�n establecida\n");
            
        }
        catch(Exception ex){
            System.err.println("Error al establecer la conexion " + ex);
            out.println("Error al establecer la conexion " + ex);
        }
        finally{
            return loSession;
        }
    }*/
     /* public boolean executeCommand(Session loSession,String lsCommand) throws IOException, JSchException
      {
        String lsError = "";
        String lsResult = "";
        System.out.println("*** Comando: " + lsCommand);
        Channel loChannel = null;
        ChannelExec loChannelExec = null;
        try{
           
            loChannel = loSession.openChannel("exec"); //Abre un canal, de tipo ejecutable, en la sesion
            loChannelExec = (ChannelExec)loChannel;
            loChannelExec.setInputStream(null);
            loChannelExec.setCommand(lsCommand);
            loChannelExec.setErrStream(System.err); //Dirige el canal de salida de errores de la tarminal en la sesion remota a canal de System.err
            InputStream loInput = loChannel.getInputStream();
            InputStream loErrorStream = loChannelExec.getErrStream();
             //En el momento de hacer la coneccion, el comando se ejecuta de forma autom�tica.
            loChannelExec.connect();
            
            InputStreamReader inputReader = new InputStreamReader(loInput);
            BufferedReader bufferedReader = new BufferedReader(inputReader);
                String line = null;
                System.out.println("* Salida de comando: * ");
                while((line = bufferedReader.readLine()) != null){
                    System.out.println(line);
                    lsResult += lsResult + line + "\n";  
                }
                
            InputStreamReader inputReaderError = new InputStreamReader(loErrorStream);
            BufferedReader bufferedReaderError = new BufferedReader(inputReaderError);
                String lineError = null;
                System.out.println("* Salida de Error de Comando: * "); 
                while((lineError = bufferedReaderError.readLine()) != null){
                    System.out.println(lineError);
                     lsError += lsError + lineError + "\n";  
                }
            
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        finally{
            loChannel.disconnect();
            loChannelExec.disconnect();
            if(lsError.contentEquals("")) //De no haber errores, devuelve 
                return true;
            else{
                //lsResult.append(lsError);
                return false;
            }
        }
    }*/
       //Termina la Session que reciba en caso de estar abierta
   /* public  void endSession(Session loSession){
        try{
        if(loSession.isConnected())
            loSession.disconnect();
        }
        catch(NullPointerException nullEx){
            
        }
    } */
    public String [] getIpsByStores(String [][] lsStores,PrintWriter out)
    {
    
        String [] lsIps = new String[lsStores.length];
        DBAccess loRequest = new DBAccess("jdbc/masterStoreDBConnectionPool");
        for(int jii=0;jii < lsStores.length;jii++)
        {
            String lsQuery = "SELECT  ip FROM public.it_grl_v3_store_control WHERE store_id = '"+  lsStores[jii][0] +"';";
            String [][] loQueryResult = loRequest.queryToMatrix(lsQuery);
            //out.print("<h1> * Comandos *</h1>");
            //System.out.println("<h1> * Ip *</h1>");
            for(int lii=0;lii<loQueryResult.length;lii++)
            {
                out.print("<p>"+ loQueryResult[lii][0]+"</p>");
                //System.out.println(loQueryResult[lii][0]);
                lsIps [jii] = loQueryResult[lii][0];
            }
            
            
            
        }
        
       
        
      return lsIps;
    }
    /*public static String getChecksum (String loDir){
        try{
            FileInputStream loCheckFile = new FileInputStream(loDir);
            MessageDigest loMD5 = MessageDigest.getInstance("MD5");
            byte[] loCheckBytes = new byte[1024];
            int liNumRead = 0;
            while ((liNumRead = loCheckFile.read(loCheckBytes)) != -1)
                loMD5.update(loCheckBytes, 0, liNumRead);
            byte[] loMD5Bytes = loMD5.digest();
            StringBuffer loStrinfBuffer = new StringBuffer();
            for (int i = 0; i < loMD5Bytes.length; i++)
                loStrinfBuffer.append(Integer.toString((loMD5Bytes[i] & 0xff) + 0x100, 16).substring(1));
            return loStrinfBuffer.toString();
        } catch(IOException ex){
            return(ex+"");
        } catch (NoSuchAlgorithmException ex) {
            return(ex+"");
        }
    }
    public boolean compareChecksum(String lsOriginSUM,String lsPathDestinationFile)
    {
        boolean lbResultSum = false;
       String lsResult = getChecksum(lsPathDestinationFile);
        //System.out.println("Sum Destino: "+ lsResult);
        if (lsResult.equals(lsOriginSUM)) 
        {
            lbResultSum = true;
        } 
        else 
        {
            lbResultSum = false;
        }
        return lbResultSum; 
    }*/
    /*public boolean  sendFile(Session loSession, String lsFileToTransfer, String lsDestination) throws IOException, JSchException{
        boolean lbResult = false;
        System.out.println("* Enviando Archivo *");
        //Se obtiene el checksum del archivo antes de ser enviado
        String lsMD5sum = getChecksum(lsFileToTransfer);
        //checkSession(loSession);
        Channel loChannel = null;
        ChannelSftp loChannelSftp = null;
        //String lsFileName="";
        //System.out.println("Sum Origen: "+ lsMD5sum);
        try{
            loChannel = loSession.openChannel("sftp"); //Se abre un canal de tipo SecureFileTransferProtocol
            loChannel.connect();
            loChannelSftp = (ChannelSftp) loChannel;
            //msWorkingDir es el directorio sobre el cual se va a trabajar y donde llegar� el erchvio
            //loChannelSftp.cd(msWorkingDir);
            
            File loFile = new File(lsFileToTransfer);
            //lsFileName = loFile.getName();
            loChannelSftp.put(new FileInputStream(loFile), lsDestination);
            System.out.println("Host : "+ loSession.getHost() +" Se ha generado el archivo: "+ loFile.getAbsolutePath() + " Resultado Sum: "+ compareChecksum(lsMD5sum, loFile.getAbsolutePath()) );
            lbResult = true;
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        finally{
            //Se obtiene el checksum del archivo despues de ser enviado para 
            //para confirmar que el envio se realizo correctamente
            loChannelSftp.disconnect();
           
        }
        return lbResult;
    }
    public boolean receiveFile(Session loSession, String lsFileToGet, String lsNewFile) throws IOException, JSchException
    {
        //Ejecuta un checksum sobre el archivo en la sesion remota antes de traerlo
        boolean lbResult = false;
        System.out.println("* Recibiendo Archivo *");
        Channel loChannel = null;
        ChannelSftp loChannelSftp = null;
        
       
        try{
            loChannel = loSession.openChannel("sftp"); //Se abre un canal de tipo SecureFileTransferProtocol
            loChannel.connect();
            loChannelSftp = (ChannelSftp) loChannel;
            loChannelSftp.cd("/tmp/");
                
            InputStream loChanelInStream = loChannelSftp.get(lsFileToGet);
            String lsOriginSum =  getCheckSumFromInputStream(loChanelInStream);
            byte[] loBuffer = new byte[1024];
            BufferedInputStream loBInput = new BufferedInputStream(loChannelSftp.get(lsFileToGet));
            File loNewFile = new File(lsNewFile);
            OutputStream loOutput = new FileOutputStream(loNewFile);
            BufferedOutputStream loBOutput = new BufferedOutputStream(loOutput);
            int liReadCount;
            while((liReadCount = loBInput.read(loBuffer)) > 0)
                loBOutput.write(loBuffer, 0, liReadCount);
            loBInput.close();
            loBOutput.close();
            System.out.println("Host : "+ loSession.getHost() +" Se ha generado el archivo: "+ loNewFile.getAbsolutePath() + " Resultado Sum :  "+ compareChecksum(lsOriginSum,loNewFile.getAbsolutePath()));
            lbResult = true;
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        finally{
            //Despues de traer el archivo, le saca el chechsum a la copia local 
            //para comprobar que el archivo no sufrio perdidas en la transmision
            loChannelSftp.disconnect();
            //return lsMD5sum.toString().replace("\n", "").contentEquals(getChecksum(lsNewFile));
        }
        return lbResult;
    }*/
   /* public  String getCheckSumFromInputStream (InputStream loCheckFile){
        try{
            
            MessageDigest loMD5 = MessageDigest.getInstance("MD5");
            byte[] loCheckBytes = new byte[1024];
            int liNumRead = 0;
            while ((liNumRead = loCheckFile.read(loCheckBytes)) != -1)
                loMD5.update(loCheckBytes, 0, liNumRead);
            byte[] loMD5Bytes = loMD5.digest();
            StringBuffer loStrinfBuffer = new StringBuffer();
            for (int i = 0; i < loMD5Bytes.length; i++)
                loStrinfBuffer.append(Integer.toString((loMD5Bytes[i] & 0xff) + 0x100, 16).substring(1));
            return loStrinfBuffer.toString();
        } catch(IOException ex){
            return(ex+"");
        } catch (NoSuchAlgorithmException ex) {
            return(ex+"");
        }
    }*/
    
    public  class TaskCommandAtributes{
        public String lsOptionId;
        public String lsType;
        public String lsParentId;
        public String lsSource;
        public String lsDestination;
        public String lsError;
        

        public String getLsOptionId() {
            return lsOptionId;
        }

        public String getLsType() {
            return lsType;
        }

        public String getLsParentId() {
            return lsParentId;
        }

        public String getLsSource() {
            return lsSource;
        }

        public String getLsDestination() {
            return lsDestination;
        }

        public boolean isLoExecuted() {
            return loExecuted;
        }
        public boolean loExecuted;
        
        public void setError(String lsCmdError)
        {
            lsError = lsCmdError;
        }
        public String getError ()
        {
            
            return lsError;
        }
        TaskCommandAtributes(){
        }
    }
    
    public class executeCommandsByStore extends  Thread
    {
      
        String lmStore,lmQueue;
        PrintWriter mout;
        ArrayList<TaskCommandAtributes> moTaskCommands;
        ArrayList<Log> moLog =  new  ArrayList<Log>();
        int moStorecount;
        DBAccess moDBAccess = new DBAccess("jdbc/masterStoreDBConnectionPool");
        
        
        public executeCommandsByStore(String lsStore,ArrayList<TaskCommandAtributes> loTCArray,PrintWriter lout,int loStoreCount,String lsQueue) {
            lmStore = lsStore;
            moTaskCommands = loTCArray;
            mout = lout;
            moStorecount = loStoreCount;
            lmQueue = lsQueue;
        }
        
        @Override
        public  void run ()
        {
            Log loLog =  new Log();
            System.out.println("*IP * : " + lmStore);
            System.out.println("* Comandos a Ejecutar * ");
            //System.out.println(moTaskCommands.size());
            Session loSession;
            Date loDate =  new Date();
            double lornd = Math.random();
            loLog.setMsHost(lmStore);
            loLog.setMotimestamp(loDate);
            loLog.setMornd(lornd);
           
            
            
            String lsErrorParent = "";
            for (int lii = 0; lii < moTaskCommands.size(); lii++) 
            {
               
                  lsErrorParent = findParentError(moTaskCommands.get(lii).getLsParentId());
                  if (!lsErrorParent.equals("")) 
                  {
                      moTaskCommands.get(lii).setError("Error Parent");
                       moDBAccess.executeSQLCommand("INSERT INTO  it_snc_execute_log VALUES (?,?,?,?,?,?)", new String[] {loLog.getMsHost(),String.valueOf(loLog.getMotimestamp().getTime()),moTaskCommands.get(lii).getLsType(),moTaskCommands.get(lii).getLsSource(),"Error in parent command" ,"Error in parent command"});
                             if(!moDBAccess.hasError()){
                                System.out.println("* Exito el Ejecutar Insert Into *"); 

                               }else{
                                   System.out.println("* Error el Ejecutar Insert Into *");  
                               } 
                  }
                  else
                  {
                        if (moTaskCommands.get(lii).getLsType().equals("local_cmd")) 
                        {
                            System.out.println("CMD Local: " + moTaskCommands.get(lii).getLsSource());
                            loLog.setMoType("local_cmd");
                            loLog.setMocmd(moTaskCommands.get(lii).getLsSource());
                            Session loLocalSession = null;
                            try 
                            {

                                InetAddress loInetAddress =  InetAddress.getLocalHost();
                                loLocalSession = establishSession(mout,loInetAddress.getHostAddress(), 22,"admin","admin");
                                System.out.println("ESTADO DE LA CONEXION: "+loLocalSession.isConnected());
                                if (loLocalSession.isConnected()==true) 
                                {
                                    
                                    String [][] lsFullOut  = executeCommand(loLocalSession,moTaskCommands.get(lii).getLsSource());
                                    loLog.setMoOutput(lsFullOut[0][0]);
                                    loLog.setMoError(lsFullOut[0][1]);
                                    moTaskCommands.get(lii).setError(lsFullOut[0][1]);
                                
                                } 
                                else 
                                {
                                    
                                    loLog.setMoOutput("Error al conectar al host ");
                                    loLog.setMoError("Error al conectar al host ");
                                    moTaskCommands.get(lii).setError("Error al conectar al host ");

                                }
                               
                               
                            } 
                            catch (Exception e) 
                            {
                                System.out.println(e.toString());
                            }
                            endSession(loLocalSession);

                        }
                        else if (moTaskCommands.get(lii).getLsType().equals("cmd"))
                        {
                            loLog.setMoType("cmd");
                            loLog.setMocmd(moTaskCommands.get(lii).getLsSource());
                            System.out.println("CMD Remoto: " + moTaskCommands.get(lii).getLsSource());
                            loSession = establishSession(mout,lmStore, 22,"admin","admin");
                            System.out.println("ESTADO DE LA CONEXION: "+loSession.isConnected());
                            try 
                            {   
                                if(loSession.isConnected()==true)
                                {
                                    String [][] lsFullOut = executeCommand(loSession,moTaskCommands.get(lii).getLsSource());
                                    loLog.setMoOutput(lsFullOut[0][0]);
                                    loLog.setMoError(lsFullOut[0][1].replace("'", "").replace("`", ""));
                                    moTaskCommands.get(lii).setError(lsFullOut[0][1].replace("'", "").replace("`", ""));
                                        
                                } 
                                else 
                                {
                                    
                                    loLog.setMoOutput("Error al conectar al host ");
                                    loLog.setMoError("Error al conectar al host ");
                                    moTaskCommands.get(lii).setError("Error al conectar al host ");

                                }
                                    

                            } 
                            catch (Exception e) 
                            {
                                System.out.println(e.toString());
                            }
                            endSession(loSession);
                        }
                        else if(moTaskCommands.get(lii).getLsType().equals("receive"))
                        {
                            loLog.setMoType("recive");
                            loLog.setMocmd(moTaskCommands.get(lii).getLsSource()+"  "+moTaskCommands.get(lii).getLsDestination());
                            System.out.println("Recibir Archivo : " + moTaskCommands.get(lii).getLsSource() +" " );
                            loSession = establishSession(mout,lmStore, 22, "admin","admin");
                            System.out.println("ESTADO DE LA CONEXION: "+loSession.isConnected());
                            try {

                                if(loSession.isConnected()==true)
                                {
                                boolean[] lbReciveFile = receiveFile(loSession,moTaskCommands.get(lii).getLsSource(),moTaskCommands.get(lii).getLsDestination());
                                System.out.println("Proceso de Recivo de Archivo: " + lbReciveFile[0]);
                                loLog.setMoOutput(" Process of receive : "+String.valueOf(lbReciveFile[0])+  " Result Of Cheksum: "+String.valueOf(lbReciveFile[1]));
                                loLog.setMoError("----");
                                moTaskCommands.get(lii).setError(String.valueOf(lbReciveFile[0]).replace("true",""));
                                } 
                                else 
                                {
                                    
                                    loLog.setMoOutput("Error al conectar al host ");
                                    loLog.setMoError("Error al conectar al host ");
                                    moTaskCommands.get(lii).setError("Error al conectar al host ");

                                }
                                
                              

                            } catch (Exception e) {
                                System.out.println("Error al enviar: "+e.toString());
                            }

                            endSession(loSession);
                        }
                        else if(moTaskCommands.get(lii).getLsType().equals("send"))
                        {
                             loLog.setMoType("send");
                             loLog.setMocmd(moTaskCommands.get(lii).getLsSource()+"  "+moTaskCommands.get(lii).getLsDestination());
                             System.out.println("Enviar Archivo: " + moTaskCommands.get(lii).getLsSource());
                             loSession = establishSession(mout,lmStore, 22, "admin","admin");
                             System.out.println("ESTADO DE LA CONEXION: "+loSession.isConnected());
                                try {
                                    if(loSession.isConnected()==true)
                                    {                                                 //PathHostLocal //PathDestino 
                                    boolean [] lbSendFileResult = sendFile2(loSession,moTaskCommands.get(lii).getLsSource().trim(),moTaskCommands.get(lii).getLsDestination().trim());
                                    System.out.println("Proceso de Envio de Archivo: " + lbSendFileResult[0]);
                                    loLog.setMoOutput(" Process of Send: " + String.valueOf(lbSendFileResult[0]) + " Result Of Cheksum: "+String.valueOf(lbSendFileResult[1])  );
                                    loLog.setMoError("----");
                                    moTaskCommands.get(lii).setError(String.valueOf(lbSendFileResult[0]).replace("true",""));
                                
                                    } 
                                    else 
                                    {

                                        loLog.setMoOutput("Error al conectar al host ");
                                        loLog.setMoError("Error al conectar al host ");
                                        moTaskCommands.get(lii).setError("Error al conectar al host ");

                                    }    
                                    

                                } catch (Exception e) {
                                    System.out.println("Error al enviar: "+e.toString());
                                }

                                endSession(loSession);    
                        }
                
                        System.out.println(loLog.getLine());
                         moDBAccess.executeSQLCommand("INSERT INTO  it_snc_execute_log VALUES (?,?,?,?,?,?)", new String[] {loLog.getMsHost(),String.valueOf(loLog.getMotimestamp().getTime()),loLog.getMoType(), loLog.getMocmd(),loLog.getMoOutput(),loLog.getMoError()});
                         if(!moDBAccess.hasError()){
                             System.out.println("* Exito el Ejecutar Insert Into *"); 

                            }else{
                                System.out.println("* Error el Ejecutar Insert Into *");  
                            }
                
                  }     
                        
                moDBAccess.executeSQLCommand("DELETE FROM it_snc_execute_submit WHERE option_id = '"+ moTaskCommands.get(lii).getLsOptionId() +"' AND queue_id = (SELECT queue_id FROM it_snc_cat_task_queue WHERE queue_desc = '"+ msDemandQueue +"');");
                         if(!moDBAccess.hasError()){
                             System.out.println("* Exito el Ejecutar Insert Into *"); 

                            }else{
                                System.out.println("* Error el Ejecutar Insert Into *");  
                            }  
            }
            stop();
        lmStore =null ;lmQueue=null;
        mout = null;
        moTaskCommands = new ArrayList<TaskCommandAtributes>();
        ArrayList<Log> moLog =  new  ArrayList<Log>();
        moStorecount = 0;
        moDBAccess = new DBAccess("jdbc/masterStoreDBConnectionPool");
        
        }
        public String findParentError(String lsParent)
        {
            String hasError = "";
            for  (int i = 0; i < moTaskCommands.size(); i++) {
                    
                    if(moTaskCommands.get(i).getLsOptionId().equals(lsParent))
                    {
                        hasError = moTaskCommands.get(i).getError();
                    }
                }
            return hasError;
        }
        public String [][] executeCommand(Session loSession,String lsCommand) throws IOException, JSchException
        {
          //String [0][0] = OutPut String [0][1] = Error
          String lsFullOutPut [][] =  new String[1][2];
          StringBuilder lsResult= new StringBuilder();
          StringBuilder lsError= new StringBuilder() ;
          System.out.println("*** Comando: " + lsCommand);
          Channel loChannel = null;
          ChannelExec loChannelExec = null;
          try{

              loChannel = loSession.openChannel("exec"); //Abre un canal, de tipo ejecutable, en la sesion
              loChannelExec = (ChannelExec)loChannel;
              loChannelExec.setInputStream(null);
              loChannelExec.setCommand(lsCommand);
              loChannelExec.setErrStream(System.err); //Dirige el canal de salida de errores de la tarminal en la sesion remota a canal de System.err
              InputStream loInput = loChannel.getInputStream();
              InputStream loErrorStream = loChannelExec.getErrStream();
               //En el momento de hacer la coneccion, el comando se ejecuta de forma autom�tica.
              loChannelExec.connect();

              InputStreamReader inputReader = new InputStreamReader(loInput);
              BufferedReader bufferedReader = new BufferedReader(inputReader);
                  String line = null;
                  System.out.println("* Salida de comando: * ");
                  while((line = bufferedReader.readLine()) != null){
                      //System.out.println(line);
                      lsResult.append(line);   
                      
                  }
                  lsFullOutPut[0][0] = lsResult.toString();
              InputStreamReader inputReaderError = new InputStreamReader(loErrorStream);
              BufferedReader bufferedReaderError = new BufferedReader(inputReaderError);
                  String lineError = null;
                  System.out.println("* Salida de Error de Comando: * "); 
                  while((lineError = bufferedReaderError.readLine()) != null){
                      //System.out.println(lineError);
                      lsError.append(lineError);
                  }
                  lsFullOutPut[0][1] = lsError.toString(); 
          }
          catch(Exception ex){
              ex.printStackTrace();
          }
          finally{
              loChannel.disconnect();
              loChannelExec.disconnect();
              return lsFullOutPut;
          }
      }
      public Session establishSession(PrintWriter out, String lsHostname,int liPort, String lsUsername, String lsPassword)
      {
        Session loSession = null;
        try{
            System.out.println("ESTABLECIENDO SESION.. IP: "+ lsHostname);
            JSch loJSch = new JSch();
            loSession = loJSch.getSession(lsUsername, lsHostname, liPort);
            loSession.setPassword(lsPassword);
            Properties loConfig = new Properties();
            loConfig.put("StrictHostKeyChecking", "no");
            loSession.setConfig(loConfig);
            loSession.connect();
            System.out.println("\nSesi�n establecida\n");
            out.println("\nSesi�n establecida\n");
            
        }
        catch(Exception ex){
            System.err.println("Error al establecer la conexion " + ex);
            out.println("Error al establecer la conexion " + ex);
        }
        finally{
            return loSession;
        }
      }
      public  void endSession(Session loSession)
      {
            try{
            if(loSession.isConnected())
                loSession.disconnect();
            }
            catch(NullPointerException nullEx){

            }
       }
      public  String getChecksum (String loDir)
      {
        try{
            FileInputStream loCheckFile = new FileInputStream(loDir);
            MessageDigest loMD5 = MessageDigest.getInstance("MD5");
            byte[] loCheckBytes = new byte[1024];
            int liNumRead = 0;
            while ((liNumRead = loCheckFile.read(loCheckBytes)) != -1)
                loMD5.update(loCheckBytes, 0, liNumRead);
            byte[] loMD5Bytes = loMD5.digest();
            StringBuffer loStrinfBuffer = new StringBuffer();
            for (int i = 0; i < loMD5Bytes.length; i++)
                loStrinfBuffer.append(Integer.toString((loMD5Bytes[i] & 0xff) + 0x100, 16).substring(1));
            return loStrinfBuffer.toString();
        } catch(IOException ex){
            return(ex+"");
        } catch (NoSuchAlgorithmException ex) {
            return(ex+"");
        }
    }
    public boolean compareChecksum(String lsOriginSUM,String lsPathDestinationFile)
    {
        boolean lbResultSum = false;
       String lsResult = lsPathDestinationFile;
        //System.out.println("Sum Destino: "+ lsResult);
        if (lsResult.equals(lsOriginSUM)) 
        {
            lbResultSum = true;
        } 
        else 
        {
            lbResultSum = false;
        }
        return lbResultSum; 
    }
    public  String getCheckSumFromInputStream (InputStream loCheckFile)
      {
        try{
            
            MessageDigest loMD5 = MessageDigest.getInstance("MD5");
            byte[] loCheckBytes = new byte[1024];
            int liNumRead = 0;
            while ((liNumRead = loCheckFile.read(loCheckBytes)) != -1)
                loMD5.update(loCheckBytes, 0, liNumRead);
            byte[] loMD5Bytes = loMD5.digest();
            StringBuffer loStrinfBuffer = new StringBuffer();
            for (int i = 0; i < loMD5Bytes.length; i++)
                loStrinfBuffer.append(Integer.toString((loMD5Bytes[i] & 0xff) + 0x100, 16).substring(1));
            return loStrinfBuffer.toString();
        } catch(IOException ex){
            return(ex+"");
        } catch (NoSuchAlgorithmException ex) {
            return(ex+"");
        }
      }
   /* Metodo con Errores public boolean[]  sendFile(Session loSession, String lsFileToTransfer, String lsDestination) throws IOException, JSchException{
        boolean [] lbResult = new boolean[2];
        lbResult[0] = false;
        lbResult[1] = false;
        System.out.println("* Enviando Archivo *");
        //Se obtiene el checksum del archivo antes de ser enviado
        String lsMD5sum = getChecksum(lsFileToTransfer);
        //checkSession(loSession);
        Channel loChannel = null;
        ChannelSftp loChannelSftp = null;
        //String lsFileName="";
        //System.out.println("Sum Origen: "+ lsMD5sum);
        try{
            loChannel = loSession.openChannel("sftp"); //Se abre un canal de tipo SecureFileTransferProtocol
            loChannel.connect();
            loChannelSftp = (ChannelSftp) loChannel;
            //msWorkingDir es el directorio sobre el cual se va a trabajar y donde llegar� el erchvio
            //loChannelSftp.cd(msWorkingDir);
            InputStream loChanelInStream = loChannelSftp.get(lsDestination);
            String lsDestSum =  getCheckSumFromInputStream(loChanelInStream);
            File loFile = new File(lsFileToTransfer);
            //lsFileName = loFile.getName();
            loChannelSftp.put(new FileInputStream(loFile), lsDestination);
            System.out.println("Host : "+ loSession.getHost() +" Se ha generado el archivo: "+ loFile.getAbsolutePath() + " Resultado Sum: "+ compareChecksum(lsMD5sum, lsDestSum) );
            lbResult[0] = true;
            lbResult[1] = compareChecksum(lsMD5sum, lsDestSum);
            //System.out.println(lsMD5sum + "  " + lsDestSum);
        }
        catch(Exception ex){
            ex.printStackTrace();
             lbResult[0] = false;
        }
        finally{
            //Se obtiene el checksum del archivo despues de ser enviado para 
            //para confirmar que el envio se realizo correctamente
            loChannelSftp.disconnect();
             
        }
        return lbResult;
       
    } */
    public boolean[] sendFile2(Session loSession, String lsFileToTransfer, String lsDestination) throws IOException, JSchException{
        //Se obtiene el checksum del archivo antes de ser enviado
         boolean [] lbResult = new boolean[2];
        lbResult[0] = false;
        lbResult[1] = false;
        System.out.println("* Enviando Archivo *");
        String lsMD5sum = getChecksum(lsFileToTransfer);
        //checkSession(loSession);
        Channel loChannel = null;
        ChannelSftp loChannelSftp = null;
        //String lsFileName="";
        
        try{
            loChannel = loSession.openChannel("sftp"); //Se abre un canal de tipo SecureFileTransferProtocol
            loChannel.connect();
            loChannelSftp = (ChannelSftp) loChannel;
            //msWorkingDir es el directorio sobre el cual se va a trabajar y donde llegar� el erchvio
            //loChannelSftp.cd(msWorkingDir);
            
            File loFile = new File(lsFileToTransfer);
            //lsFileName = loFile.getName();
            loChannelSftp.put(new FileInputStream(loFile), lsDestination);
            InputStream loChanelInStream = loChannelSftp.get(lsDestination);
            String lsDestSum =  getCheckSumFromInputStream(loChanelInStream);
            System.out.println("Host : "+ loSession.getHost() +" Se ha generado el archivo: "+ loFile.getAbsolutePath() + " Resultado Sum: "+ compareChecksum(lsMD5sum, lsDestSum) );
            lbResult[0] = true;
            lbResult[1] = compareChecksum(lsMD5sum, lsDestSum);
        }
        catch(Exception ex){
            ex.printStackTrace();
             lbResult[0] = false;
        }
        finally{
            //Se obtiene el checksum del archivo despues de ser enviado para 
            //para confirmar que el envio se realizo correctamente
            loChannelSftp.disconnect();
           return lbResult ;
        }
    }
    public boolean[] receiveFile(Session loSession, String lsFileToGet, String lsNewFile) throws IOException, JSchException
    {
        boolean [] lbResult = new boolean[2];
        lbResult[0] = false;
        lbResult[1] = false;
        System.out.println("* Recibiendo Archivo *");
        Channel loChannel = null;
        ChannelSftp loChannelSftp = null;
        
       
        try{
            loChannel = loSession.openChannel("sftp"); //Se abre un canal de tipo SecureFileTransferProtocol
            loChannel.connect();
            loChannelSftp = (ChannelSftp) loChannel;
            loChannelSftp.cd("/tmp/");
                
            InputStream loChanelInStream = loChannelSftp.get(lsFileToGet);
            String lsOriginSum =  getCheckSumFromInputStream(loChanelInStream);
            byte[] loBuffer = new byte[1024];
            BufferedInputStream loBInput = new BufferedInputStream(loChannelSftp.get(lsFileToGet));
            File loNewFile = new File(lsNewFile);
            OutputStream loOutput = new FileOutputStream(loNewFile);
            BufferedOutputStream loBOutput = new BufferedOutputStream(loOutput);
            int liReadCount;
            while((liReadCount = loBInput.read(loBuffer)) > 0)
                loBOutput.write(loBuffer, 0, liReadCount);
            loBInput.close();
            loBOutput.close();
            System.out.println("Host : "+ loSession.getHost() +" Se ha generado el archivo: "+ loNewFile.getAbsolutePath() + " Resultado Sum :  "+ compareChecksum(lsOriginSum,loNewFile.getAbsolutePath()));
            lbResult[0] = true;
            lbResult[1] = compareChecksum(lsOriginSum, getChecksum(loNewFile.getAbsolutePath()));
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        finally{
            //Despues de traer el archivo, le saca el chechsum a la copia local 
            //para comprobar que el archivo no sufrio perdidas en la transmision
            loChannelSftp.disconnect();
            //return lsMD5sum.toString().replace("\n", "").contentEquals(getChecksum(lsNewFile));
        }
        return lbResult;
    }
    }
    public class Log 
    {
        double mornd;
        String msHost;
        String moType;
        String Line;
        Date motimestamp;
        String moOutput;
        String moError;
        String mocmd;
        //String moMsg;
        public String getLine()
        {
            Line = getMsHost() + " " + getMotimestamp() + " " + getMornd() +" Cmd: "+ getMocmd() + " Operation type: "+ moType +" \nOutput: "+ getMoOutput() +" \nOutPutError: " + getMoError();
            
            return  Line;
        }
        

        public void setMornd(double mornd) {
            this.mornd = mornd;
        }

        public void setMsHost(String msHost) {
            this.msHost = msHost;
        }

        public void setMoType(String moType) {
            this.moType = moType;
        }

       

        public void setMotimestamp(Date motimestamp) {
            this.motimestamp = motimestamp;
        }

        

        public double getMornd() {
            return mornd;
        }

        public String getMsHost() {
            return msHost;
        }

        public String getMoType() {
            return moType;
        }

       

        public Date getMotimestamp() {
            return motimestamp;
        }

        public String getMoOutput() {
            return moOutput;
        }

        public void setMoOutput(String moOutput) {
            this.moOutput = moOutput;
        }

        public String getMoError() {
            return moError;
        }

        public void setMoError(String moError) {
            this.moError = moError;
        }

        public String getMocmd() {
            return mocmd;
        }

        public void setMocmd(String mocmd) {
            this.mocmd = mocmd;
        }

        
        
        
    }
    

}
