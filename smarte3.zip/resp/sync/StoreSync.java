/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yum.e3.server.development.apps.it.sync;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.ByteArrayInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.Document;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import java.util.ArrayList;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Calendar;


/**
 *
 * @author EMP2303
 */
public class StoreSync{
    
    private static Document moDOMData;
    private static  ArrayList<TaskCommandAtributes> moTCArray = new ArrayList<TaskCommandAtributes>();
    private static String msWorkingDir = "/home/jorge/Desktop/";
    private static int miPort = 22;
    private static Session session;
    private static String username = "jorge";
    private static String password = "Prb123-";
    private static String hostname = "192.168.110.81";
    
    
    //La clase UploadFile contiene el proceso que ejecutara un hilo. Debe implementar Runnable
    //para tener acceso al metodo abstracto run() que se ejecutara cuando este en un hilo.
    public static class UploadFile implements Runnable {
        
        String msFile;
        
        
        
        //El constructor de UploadFile puede recibir variables que sean necesarias para la 
        //ejecucion del hilo
        private UploadFile(String lsFile) {
            msFile = lsFile;
        }
        
        
        
        //EN ESTE CASO, establece una sesion y envia el archivo especificado por la 
        //variable global msFile en el momento de crear el objeto UploadFile
        @Override
        public void run() {
            Session loSession = null;
            try{
                System.out.println("Subiendo "+msFile+" ...");
                loSession = establishSession("192.168.110.81", "jorge", "Prb123-");
                //Thread loThread = Thread.currentThread();
                if(sendFile(loSession,"/home/jorge/Documents/prueba/"+msFile,msWorkingDir+msFile));
                    System.out.println(msFile+" subido.");
            }
            catch (Exception ex){
                ex.printStackTrace();
            }
            finally{
                endSession(loSession);
            }
        }
    }
    

    
    
    
    /*ExecutorService loPool = Executors.newFixedThreadPool(3); //Decalara un pool de hilos que limita el numero m�ximo 
                                                                    //de hilos con los que se planea trabajar. De igual forma
                                                                    //se encarga del manejo de los hilos. 
        for(int i = 1; i < 8; i++)
            loPool.submit(new UploadFile("Video"+i+".mp4")); //Encola procesos definidos en el metodo run de UploadFile. En caso de contar
                                                                //con hilos para la ejecucion, los pocesos esperan a que uno se libere.
        loPool.shutdown();*/
    //Solo existe pra pruebas
    
    
    
    public static void main(String[] args) throws IOException, JSchException{

        Session loSession = null;
        try{
            System.out.println("ESTABLECIENDO SESION.. IP: "+ "192.168.110.218");
            JSch loJSch = new JSch();
            loSession = loJSch.getSession("admin", "192.168.110.218", 22);
            loSession.setPassword("admin");
            Properties loConfig = new Properties();
            loConfig.put("StrictHostKeyChecking", "no");
            loSession.setConfig(loConfig);
            loSession.connect();
            System.out.println("\nSesi�n establecida\n");
            System.out.println("\nSesi�n establecida\n");
            sendFile(loSession,"/home/sisdbar/files/esp/sql_script.sql","/tmp/sql_script.sql");
            loSession.disconnect();
            
        }
        catch(Exception ex){
            System.err.println("Error al establecer la conexion " + ex);
            System.out.println("Error al establecer la conexion " + ex);
        }
        finally{
            //return loSession;
        }
        
        
    }
    
    
    
    
    
    //Establece una sesion remota 
    //lsHostname es la direccion de la sesion que se quiere establecer
    //lsUsername el usuario con el que se quiere dar de alta la sesion
    //lsPassword la clave de acceso de ese usuario
    //Devuelve un objeto de tipo Session con la sesion establecida.
    private static Session establishSession(String lsHostname, String lsUsername, String lsPassword){
        Session loSession = null;
        try{
            System.out.println("ESTABLECIENDO SESION..");
            JSch loJSch = new JSch();
            loSession = loJSch.getSession(lsUsername, lsHostname, miPort);
            loSession.setPassword(lsPassword);
            Properties loConfig = new Properties();
            loConfig.put("StrictHostKeyChecking", "no");
            loSession.setConfig(loConfig);
            loSession.connect();
            System.out.println("\nSesi�n establecida\n");
            
            
        }
        catch(Exception ex){
            
        }
        finally{
            return loSession;
        }
    }
    
    
    
    
    //Se asegura de que la sesion que reciba este abierta
    //la abre en caso de no estarlo
    private static void checkSession(Session loSession) {
        try {
            if(!loSession.isConnected())
                loSession.connect();
        } catch (JSchException ex) {
            Logger.getLogger(StoreSync.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    
     //Termina la Session que reciba en caso de estar abierta
    private static void endSession(Session loSession){
        try{
        if(loSession.isConnected())
            loSession.disconnect();
        }
        catch(NullPointerException nullEx){
            
        }
    }
    
    
    
    
    //Cambia el valor de la variable global miPort; 
    //la cual siempre es 22 por defecto.
    private static void setPort(int liPort){
        miPort = liPort; 
    }
    
    
    
    
    //Envia un archivo local a traves de una sesion remota
    //loSession la sesion para la cual va a enviar el archvio
    //lsFileToTranfer el archivo que se quiere enviar
    //Devuelve un booleano que nos indica si la transferencia se ralizo correctamente
    private static boolean sendFile(Session loSession, String lsFileToTransfer, String lsDestination) throws IOException, JSchException{
        //Se obtiene el checksum del archivo antes de ser enviado
        String lsMD5sum = getChecksum(lsFileToTransfer);
        checkSession(loSession);
        Channel loChannel = null;
        ChannelSftp loChannelSftp = null;
        //String lsFileName="";
        
        try{
            loChannel = loSession.openChannel("sftp"); //Se abre un canal de tipo SecureFileTransferProtocol
            loChannel.connect();
            loChannelSftp = (ChannelSftp) loChannel;
            //msWorkingDir es el directorio sobre el cual se va a trabajar y donde llegar� el erchvio
            //loChannelSftp.cd(msWorkingDir);
            
            File loFile = new File(lsFileToTransfer);
            //lsFileName = loFile.getName();
            loChannelSftp.put(new FileInputStream(loFile), lsDestination);
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        finally{
            //Se obtiene el checksum del archivo despues de ser enviado para 
            //para confirmar que el envio se realizo correctamente
            loChannelSftp.disconnect();
            return true;
        }
    }
    
    
    
    
    //Trae un archivo a traves de una coneccion remota
    //loSession la sesion que debe establecer para traer el archivo
    //lsFileToGet la ruta del archivo que debe traer
    //lsNewFile la ruta del nuevo archivo que debe crear en algun directorio local
    //Regresa un booleano que nos dice si el archivo fue traido sin problemas
    private static boolean receiveFile(Session loSession, String lsFileToGet, String lsNewFile) throws IOException, JSchException{
        //Ejecuta un checksum sobre el archivo en la sesion remota antes de traerlo
        StringBuilder lsMD5sum = new StringBuilder("");
        executeCommand(loSession, "md5sum "+lsFileToGet+" | awk '{ print $1 }'",lsMD5sum);
        
        Channel loChannel = null;
        ChannelSftp loChannelSftp = null;
        
        try{
            loChannel = loSession.openChannel("sftp"); //Se abre un canal de tipo SecureFileTransferProtocol
            loChannel.connect();
            loChannelSftp = (ChannelSftp) loChannel;
            loChannelSftp.cd(msWorkingDir);
            
            byte[] loBuffer = new byte[1024];
            BufferedInputStream loBInput = new BufferedInputStream(loChannelSftp.get(lsFileToGet));
            File loNewFile = new File(lsNewFile);
            OutputStream loOutput = new FileOutputStream(loNewFile);
            BufferedOutputStream loBOutput = new BufferedOutputStream(loOutput);
            int liReadCount;
            while((liReadCount = loBInput.read(loBuffer)) > 0)
                loBOutput.write(loBuffer, 0, liReadCount);
            loBInput.close();
            loBOutput.close();
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        finally{
            //Despues de traer el archivo, le saca el chechsum a la copia local 
            //para comprobar que el archivo no sufrio perdidas en la transmision
            loChannelSftp.disconnect();
            return lsMD5sum.toString().replace("\n", "").contentEquals(getChecksum(lsNewFile));
        }
    }
    

    
    
    
    //Para ejecutar commandos en sesion remota. Recibe la sesion a la cual debe
    //mandar los comandos, y el string con comando devuelve la salida de la 
    //terminal de la sesion remota
    private static boolean executeCommand(Session loSession,String lsCommand, StringBuilder lsResult) throws IOException, JSchException{
        String lsError = "";
        System.out.println(" **************** recibiendo comando " + lsCommand);
        Channel loChannel = null;
        ChannelExec loChannelExec = null;
        Integer loIdChannel = 0;
        try{
 
            
            
            
            loChannel = loSession.openChannel("exec"); //Abre un canal, de tipo ejecutable, en la sesion
            loChannelExec = (ChannelExec)loChannel;
            loChannelExec.setCommand(lsCommand);
            loChannelExec.setErrStream(System.err); //Dirige el canal de salida de errores de la tarminal en la sesion remota a canal de System.err
            InputStream loInput = loChannelExec.getInputStream();
            //En el momento de hacer la coneccion, el comando se ejecuta de forma autom�tica.
            InputStream loErrorStream = loChannelExec.getErrStream();
            loChannelExec.connect();

        
            
            
            //Obtiene el la respuesta de la terminal de la sesion remota y la pasa a un String por medio de un buffer
            byte[] loBuffer = new byte[1024];
            
            while(true){
                
                    int i = loInput.read(loBuffer, 0, 1024);
                while(loInput.available() > 0){
                    
                    
                    if(i<0)break;
                    lsResult.append( new String (loBuffer, 0, i));
                }
                if(loChannel.isClosed()){
                    //System.out.println("exit-status: "+loChannel.getExitStatus());
                    break;
                }
                try{Thread.sleep(1000);}catch(Exception ex){}
            }
            
            
            
            loBuffer = new byte[1024];
            
            while(true){
                while(loErrorStream.available() > 0){
                    int i = loErrorStream.read(loBuffer, 0, 1024);
                    if(i<0)break;
                    lsError += new String (loBuffer, 0, i);
                }
                if(loChannel.isClosed()){
                    //System.out.println("exit-status: "+loChannel.getExitStatus());
                    break;
                }
                try{Thread.sleep(1000);}catch(Exception ex){}
            }
            System.out.println("La salida del comando es:");
            System.out.println(lsResult);
            System.out.println("La salida de error es:");
            System.out.println(lsError);
            
            CommandExit commandEx = new CommandExit();
            commandEx.resultExit = lsResult;
            commandEx.errorExit = lsError;
            log(lsCommand, lsError, lsResult);
            lsResult = new StringBuilder("");
           System.out.println("El valor del canal es: " + loChannel.isConnected() + 
                    " y el valor del canal ejec es: " + loChannelExec.isConnected());
            
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        finally{
            //loChannelExec.disconnect();
            if(lsError.contentEquals("")) //De no haber errores, devuelve 
                return true;
            else{
                //lsResult.append(lsError);
                return false;
            }
        }
    }
    
    
    
    
    public static void log(String command, String error, StringBuilder result) throws IOException{
        boolean state = cmdValidate(result, error);
        String commandState = "";
        if(state){
            commandState = "Si";
        }
        
        else{
            commandState = "No";
        }
        
        FileWriter archivo;
        if (new File("log.txt").exists()==false){archivo=new FileWriter(new File("/tmp/LOG.txt"),false);}
             archivo = new FileWriter(new File("/tmp/LOG.txt"), true);
             Calendar fechaActual = Calendar.getInstance(); //Para poder utilizar el paquete calendar    
             //Empieza a escribir en el archivo
             archivo.write("********************  Date:   ********************\n" + (String.valueOf(fechaActual.get(Calendar.DAY_OF_MONTH))
                  +"/"+String.valueOf(fechaActual.get(Calendar.MONTH)+1)
                  +"/"+String.valueOf(fechaActual.get(Calendar.YEAR))
                  +";"+String.valueOf(fechaActual.get(Calendar.HOUR_OF_DAY))
                  +":"+String.valueOf(fechaActual.get(Calendar.MINUTE))
                  +":"+String.valueOf(fechaActual.get(Calendar.SECOND)))+
                     "\n******************** Command: ********************\n"+command+"\n******************** Resultado: ******************\n"+result+
                     "\n******************** Error: ********************** \n"+error+
                     "\n******************** Se ejecut� corectamente: ********************** \n"+commandState+"\n\n\n\r\n");
             archivo.close();
    }
    
    
    
    public static boolean cmdValidate(StringBuilder lsResult, String lsError){
        boolean lsValidate = false;
        if((lsError.equals("") && lsResult.equals("")) || (lsError.equals("") && !lsResult.equals(""))){
            System.out.println("Comando ejecutado satisfactoriamente.");
            lsValidate = true;
        }
        
        else if(lsError == ""){
            System.out.println("No se ejecut� el comando.");
        }
        
        return lsValidate;
    }
    
 
    
    //Hace un parseo del archivo XML para obtener los atributos de cada 
    //linea de comando y guardarlos en objetos de tipo TaskCommandAtribute
    private static void parseXML(){
        if(moDOMData != null){
            Node loAttribute;
            Node loTreeOption;
            TaskCommandAtributes loTaskCommand;
            NamedNodeMap loAttributes;
            NodeList loTreeOptionChildren;
            
            NodeList loTreeOptions = moDOMData.getElementsByTagName("tree_option");
            for(int i = 0; i < loTreeOptions.getLength(); i++){
                loTaskCommand = new TaskCommandAtributes();
                loTreeOption = loTreeOptions.item(i);
                loAttributes = loTreeOption.getAttributes();
                for(int j = 0; j < loAttributes.getLength(); j++){
                    loAttribute = loAttributes.item(j);
                    if(loAttribute.getLocalName().contentEquals("Tipo"))
                        loTaskCommand.lsType = loAttribute.getNodeValue();
                    if(loAttribute.getLocalName().contentEquals("option_id"))
                        loTaskCommand.lsOptionId = loAttribute.getNodeValue();
                    if(loAttribute.getLocalName().contentEquals("parent_id"))
                        loTaskCommand.lsParentId = loAttribute.getNodeValue();
                }
                loTreeOptionChildren = loTreeOption.getChildNodes();
                loTaskCommand.lsSource = getValidNodeValue(loTreeOptionChildren.item(0).getFirstChild(),"");
                loTaskCommand.lsDestination = getValidNodeValue(loTreeOptionChildren.item(1).getFirstChild(),"");
                loTaskCommand.loExecuted = false;
                moTCArray.add(loTaskCommand);
            }
        }
    }
    
    
    
    //Lee un archivo XML y lo almacena como objeto de tipo Document en la variable moDOMData
    private static void readXMLFile(String lsXMLFile) throws IOException {
        BufferedReader loBurreredReder = new BufferedReader(new FileReader(lsXMLFile));
        try {
            StringBuilder loStringBuilder = new StringBuilder();
            String lsLine = loBurreredReder.readLine();
            //Lee el archivo linea por linea y lo guarda en el StringBuilder 
            while (lsLine != null) {
                loStringBuilder.append(lsLine.trim());//Elimina los espacion vacios en la linea 
                //loStringBuilder.append("\n");
                lsLine = loBurreredReder.readLine();
            }
            //String loXMLString = "";
            /*String[] loLines = loStringBuilder.toString().split("\n");
            for(int i = 0; i < loLines.length; i++)
                loXMLString += loLines[i];*/
            moDOMData = (Document) loadXMLFromString(loStringBuilder.toString());
        }
        catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        finally {
            loBurreredReder.close();
        }
    }
    
    
    
    //Recibe un XML en forma de String y lo convierte en un objeto de tipo Document
    public static Document loadXMLFromString(String lsXML) throws Exception{
        DocumentBuilderFactory loDocumentFactory = DocumentBuilderFactory.newInstance();
        loDocumentFactory.setNamespaceAware(true);
        DocumentBuilder loDocumentBuilder = loDocumentFactory.newDocumentBuilder();
        return loDocumentBuilder.parse(new ByteArrayInputStream(lsXML.getBytes()));
    }
    
    
    
    //Verifica que el string psAttribute no este igualado a un null. En caso de
    //estarlo devielve el valor de psDefaultvalue
    public static  String getValidNodeValue(Node loCheckNode, String lsIfNull) {
        if(loCheckNode != null)
            return loCheckNode.getNodeValue();
        else
            return lsIfNull;
    }
    
    
    
    //Recibe una ruta y devuelve el checksum correspondiente al archivo que se encuentra en la ruta
    public static String getChecksum (String loDir){
        try{
            FileInputStream loCheckFile = new FileInputStream(loDir);
            MessageDigest loMD5 = MessageDigest.getInstance("MD5");
            byte[] loCheckBytes = new byte[1024];
            int liNumRead = 0;
            while ((liNumRead = loCheckFile.read(loCheckBytes)) != -1)
                loMD5.update(loCheckBytes, 0, liNumRead);
            byte[] loMD5Bytes = loMD5.digest();
            StringBuffer loStrinfBuffer = new StringBuffer();
            for (int i = 0; i < loMD5Bytes.length; i++)
                loStrinfBuffer.append(Integer.toString((loMD5Bytes[i] & 0xff) + 0x100, 16).substring(1));
            return loStrinfBuffer.toString();
        } catch(IOException ex){
            return(ex+"");
        } catch (NoSuchAlgorithmException ex) {
            return(ex+"");
        }
    }
    
    public static boolean executeCommandX(Session loSession,String lsCommand) throws IOException, JSchException
        {
          String lsError = "";
          String lsResult = "";
          System.out.println("*** Comando: " + lsCommand);
          Channel loChannel = null;
          ChannelExec loChannelExec = null;
          try{

              loChannel = loSession.openChannel("exec"); //Abre un canal, de tipo ejecutable, en la sesion
              loChannelExec = (ChannelExec)loChannel;
              loChannelExec.setInputStream(null);
              loChannelExec.setCommand(lsCommand);
              loChannelExec.setErrStream(System.err); //Dirige el canal de salida de errores de la tarminal en la sesion remota a canal de System.err
              InputStream loInput = loChannel.getInputStream();
              InputStream loErrorStream = loChannelExec.getErrStream();
               //En el momento de hacer la coneccion, el comando se ejecuta de forma autom�tica.
              loChannelExec.connect();

              InputStreamReader inputReader = new InputStreamReader(loInput);
              BufferedReader bufferedReader = new BufferedReader(inputReader);
                  String line = null;
                  System.out.println("* Salida de comando: * ");
                  while((line = bufferedReader.readLine()) != null){
                      System.out.println(line);
                      lsResult += lsResult + line + "\n";  
                  }

              InputStreamReader inputReaderError = new InputStreamReader(loErrorStream);
              BufferedReader bufferedReaderError = new BufferedReader(inputReaderError);
                  String lineError = null;
                  System.out.println("* Salida de Error de Comando: * "); 
                  while((lineError = bufferedReaderError.readLine()) != null){
                      System.out.println(lineError);
                       lsError += lsError + lineError + "\n";  
                  }

          }
          catch(Exception ex){
              ex.printStackTrace();
          }
          finally{
              loChannel.disconnect();
              loChannelExec.disconnect();
              if(lsError.contentEquals("")) //De no haber errores, devuelve 
                  return true;
              else{
                  //lsResult.append(lsError);
                  return false;
              }
          }
      }
        public static boolean exec(Session loSession,String lsCommand)
    {
        boolean c =false;
        
                 try
                        {
                            String lsOutput = null;
                            String lsErrorOutput = null;
                            Runtime rt = Runtime.getRuntime();
                            Process proc = rt.exec(lsCommand);
                            BufferedReader stdInput = new BufferedReader(new
                            InputStreamReader(proc.getInputStream()));

                            BufferedReader stdError = new BufferedReader(new
                            InputStreamReader(proc.getErrorStream()));
                              System.out.println("* Salida de comando: * ");
                                 while ((lsOutput = stdInput.readLine()) != null) {
                                     System.out.println(lsOutput);
                                     lsOutput += lsOutput + lsOutput + "\n";
                                 }

                                System.out.println("* Salida de Error de Comando: * "); 
                                 while ((lsErrorOutput = stdError.readLine()) != null) {
                                     System.out.println(lsErrorOutput);
                                     lsErrorOutput += lsErrorOutput + lsErrorOutput + "\n";
                                 }  
                                 c =true;
                        }
                        catch (Exception e) 
                        {
                            System.out.println(e.toString());
                        }
                 return  c;
    }
    //Manejo de los comandos extraidos del XML en forma de estructura
    public static class TaskCommandAtributes{
        public String lsOptionId;
        public String lsType;
        public String lsParentId;
        public String lsSource;
        public String lsDestination;
        public boolean loExecuted;
        TaskCommandAtributes(){
        }
    }
    
    
    
    //Manejo de salidas en ejecucion de comandos
    public static class CommandExit{
        public String errorExit;
        public StringBuilder resultExit;
        CommandExit(){         
        }
    
    }
    
}
