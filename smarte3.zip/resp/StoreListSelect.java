/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yum.e3.client.development.apps.it.sync;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.logical.shared.AttachEvent;
import com.google.gwt.user.client.ui.FileUpload;
import com.google.gwt.user.client.ui.FormPanel;
import com.google.gwt.user.client.ui.IsWidget;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.xml.client.Text;
import com.smartgwt.client.types.AutoFitWidthApproach;
import yum.e3.server.development.apps.it.sync.*;
import yum.e3.client.generals.templates.windows.*;
import com.smartgwt.client.types.HeaderControls;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Button;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.events.CloseClientEvent;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.fields.events.KeyPressEvent;
import com.smartgwt.client.widgets.form.fields.events.KeyPressHandler;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.CellDoubleClickEvent;
import com.smartgwt.client.widgets.grid.events.CellDoubleClickHandler;
import com.smartgwt.client.widgets.grid.events.CellMouseDownEvent;
import com.smartgwt.client.widgets.grid.events.CellMouseDownHandler;
import com.smartgwt.client.widgets.grid.events.CellSavedEvent;
import com.smartgwt.client.widgets.grid.events.CellSavedHandler;
import com.smartgwt.client.widgets.grid.events.EditCompleteEvent;
import com.smartgwt.client.widgets.grid.events.EditCompleteHandler;
import com.smartgwt.client.widgets.grid.events.EditFailedEvent;
import com.smartgwt.client.widgets.grid.events.EditFailedHandler;
import java.util.Date;
import java.util.LinkedHashMap;
import yum.e3.client.SolutionFactory;
import static yum.e3.client.development.apps.finance.it.ccot.controls.ControlFactory.createIButton;
import yum.e3.client.generals.AppHandler;
import yum.e3.client.generals.rpc.RPCHandler;
import yum.e3.client.generals.rpc.RemoteDBAccess;
import yum.e3.client.generals.rpc.data.DBRequest;
import yum.e3.client.generals.rpc.data.WebServiceData;
import yum.e3.client.generals.rpc.data.WebServiceRequest;
import yum.e3.client.generals.templates.core.ABCGridParser;
import yum.e3.client.generals.templates.core.ABCRowControl;
import yum.e3.client.generals.templates.core.ReportHeader;
import yum.e3.client.generals.templates.core.SolutionHandler;
import yum.e3.client.generals.templates.ui.ABCGrid;
import yum.e3.client.generals.templates.ui.ABCGridPanel;
import yum.e3.client.generals.utils.Alert;
import yum.e3.client.generals.utils.DataUtils;
/**
 *
 * @author jorge
 */
public class StoreListSelect extends ABCGridDetailWindow{
    protected SolutionHandler moSolutionHandler;
    protected ABCGridPanel moReportPanel;
    protected String loSelection;



    public StoreListSelect(SolutionHandler poSolutionHandler) {
        super(poSolutionHandler);
        this.moReportPanel = super.moReportPanel;
        this.loSelection = "";

    }

    //protected ReportPanelTA moReportPanel;

    public static class Factory implements SolutionFactory {
        public Canvas create(SolutionHandler poSolutionHandler) {
            return new StoreListSelect(poSolutionHandler);
        }
    }
    
    
    
    
    @Override
    public ABCGridPanel getReportPanel(SolutionHandler poSolutionHandler) {
        return new ABCGridPanel(poSolutionHandler){
        
            
            public String selectDeSelectAll() {
                        ListGridRecord loRecords[] = null;
                        int lsTotalSelect = 0;
                        int lsTotalDeselect = 0;
                        System.out.println("Mostrando registros...");
                        loRecords = moReportPanel.getGrid().getRecords();
                        System.out.println("Imprimiendo...");
                        System.out.println("Total de registros: " + loRecords.length);
                        for(int li = 0; li < loRecords.length ; li++){
                            ListGridRecord loRecord = loRecords[li];
                            
                                Boolean lsRecordAttribute = Boolean.parseBoolean(loRecord.getAttributeAsString("status"));
                                System.out.println(lsRecordAttribute);
                                //System.out.println(loRecord.getAttributeAsString(lsRecordAttribute));
                                
                                
                                
                                if(lsRecordAttribute == false)
                                    lsTotalDeselect ++;
                                
                                else if(lsRecordAttribute == true)
                                    lsTotalSelect ++;
                                
                        }
                        System.out.println("Total de true encontrados: " + lsTotalSelect);
                        System.out.println("Total de false encontrados: " + lsTotalDeselect);
                        
                        if(lsTotalDeselect > 0){
                            loSelection = "Deseleccionar todo";
                            selectaAll();
                            moReportPanel.updateDetail();
                            moReportPanel.redraw();
                            
                            
                        }
                        
                        else if(lsTotalSelect == loRecords.length){
                            loSelection = "Seleccionar todo";
                            deSelectaAll();
                            moReportPanel.updateDetail();
                            moReportPanel.redraw();
                        }
                        
                        moReportPanel.updateDetail();
                        moReportPanel.redraw();
                        System.out.println(loSelection);
                        return loSelection;
            }
            
            
            public void selectaAll(){
                ListGridRecord loRecords[] = null;
                loRecords = moReportPanel.getGrid().getRecords();
                   
                
                
                for(int li = 0; li < loRecords.length ; li++){
                    ListGridRecord loRecord = loRecords[li];

                    String lsRecordAttribute = loRecord.getAttributeAsString("status");
                    String lsRecordRow = loRecord.getAttributeAsString("row_control_object");
                    loRecord.setAttribute("status", true);
                    ABCRowControl loRC = getRowControl(loRecord);
                    loRC = new ABCRowControl();
                    loRC.setAction(ABCRowControl.ROW_EDITED);
                    loRecord.setAttribute(ABCRowControl.ROW_CONTROL_OBJECT,loRC);
                    System.out.println(lsRecordAttribute);
                    System.out.println(lsRecordRow);
                    
                }
                moReportPanel.redraw();
            }
            
            
            public void deSelectaAll(){
                ListGridRecord loRecords[] = null;
                loRecords = moReportPanel.getGrid().getRecords();
                for(int li = 0; li < loRecords.length ; li++){
                    ListGridRecord loRecord = loRecords[li];
       
                    String lsRecordAttribute = loRecord.getAttributeAsString("status");
                    String lsRecordRow = loRecord.getAttributeAsString("_rec");
                    loRecord.setAttribute("status", false);
                    ABCRowControl loRC = getRowControl(loRecord);
                    loRC = new ABCRowControl();
                    loRC.setAction(ABCRowControl.ROW_EDITED);
                    loRecord.setAttribute(ABCRowControl.ROW_CONTROL_OBJECT,loRC);
                    System.out.println(lsRecordAttribute);    
                    System.out.println(lsRecordRow);
                    
                }
                moReportPanel.redraw();
            }
            
            
            
            
    public void buildLayout(SolutionHandler poSolutionHandler) {
        setSolutionHandler(poSolutionHandler);
            
        String loTitleSelect="Seleccionar todos";
            
        
        
        moParser = new ABCGridParser(poSolutionHandler.getXMLConfigData());
        if (moParser.isEmbededComponent()) {
            moHeader = new ReportHeader("", "", false, 23);
        } else {
            moHeader = new ReportHeader(poSolutionHandler.getTitle(), poSolutionHandler.getDepartmentIcon());
        }
        
        //Modificaci�n por DAS0685////////
        if(moParser.hasFilter()){
            final TextItem moTxtFilter = new TextItem();
            moTxtFilter.setWidth(170);
            moTxtFilter.setLength(25);
            moTxtFilter.setTitle("Filtrar por");
            moTxtFilter.setWrapTitle(false);

            moTxtFilter.addKeyPressHandler(new KeyPressHandler() {
                public void onKeyPress(KeyPressEvent poEvent) {
                    if ("ENTER".equalsIgnoreCase(poEvent.getKeyName())) {
                         msFilterValue=moTxtFilter.getValueAsString();
                         doFilter(moTxtFilter.getValueAsString());
                    }
                }
            });
            
            
        
            IButton loFilter = new IButton("");
            loFilter.setIcon(AppHandler.getConfigData().getConfiguration("abcDParam_filterIcon"));
            loFilter.setWidth(25);
            loFilter.addClickHandler(new ClickHandler() {
                public void onClick(ClickEvent event) {
                    msFilterValue=moTxtFilter.getValueAsString();
                    doFilter(moTxtFilter.getValueAsString());
                }
            });
        
            IButton loCancelFilter = new IButton("");
            loCancelFilter.setIcon(AppHandler.getConfigData().getConfiguration("abcDParam_filterCancelIcon"));
            loCancelFilter.setWidth(25);
            loCancelFilter.addClickHandler(new ClickHandler() {
                public void onClick(ClickEvent event) {
                    moTxtFilter.setValue("");
                    msFilterValue="";
                    doFilter(moTxtFilter.getValueAsString());
                   }
               });
            
            System.out.println("El titulo actaul para el boton es: " + loTitleSelect);
            
            IButton loSel = new IButton("");
            loSel.setTitle("Seleccionar todos");
            loSel.setWidth(135);
            loSel.addClickHandler(new ClickHandler() {
                public void onClick(ClickEvent event) {
                        ((IButton)event.getSource()).setTitle(selectDeSelectAll());
                    }
               });
            
            final Window loDSTwindow =  new Window();
            DynamicForm loTopForm = new DynamicForm();
            loTopForm.setFields(moTxtFilter);
            final FormPanel loFormPanelDST =  new FormPanel();
            loFormPanelDST.setEncoding(FormPanel.ENCODING_MULTIPART);
            loFormPanelDST.setMethod(FormPanel.METHOD_POST);
            loFormPanelDST.setAction(GWT.getHostPageBaseURL()+"StoreListSelectServlet");
            loFormPanelDST.addSubmitCompleteHandler(new FormPanel.SubmitCompleteHandler() {
                public void onSubmitComplete(FormPanel.SubmitCompleteEvent poEvent) {
                    //SC.say(poEvent.getResults());
                    moGrid.refreshData();
                    loDSTwindow.hide();
                    SC.say("Se ha guardado lista de distribuci�n.");
                }
            });
            VerticalPanel loVerticalDST = new VerticalPanel();
            loVerticalDST.setSpacing(10);
            final FileUpload  loFileUpload = new FileUpload();
            loFileUpload.setTitle("Buscar Archivo de lista de distribuci�n:");
            loFileUpload.setName("list");
            loFileUpload.getElement().setAttribute("accept",".dst");
            final Button loAceptBtnDST =  new Button("Aceptar");
            loAceptBtnDST.addClickHandler(new ClickHandler() {
                public void onClick(ClickEvent event) {
                    
                    if(loFileUpload.getFilename().equals(""))
                    {
                         Alert.showError("Porfavor eliga un archivo de listas");
                    }
                    else if(!loFileUpload.getFilename().contains(".dst"))
                    {
                        Alert.showError("Porfavor eliga un archivo de listas");
                    }
                    else
                    {
                      loFileUpload.setName(moSolutionHandler.getInitParams().getControlValue("master.field1")+"~"+loFileUpload.getName());
                       loFormPanelDST.submit();
                    }  
                  
                 
                }
            });
            
            loDSTwindow.setTitle("Examinar");
            loDSTwindow.setWidth(200);
            loDSTwindow.setHeight(100);
            loDSTwindow.setAutoSize(true);  
            loDSTwindow.setCanDragReposition(true);  
            loDSTwindow.setCanDragResize(true);
            loDSTwindow.addCloseClickHandler(new CloseClickHandler() {
                       public void onCloseClick(CloseClientEvent event) {
                           loDSTwindow.hide();
                       }
            });
           
            loVerticalDST.add(loFileUpload);
            loVerticalDST.add(loAceptBtnDST);
            loFormPanelDST.setWidget(loVerticalDST);
            loDSTwindow.addItem(loFormPanelDST);
            IButton  loImportDST =  new IButton("Examinar");
            loImportDST.addClickHandler(new ClickHandler() {

                public void onClick(ClickEvent event) {
                  loDSTwindow.show();
                  addChild(loDSTwindow);
                }
            });
           
            moHeader.getToolStrip().setSeparatorSize(50);
            moHeader.getToolStrip().addMember(loTopForm);
            moHeader.getToolStrip().addMember(loFilter);
            moHeader.getToolStrip().addMember(loCancelFilter);
            moHeader.getToolStrip().addMember(loImportDST);
            moHeader.getToolStrip().addMember(loSel);
            moHeader.addSpacer(40);
           
        }
        ////////////////////////////////////////////////////
        if(printBtnFlag())moHeader.addButtons(moParser.parseAndGetButtons(this));
        
        //Agregar canvas a grid
        moGrid = createGrid(moParser);

        
        addMember(moHeader);
        addMember(moGrid);

        if (moSolutionHandler.canExecuteOnLoad()) moGrid.populateGrid("");
        moGrid.refreshData();
        manageEndOfCall();
        
    }
            
            
            
            
            
            
            
            
             
            public ABCGrid createGrid(ABCGridParser poGridParser){
                return new ABCGrid(poGridParser){
                    
                    
                    
                    
                    
                    
                    @Override
                    public void executeAfterLoad(){
                        ListGridRecord loRecords[] = null;
                        System.out.println("Mostrando registros...");
                        loRecords = moReportPanel.getGrid().getRecords();
                        System.out.println("Imprimiendo...");
                        for(int li = 0; li < loRecords.length ; li++){
                            ListGridRecord loRecord = loRecords[li];
                            
                                String lsRecordAttribute = loRecord.getAttributeAsString("status");
                                System.out.println(lsRecordAttribute);
                                //System.out.println(loRecord.getAttributeAsString(lsRecordAttribute));
                                if(lsRecordAttribute.equals(false)){
                                    loSelection = "Seleccionar todo";
                                }
                                else{
                                    loSelection = "Deseleccionar todo";
                                }
                                 
                                
                        }
                        
                        System.out.println(loSelection);
                        
                    }
                    
                    
                };
            }
        };
    }
    
    
    
    
    protected ABCRowControl getRowControl(ListGridRecord record) {
        ABCRowControl loRC = (ABCRowControl)record.getAttributeAsObject(ABCRowControl.ROW_CONTROL_OBJECT);

        return loRC;
    }
    
    @Override
        public void initWindow() {
            
            //moReportPanel.getGrid();
            buildWindow();

            System.out.println(loSelection);
    }
        
            
    

}
