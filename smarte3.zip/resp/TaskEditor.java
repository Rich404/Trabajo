/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yum.e3.client.development.apps.it.sync;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.ui.FileUpload;
import com.google.gwt.user.client.ui.FormPanel;
import com.google.gwt.user.client.ui.TreeItem;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.Node;
import com.google.gwt.xml.client.NodeList;
import com.google.gwt.xml.client.Text;
import com.google.gwt.xml.client.XMLParser;
import com.smartgwt.client.data.Record;
import com.smartgwt.client.data.RecordList;
import com.smartgwt.client.docs.Data;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.types.ContentsType;
import com.smartgwt.client.types.ListGridEditEvent;
import com.smartgwt.client.types.ListGridFieldType;
import com.smartgwt.client.types.Overflow;
import com.smartgwt.client.types.Positioning;
import com.smartgwt.client.types.SelectionStyle;
import com.smartgwt.client.types.TreeModelType;
import com.smartgwt.client.types.VerticalAlignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Button;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.HTMLFlow;
import com.smartgwt.client.widgets.HTMLPane;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.RichTextEditor;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.events.CloseClientEvent;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.CheckboxItem;
import com.smartgwt.client.widgets.form.fields.FormItem;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.TextAreaItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.CellClickEvent;
import com.smartgwt.client.widgets.grid.events.CellClickHandler;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.grid.events.SelectionChangedHandler;
import com.smartgwt.client.widgets.grid.events.SelectionEvent;
import com.smartgwt.client.widgets.layout.HLayout;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.toolbar.ToolStrip;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;
import com.smartgwt.client.widgets.tree.Tree;
import com.smartgwt.client.widgets.tree.TreeGrid;
import com.smartgwt.client.widgets.tree.TreeGridField;
import com.smartgwt.client.widgets.tree.TreeNode;
import java.io.File;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import yum.e3.client.SolutionFactory;
import yum.e3.client.generals.AppHandler;
import yum.e3.client.generals.rpc.RPCHandler;
import yum.e3.client.generals.rpc.RemoteDBAccess;
import yum.e3.client.generals.rpc.data.DBResponse;
import yum.e3.client.generals.rpc.data.SQLDMLBatch;
import yum.e3.client.generals.rpc.data.SQLQuery;
import yum.e3.client.generals.templates.core.ReportHeader;
import yum.e3.client.generals.templates.core.SolutionHandler;
import yum.e3.client.generals.templates.ui.DynamicComboBoxItem;
import yum.e3.client.generals.ui.XMLTree;
import yum.e3.client.generals.utils.Alert;
import yum.e3.client.generals.utils.DataUtils;

/**
 *
 * @author DAB1379
 */
public class TaskEditor extends VLayout{
    protected String msXMLData;
    protected Document moDOMData;
    protected ReportHeader moHeader;
    private ToolStripButton maHeaderButtons[];
    private String maXMLConfigData[];
    private TreeGrid moTreeGrid;
    private int miLast;
    private SelectItem moTypeCmb;
    private Window moFileWindow;
    private int moFlag;
    private DynamicComboBoxItem moBrand;
    private String[] moValidTaskType;
    private String moSuffix;
    private String moBrandSet;
    private String moUploadDirectory;
    protected Window moWaitWindow;
    public RPCHandler<DBResponse> moRPCHandler = null;
    private TaskTreeGrid moTaskGrid;
    private FormPanel loForm;
    private FileUpload loFileUpload;
    
    private ListGrid moListGridTaskDB,moListTaskDetail;
    
    
    
    // CONTROLES TAREAS
    
    private TextItem moTextNameTask,moTextIdTask,moTextOther,moTxtFiltro;
    private CheckboxItem moCheckShared,moCheckStatus;
    private TextAreaItem moTextDescription;
    private String lsXMLString,moUser,msIdDetail;
   
    private  LinkedHashMap<String,String> moCmbValues;

    private void showWaitWindow(){
        moWaitWindow.show();
    }
    
    private void hideWaitWindow(){
        moWaitWindow.hide();
    }
    
    private FormPanel drawForm() {
        
        loForm = new FormPanel();
        VerticalPanel loPanel = new VerticalPanel();
        VLayout  loGridContent =  new VLayout();
        loGridContent.setWidth(500);
        loPanel.setSpacing(10);
        loPanel.setWidth("500px");
        loPanel.setHeight("402px");
        
        Label loLbl =  new Label("Tarea desde Archivo (.tkq) : ");
        loLbl.setHeight(18);
        loLbl.setWidth(150);
        loPanel.add(loLbl);
        
        loForm.setWidget(loPanel);

        loForm.setEncoding(FormPanel.ENCODING_MULTIPART);
        loForm.setMethod(FormPanel.METHOD_POST);

        loFileUpload = new FileUpload();
        loFileUpload.setTitle("Buscar Archivo de Tareas:");
        loFileUpload.setName("taskTkqFile");
        loFileUpload.getElement().setAttribute("accept",".tkq");
        loPanel.add(loFileUpload);
        
        IButton loBtn  = new IButton("Cargar ");
        loBtn.setIcon("e3/ui/customercare/upload.png");
        loBtn.addClickHandler(new ClickHandler() {
            public void onClick(ClickEvent event) {
                loForm.submit();
            }
        });
        
        
        
        ToolStrip TaskToolStrip = new ToolStrip();  
        TaskToolStrip.setWidth100();  
        TaskToolStrip.addFill();
        
        
        moTxtFiltro =  new TextItem("txtFilterTask","Filtro");
        TaskToolStrip.addFormItem(moTxtFiltro);
        
        ToolStripButton loFilterBtn = new ToolStripButton("", "e3/ui/templates/filter.gif");
        loFilterBtn.setAutoFit(true);
        loFilterBtn.addClickHandler(new ClickHandler() {  
            public void onClick(ClickEvent event) {  
                 //moTxtFiltro.setValue("");
                 //SC.warn("OKAY !: " + moTxtFiltro.getValueAsString());
                 if(moTxtFiltro.getValueAsString() == null)
                 {
                     moTxtFiltro.setValue("");
                 }
                    RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                    loRDBA.executeDBRequest(new SQLQuery("SELECT task_id as id_tarea, task_name as nombre, task_desc as descripcion, user_id as usuario, is_shared, status, xml_data FROM  it_snc_cat_task WHERE task_name LIKE '%"+ moTxtFiltro.getValueAsString() +"%' AND user_id = '"+ moUser +"';","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {
                        @Override
                        public void onSuccessAction(DBResponse poResponse) {
                            //printLOG("N",psStore);

                           if(poResponse.getResultAsString().equals(""))
                           {
                               //Alert.show("Esta Vacio :v");
                           }
                           else
                           {
                               populateGrid(poResponse,moListGridTaskDB);
                               moListGridTaskDB.hideField("is_shared");
                           }


                        }
                        @Override
                        public void onFailureAction(String psMessage) {
                            manageEndOfCall();
                            Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                        }
                    }); 
                 
            }  
        });
        TaskToolStrip.addButton(loFilterBtn);
        
        ToolStripButton loFilterCancelBtn = new ToolStripButton("", "e3/ui/templates/filter_x.gif");
        loFilterCancelBtn.setAutoFit(true);
        loFilterCancelBtn.addClickHandler(new ClickHandler() {  
            public void onClick(ClickEvent event) {  
                 //SC.warn("Cancelar !");
                     RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                     loRDBA.executeDBRequest(new SQLQuery("SELECT task_id as id_tarea, task_name as nombre, task_desc as descripcion, user_id as usuario, is_shared, status, xml_data FROM  it_snc_cat_task WHERE task_name LIKE '%%' AND user_id = '"+ moUser +"';","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {
                        @Override
                        public void onSuccessAction(DBResponse poResponse) {
                            //printLOG("N",psStore);

                           if(poResponse.getResultAsString().equals(""))
                           {
                               //Alert.show("Esta Vacio :v");
                           }
                           else
                           {
                             populateGrid(poResponse,moListGridTaskDB);
                             moListGridTaskDB.hideField("is_shared");
                           }


                        }
                        @Override
                        public void onFailureAction(String psMessage) {
                            manageEndOfCall();
                          Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                        }
                    }); 
            }  
        });
        TaskToolStrip.addButton(loFilterCancelBtn);
      
        
        
        loForm.addSubmitHandler(new FormPanel.SubmitHandler() {
            public void onSubmit(FormPanel.SubmitEvent poEvent) {
              
               if(loFileUpload.getFilename().equals(""))
                {
                    Alert.showError("Porfavor eliga un archivo de tareas");
                }
               else if(!loFileUpload.getFilename().contains(".tkq"))
               {
                   Alert.showError("Porfavor eliga un archivo de tareas");
               }
               else
               {
                  
                  //Alert.show("url: "+ GWT.getHostPageBaseURL()+"TkqParserServlet");
                  loForm.setAction(GWT.getHostPageBaseURL()+"TkqParserServlet");  
               }
                  
                
            }
        });
        loForm.addSubmitCompleteHandler(new FormPanel.SubmitCompleteHandler() {
            public void onSubmitComplete(FormPanel.SubmitCompleteEvent poEvent) {

                //Alert.show("Id de respuesta  - Para XML: "+poEvent.getResults().trim());
                moTextIdTask.setValue("");
                moTextNameTask.setValue("");
                moTextDescription.setValue("");
                moCheckShared.setValue(false);
                moCheckStatus.setValue(false);
                
                moTextNameTask.setValue(loFileUpload.getFilename().replace(".tkq",""));
                RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                loRDBA.executeDBRequest(new SQLQuery("SELECT xmldata FROM it_snc_cat_request_xml_task WHERE id_request = '"+ poEvent.getResults().trim() +"';","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {
                    @Override
                    public void onSuccessAction(DBResponse poResponse) {
                            if(poResponse.getResultAsString().equals(""))
                            {
                                //Alert.show("Esta Vacio :v");
                            }
                            else
                            {
                                  //Alert.show("Exito en Query");
                                  moTaskGrid.populateFromString(poResponse.getResult()[0][0]);
 
                                  moFileWindow.hide();// PAra Poder crear nuevas instancias
                                  DeleteXmlRequest();
                            }


                         }
                         @Override
                         public void onFailureAction(String psMessage) {
                             manageEndOfCall();
                             Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                         }
                    });

                    }
                });
        
        
        moListGridTaskDB = new ListGrid();  
        moListGridTaskDB.setWidth(500);  
        moListGridTaskDB.setHeight(224);  
        moListGridTaskDB.setShowAllRecords(true);  
        moListGridTaskDB.setSelectionType(SelectionStyle.SINGLE);  
  
        ListGridField loFieldid_taskd = new ListGridField("id_task","TaskID");    
        ListGridField loFieldtask_name = new ListGridField("task_name", "Nombre");  
        ListGridField loFieldtask_desc = new ListGridField("task_desc", "Descripcion");  
        ListGridField loFielduser_id = new ListGridField("user_id", "Usuario");  
        ListGridField loFieldis_shared = new ListGridField("is_shared","Compartido");
        loFieldis_shared.setHidden(true);
        loFieldis_shared.setType(ListGridFieldType.BOOLEAN);
        ListGridField loFieldstatus = new ListGridField("status","Status");
        loFieldstatus.setType(ListGridFieldType.BOOLEAN);
        ListGridField loFieldxml_data =  new ListGridField("xml_data","Xml");
        loFieldxml_data.setType(ListGridFieldType.TEXT);
        
        moListGridTaskDB.setFields(loFieldid_taskd,loFieldtask_name,loFieldtask_desc,loFielduser_id,loFieldis_shared,loFieldstatus,loFieldxml_data );  
      
      
        moListGridTaskDB.setData(moListGridTaskDB.getRecords());  
        moListGridTaskDB.addRecordClickHandler(new RecordClickHandler() {
            public void onRecordClick(RecordClickEvent poEvent) {
                
                  String XMLString = poEvent.getRecord().getAttribute("xml_data");
                  
                  
                  
                    if (XMLString.equals("")) 
                    {
                        Alert.show("Celda Vacia");
                    } 
                    else 
                    {
                        //Alert.show("ID Tarea  - For XML: " + XMLTaskId);
                        moTaskGrid.populateFromString(XMLString);
                        moCheckShared.setValue(Boolean.parseBoolean(poEvent.getRecord().getAttribute("is_shared")));
                        moCheckStatus.setValue(Boolean.parseBoolean(poEvent.getRecord().getAttribute("status")));
                        moTextDescription.setValue(poEvent.getRecord().getAttribute("descripcion"));
                        moTextIdTask.setValue(poEvent.getRecord().getAttribute("id_tarea"));
                        moTextNameTask.setValue(poEvent.getRecord().getAttribute("nombre"));

                    }
                  
                  
            }
        });
      
        
       RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
        loRDBA.executeDBRequest(new SQLQuery("SELECT task_id as id_tarea, task_name as nombre, task_desc as descripcion, user_id as usuario, is_shared, status, xml_data FROM it_snc_cat_task WHERE user_id = '"+ moUser +"';","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {
            @Override
            public void onSuccessAction(DBResponse poResponse) {
                //printLOG("N",psStore);
               
               if(poResponse.getResultAsString().equals(""))
               {
                  // Alert.show("Esta Vacio :v");
               }
               else
               {
                    
                    populateGrid(poResponse,moListGridTaskDB);
                    moListGridTaskDB.hideField("is_shared");
                   
               }
                
               
            }
            @Override
            public void onFailureAction(String psMessage) {
                manageEndOfCall();
                Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
            }
        });
        
        
        
        HTMLFlow lohtmlFlow = new HTMLFlow();
        lohtmlFlow.setTop(40);
        lohtmlFlow.setWidth(280);
        lohtmlFlow.setStyleName("BR");
        lohtmlFlow.setContents("<br><br><p> Tareas : <p>");

        loGridContent.addMember(loBtn);
        loGridContent.addMember(lohtmlFlow);
        loGridContent.addMember(TaskToolStrip);
        loGridContent.addMember(moListGridTaskDB);
        loPanel.add(loGridContent);
        
        return loForm;    
    }
    public static class Factory implements SolutionFactory {
        public Canvas create(SolutionHandler poSolutionHandler) {
            return new TaskEditor(poSolutionHandler);
        }
    }
    public TaskEditor(SolutionHandler poSolutionHander){
        buildLayout(poSolutionHander);
    }
    public void buildLayout(SolutionHandler poSolutionHandler){
        
        maXMLConfigData = poSolutionHandler.getXMLConfigDataArray();
        moDOMData = XMLParser.parse(maXMLConfigData[0]);
        moHeader = new ReportHeader(poSolutionHandler.getTitle(), poSolutionHandler.getDepartmentIcon());
        moHeader.setWidth100();
        getHeaderButtons();
        if(maHeaderButtons != null)moHeader.addButtons(maHeaderButtons);
        addMember(moHeader);
        miLast = 9999;
        ToolStripButton loAddDetail = new ToolStripButton("Detalle","e3/ui/templates/options.png");
        ToolStripButton loAddRowBtn = new ToolStripButton("Agregar", "e3/ui/templates/add_record.png");  
        //ToolStripButton tmp =  new ToolStripButton("OK");
        loAddRowBtn.setAutoFit(true); 
        loAddDetail.setAutoFit(true);
       
       //*** CONTROLES Tareas
        moTextIdTask =  new TextItem("IdTask","Id_Tarea");
        moTextIdTask.setAttribute("readOnly", true);
        moTextIdTask.setWidth(50);
        moTextIdTask.setValue("");
        //moTextIdTask.setWidth("100px");
        moTextNameTask = new TextItem("NameTask","Nombre");
        moTextNameTask.setValue("");
        moTextNameTask.setWidth(95);
        moTextDescription = new TextAreaItem();  
        moTextDescription.setName("DescriptionTask");  
        moTextDescription.setTitle("Descripcion");  
        moTextDescription.setWidth(90);  
        moTextDescription.setHeight(20);
        moCheckShared = new CheckboxItem("IsShared","Compartido");
        moCheckShared.setWidth(5);
        moCheckStatus = new CheckboxItem("Status","Status");
        moCheckStatus.setWidth(5);
        //moTextOther = new TextItem("TextOther","Otro");
      
        
        
        moTypeCmb = new SelectItem("type");  
        moTypeCmb.setTitle("Tipo");  
        
        LinkedHashMap<String,String> loCmbValues = new LinkedHashMap<String,String>();
        loCmbValues.put("cmd","<table><tr style='font-size:10px'><td><img src='images/e3/ui/sync/cmd.png' width='15px'/></td><td>Comando</td></tr></table>");
        loCmbValues.put("send","<table><tr style='font-size:10px'><td><img src='images/e3/ui/sync/send.png' width='15px'/></td><td>Enviar</td></tr></table>");
        loCmbValues.put("receive","<table><tr style='font-size:10px'><td><img src='images/e3/ui/sync/receive.png' width='15px'/></td><td>Recibir</td></tr></table>");
        loCmbValues.put("local_cmd","<table><tr style='font-size:10px'><td><img src='images/e3/ui/sync/cmd.png' width='15px'/></td><td>Comando  Local</td></tr></table>");
        
        
        
        moTypeCmb.setValueMap(loCmbValues);       
        moTypeCmb.setDefaultValue("cmd");
 
        ToolStrip TaskToolStrip = new ToolStrip();  
        TaskToolStrip.setWidth100();  
        TaskToolStrip.addFill();
        
        TaskToolStrip.addFormItem(moTextIdTask);
        TaskToolStrip.addFormItem(moTextNameTask);
        TaskToolStrip.addFormItem(moTextDescription);
        TaskToolStrip.addFormItem(moCheckShared);
        TaskToolStrip.addFormItem(moCheckStatus);
        //TaskToolStrip.addFormItem(moTextOther);
        
        //TaskToolStrip.addFormItem(moTextOther);
        TaskToolStrip.addSeparator();
        TaskToolStrip.addFormItem(moTypeCmb);  
        TaskToolStrip.addSeparator();
        TaskToolStrip.addButton(loAddDetail);
        TaskToolStrip.addButton(loAddRowBtn);
        //TaskToolStrip.addButton(tmp);
        
     
        
        
        
        
       
        moTaskGrid = new TaskTreeGrid("Tarea", poSolutionHandler.buildSQLQuery("SELECT xml_data FROM it_grl_fn_tree_sync_task_xml_config() ORDER BY sorter"));
        //moTaskGrid.setFolderIcon("e3/ui/sync/pointer.png");
        moTaskGrid.setNodeIcon("e3/ui/sync/pointer.png");
        //loTaskGrid.setCanReorderFields(false);
        moTaskGrid.setCanReparentNodes(true);
        moTaskGrid.setCanReorderRecords(true);
        moTaskGrid.setAutoFetchData(true);
        moTaskGrid.setCanResizeFields(false);
        moTaskGrid.setShowHeader(false);
        moTaskGrid.addCellClickHandler(new CellClickHandler(){
            public void onCellClick(final CellClickEvent poEvent) {
                String lsColName = moTaskGrid.getFieldName(poEvent.getColNum());
                if(lsColName.equals("eliminar")){
                     BooleanCallback loCallBack = new BooleanCallback() {
                        public void execute(Boolean pbValue) {
                            if (pbValue != null && pbValue) {
                                moTaskGrid.removeData(poEvent.getRecord());
                            } 
                        }
                    };
                    SC.ask("�Est&aacute;s seguro que deseas borrar el nodo? Ten en cuenta que se borrar&aacute; todos los nodos hijo en caso de tenerlos", loCallBack);
                }
                
            }
        });
        /*tmp.addClickHandler(new ClickHandler() {

            public void onClick(ClickEvent event) {
                
                
                moTextOther.setValue(moTaskGrid.getData().getRootValue());
            }
        });*/
        moTaskGrid.setCanAcceptDroppedRecords(true);
         loAddRowBtn.addClickHandler(new ClickHandler() {
            public void onClick(ClickEvent poEvent) {
               
              if(moTaskGrid.getSelectedRecord() == null){
                  SC.say("Por favor selecciona un nodo");
              }
              else{
                  
                  /*TreeNode loNode =  new TreeNode();

                    loNode.setAttribute("option_id",1);
                    loNode.setAttribute("parent_id","");
                    loNode.setAttribute("level_id","0");
                    loNode.setAttribute("tipo",moTypeCmb.getValueAsString());
                    loNode.setAttribute("fuente","");
                    loNode.setAttribute("destino","");
                    loNode.setAttribute("eliminar","cancel");

                    moTaskGrid.getData().add(loNode, moTaskGrid.getSelectedNode());
                */
                  
                int loTreeSize = moTaskGrid.getData().getAllNodes().length;  
                int loParent = Integer.parseInt(moTaskGrid.getSelectedNode().getAttribute("option_id"));
                TreeNode loNode = new TreeNode();
                
                //loNode.setAttribute("option_id", Integer.toString(miLast));
                loNode.setAttribute("option_id", loTreeSize + 1);
                loNode.setAttribute("parent_id",loParent);
                loNode.setAttribute("level_id","0");
                loNode.setAttribute("tipo",moTypeCmb.getValueAsString());
                loNode.setAttribute("fuente","");
                loNode.setAttribute("destino","");
                loNode.setAttribute("eliminar","cancel");
                moTaskGrid.getData().add(loNode, moTaskGrid.getSelectedNode());
                
                
                miLast++;
              }
              
              
            }
        });
        loAddDetail.addClickHandler(new ClickHandler() 
         {
            public void onClick(ClickEvent event) {
               //Alert.show("Agregar Detalle");
               
                ToolStrip loTaskToolStrip = new ToolStrip();  
                loTaskToolStrip.setWidth100();  
                loTaskToolStrip.addFill();
                
                final TextItem loTxtNameDetail =  new TextItem("txtNameDetail","Detalle");
                loTaskToolStrip.addFormItem(loTxtNameDetail);
                
                /*final SelectItem loTypeCmb = new SelectItem("type");  
                loTypeCmb.setTitle("Tipo");  */
        
                moCmbValues = new LinkedHashMap<String,String>();
                moCmbValues.put("text","<table><tr style='font-size:10px'><td><img src='images/e3/ui/templates/edited.png' width='15px'/></td><td>Texto</td></tr></table>");
                moCmbValues.put("date","<table><tr style='font-size:10px'><td><img src='images/e3/ui/schedule/calendar.png' width='15px'/></td><td>Fecha</td></tr></table>");
                moCmbValues.put("integer","<table><tr style='font-size:10px'><td><img src='images/e3/ui/templates/edited.png' width='15px'/></td><td>Entero</td></tr></table>");
                
                //loTypeCmb.setValueMap(loCmbValues);
                //loTypeCmb.setDefaultValue("text");               
                //loTaskToolStrip.addFormItem(loTypeCmb);
                
                ToolStripButton loFilterBtn = new ToolStripButton("", "e3/ui/templates/filter.gif");
                loFilterBtn.setAutoFit(true);
                loFilterBtn.addClickHandler(new ClickHandler() {
                    public void onClick(ClickEvent event) {
                       RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                       loRDBA.executeDBRequest(new SQLQuery("SELECT detail_id as id_detalle,detail_name as detalle,type_detail as tipo_detalle FROM it_snc_cat_task_detail WHERE  detail_name LIKE  '%"+ loTxtNameDetail.getValueAsString() +"%' AND task_id  = "+ moTextIdTask.getValueAsString() +";","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {
                            @Override
                            public void onSuccessAction(DBResponse poResponse) {
                                //printLOG("N",psStore);

                               if(poResponse.getResultAsString().equals(""))
                               {

                               }
                               else
                               {

                                    populateGrid(poResponse,moListTaskDetail);
                                    moListTaskDetail.getField("tipo_detalle").setValueMap(moCmbValues);
                                    moListTaskDetail.getField("id_detalle").setCanEdit(false);
                                    loTxtNameDetail.setValue("");
                               }


                               }
                               @Override
                               public void onFailureAction(String psMessage) {
                                    manageEndOfCall();
                                    Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                               }
                        });
                    }
                });
                ToolStripButton loFilterCancelBtn = new ToolStripButton("", "e3/ui/templates/filter_x.gif");
                loFilterCancelBtn.setAutoFit(true);
                loFilterCancelBtn.addClickHandler(new ClickHandler() {
                    public void onClick(ClickEvent event) {
                       clearGrid();
                       loTxtNameDetail.setValue("");
                    }
                });
                ToolStripButton loSaveBtn = new ToolStripButton("Guardar", "e3/ui/templates/save.png");
                loSaveBtn.setAutoFit(true);
                loSaveBtn.addClickHandler(new ClickHandler() {
                    public void onClick(ClickEvent event) {
                         
                      
                        for (int lii = 0; lii < moListTaskDetail.getRecords().length; lii++) 
                        {
                              
                            
                            if(moListTaskDetail.getRecord(lii).getAttribute("id_detalle") == null)
                            {
                                //int liRows =  moListTaskDetail.getRecords().length;
                                String lsDataDetail = moListTaskDetail.getRecord(lii).getAttributeAsString("detalle");
                                String lsDataType  = moListTaskDetail.getRecord(lii).getAttributeAsString("tipo_detalle");
                                //Alert.show("Size:" + String.valueOf(liRows) + "DATA: " + lsDataDetail + lsDataType);
                                RemoteDBAccess loRequest = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                                          loRequest.executeDBRequest(new SQLDMLBatch("INSERT INTO it_snc_cat_task_detail (task_id, detail_name, type_detail) VALUES ("+ moTextIdTask.getValueAsString()+",'"+lsDataDetail+"','"+lsDataType+"');", "jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {   
                                              @Override
                                              public void onSuccessAction(DBResponse poValue) {
                                                  manageEndOfCall();
                                                  // moType = "UPDATE";
                                                  clearGrid();
                                              }   
                                              @Override
                                              public void onFailureAction(String psMessage) {
                                                  manageEndOfCall();
                                                  Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                                              }    
                                          });
                            }
                            else if(!moListTaskDetail.getRecord(lii).getAttribute("id_detalle").equals(""))
                            {
                                String lsDataDetail = moListTaskDetail.getRecord(lii).getAttributeAsString("detalle");
                                String lsDataType  = moListTaskDetail.getRecord(lii).getAttributeAsString("tipo_detalle");
                                //Alert.show("Size:" + String.valueOf(liRows) + "DATA: " + lsDataDetail + lsDataType);
                                RemoteDBAccess loRequest = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                                          loRequest.executeDBRequest(new SQLDMLBatch("UPDATE it_snc_cat_task_detail SET detail_name='"+ lsDataDetail +"', type_detail='"+ lsDataType +"' WHERE  detail_id = "+ moListTaskDetail.getRecord(lii).getAttribute("id_detalle")+";", "jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {   
                                              @Override
                                              public void onSuccessAction(DBResponse poValue) {
                                                  manageEndOfCall();
                                                  // moType = "UPDATE";
                                                  clearGrid();
                                              }   
                                              @Override
                                              public void onFailureAction(String psMessage) {
                                                  manageEndOfCall();
                                                  Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                                              }    
                                          });
                            }
                            else
                            {}
                        }
                       
                    };
                });
                ToolStripButton loDeleteBtn = new ToolStripButton("Eliminar", "e3/ui/templates/delete.png");
                loDeleteBtn.setAutoFit(true);
                loDeleteBtn.addClickHandler(new ClickHandler() {
                    public void onClick(ClickEvent event) {
                        RemoteDBAccess loRequest = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                                    loRequest.executeDBRequest(new SQLDMLBatch(" DELETE FROM it_snc_cat_task_detail WHERE detail_id = "+ moListTaskDetail.getSelectedRecord().getAttribute("id_detalle") +";", "jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {   
                                        @Override
                                        public void onSuccessAction(DBResponse poValue) {
                                            //manageEndOfCall();
                                            //clearGrid();
                                            moListTaskDetail.removeSelectedData();
                                        }   
                                        @Override
                                        public void onFailureAction(String psMessage) {
                                            manageEndOfCall();
                                            Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                                        }    
                                    });
                        
                        
                       
                    }
                });
                final ToolStripButton loAddNewBtn = new ToolStripButton("Agregar", "e3/ui/templates/add.png");
                loAddNewBtn.setAutoFit(true);
                loAddNewBtn.addClickHandler(new ClickHandler() {
                    public void onClick(ClickEvent event) {
                      
                     
                      if(moListTaskDetail.getRecords().length == 0)
                      {
                          ListGridField loFieldIdDetail =  new ListGridField("id_detalle","id_detalle");
                          ListGridField loFieldDetail =  new ListGridField("detalle","detalle");
                          ListGridField loFieldTypeDetail =  new ListGridField("tipo_detalle","tipo_detalle");
                          loFieldTypeDetail.setValueMap(moCmbValues);
                          moListTaskDetail.setFields(loFieldIdDetail,loFieldDetail,loFieldTypeDetail);
                          moListTaskDetail.getField("id_detalle").setCanEdit(false);
                          moListTaskDetail.startEditingNew();
                          
                          
                      }
                      else
                      {
                           moListTaskDetail.startEditingNew();
                      }
                     
                    }
                });
                /*loTaskToolStrip.addButton(loFilterBtn);
                loTaskToolStrip.addButton(loFilterCancelBtn);*/
                loTaskToolStrip.addButton(loFilterBtn);
                loTaskToolStrip.addButton(loFilterCancelBtn);
                loTaskToolStrip.addButton(loAddNewBtn);
                loTaskToolStrip.addButton(loSaveBtn);
                loTaskToolStrip.addButton(loDeleteBtn);
                moListTaskDetail = new ListGrid();
                moListTaskDetail.setCanEdit(true);
                moListTaskDetail.setAutoFetchData(true);
                //moListTaskDetail.setCanRemoveRecords(true);
                moListTaskDetail.setWidth(300);
                moListTaskDetail.setHeight(400); 
                moListTaskDetail.setShowAllRecords(true);  
                moListTaskDetail.setSelectionType(SelectionStyle.SINGLE);
                moListTaskDetail.setData(moListTaskDetail.getRecords());  
                moListTaskDetail.addRecordClickHandler(new RecordClickHandler() {
                    public void onRecordClick(RecordClickEvent poEvent) {

                        msIdDetail =   poEvent.getRecord().getAttribute("id_detalle");
                        //loTxtNameDetail.setValue(lsIdDetail);
                       // poEvent.getRecord().setAttribute("accion","U");
                        
                    }
                });
               
                
                final Window lowindow = new Window();
                lowindow.setWidth(400);
                lowindow.setHeight(400);
                lowindow.setTitle("Detalle");  
                lowindow.setAutoSize(true);  
                lowindow.setCanDragReposition(true);  
                lowindow.setCanDragResize(true);
                lowindow.centerInPage();
                lowindow.addCloseClickHandler(new CloseClickHandler() {
                   public void onCloseClick(CloseClientEvent event) {
                       lowindow.hide();
                   }
                });
                lowindow.addItem(loTaskToolStrip);
                lowindow.addItem(moListTaskDetail);
                RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                loRDBA.executeDBRequest(new SQLQuery("SELECT detail_id as id_detalle,detail_name as detalle,type_detail as tipo_detalle  FROM it_snc_cat_task_detail WHERE task_id = "+ moTextIdTask.getValue() +";","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {
                    @Override
                    public void onSuccessAction(DBResponse poResponse) {
                        //printLOG("N",psStore);

                       if(poResponse.getResultAsString().equals(""))
                       {
                          
                       }
                       else
                       {

                            populateGrid(poResponse,moListTaskDetail);
                            moListTaskDetail.getField("tipo_detalle").setValueMap(moCmbValues);
                            moListTaskDetail.getField("id_detalle").setCanEdit(false);
                            
                       }


                       }
                        @Override
                        public void onFailureAction(String psMessage) {
                            manageEndOfCall();
                            Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                        }
                });
                /*Canvas locanvasMain = new Canvas();  
                locanvasMain.addChild(lowindow);  
                locanvasMain.draw();  */
                
                lowindow.show();
                    

            }
        });

        addMember(TaskToolStrip);
        addMember(moTaskGrid);
        RemoteDBAccess loRDBAEyum = new RemoteDBAccess("jdbc/eyumDBConnectionPool");             //4510
        loRDBAEyum.executeDBRequest(new SQLQuery("SELECT user_id FROM ss_sec_user_group WHERE user_id='"+  AppHandler.getUserData().getUserId()+"';","jdbc/eyumDBConnectionPool"), new RPCHandler<DBResponse>() {
            @Override
            public void onSuccessAction(DBResponse poResponse) { 
                
             
                if(poResponse.getResult().length == 0)
                {
                    
                }
                else
                {
                  
                    moUser = poResponse.getResultAsString();
                   // Alert.show(moUser);
                }
                //moUser = poResponse.getResult()[0][0];
                //Alert.show(moUser);
            }
            @Override
            public void onFailureAction(String psMessage) {
                Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                manageEndOfCall();
            }
        });
        
        
    }
     protected void getHeaderButtons() {
        if (moDOMData==null) return;
        maHeaderButtons = null;

        try {
            NodeList loHeader = moDOMData.getElementsByTagName("header");
            int liHeadersCount = loHeader.getLength();
            if (liHeadersCount > 0) {
                Element loHeaderElement = ((Element)loHeader.item(0));
                NodeList loButtons = loHeaderElement.getElementsByTagName("button");
                int liQueriesCount = loButtons.getLength();
                maHeaderButtons = new ToolStripButton[liQueriesCount+1];

                if (liQueriesCount > 0) {
                    for (int liNodeIdx = 0; liNodeIdx < liQueriesCount; liNodeIdx++) {
                        Element loQNode = ((Element)loButtons.item(liNodeIdx));
                        final String lsType  = DataUtils.getValidValue(loQNode.getAttribute("type"),"");
                        maHeaderButtons[liNodeIdx] = new ToolStripButton();
                        String lsTitle = DataUtils.getValidValue(DataUtils.getXMLNodeData(loQNode, "title"),"N/A");
                        maHeaderButtons[liNodeIdx].setTitle(lsTitle.equals("")?null:lsTitle);
                        maHeaderButtons[liNodeIdx].setIcon(DataUtils.getValidValue(loQNode.getAttribute("icon"),""));
                        maHeaderButtons[liNodeIdx].setPrompt(DataUtils.getValidValue(DataUtils.getXMLNodeData(loQNode, "tooltip"),""));
                        maHeaderButtons[liNodeIdx].addClickHandler(new ClickHandler() {
                            public void onClick(ClickEvent poEvent) {
                                String psType = lsType.toLowerCase();
                                if (psType.equals("cancel")) 
                                {
                                    moTextIdTask.setValue("");
                                    moTextNameTask.setValue("");
                                    moTextDescription.setValue("");
                                    moCheckShared.setValue(false);
                                    moCheckStatus.setValue(false);
                                    moTaskGrid.populateFromDB();
                                    
                                }
                                else if (psType.equals("delete"))
                                {
                                    RemoteDBAccess loRequest = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                                    loRequest = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                                    loRequest.executeDBRequest(new SQLDMLBatch("DELETE FROM it_snc_cat_task_detail WHERE task_id = "+ moTextIdTask.getValueAsString() +";", "jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {   
                                        @Override
                                        public void onSuccessAction(DBResponse poValue) {
                                            //manageEndOfCall();
                                            //clearTask(); BUGG DE Ha ocurrido un error
                                            //moListTaskDetail.clear();
                                        }   
                                        @Override
                                        public void onFailureAction(String psMessage) {
                                            manageEndOfCall();
                                            Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                                        }    
                                    });
                                    //Alert.show("Eliminar Tarea");
                                    
                                    loRequest.executeDBRequest(new SQLDMLBatch("DELETE FROM  it_snc_cat_task where task_id = "+ moTextIdTask.getValueAsString() +"  and user_id = '"+ AppHandler.getUserData().getUserId() +"';", "jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {   
                                        @Override
                                        public void onSuccessAction(DBResponse poValue) {
                                            manageEndOfCall();
                                            clearTask();
                                        }   
                                        @Override
                                        public void onFailureAction(String psMessage) {
                                            manageEndOfCall();
                                            Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                                        }    
                                    });
                                    
                                   
                                    
                                }
                                if (psType.equals("search")) {
                                    
                                    createFileWindow();
                                    showFileWindow();

                                }
                                else if (psType.equals("save"))
                                {
                                     
                                    String liStatus = "0";
                                    String liShared = "0";
                                         
                                     if (moCheckStatus.getValueAsBoolean() == true) {
                                            liStatus = "1";
                                         }
                                          if (moCheckShared.getValueAsBoolean() == true) {
                                            liShared = "1";
                                     }                                             
                                    
                                   //Alert.show("Guardar Cambios");
                                    
                                   if (moTextNameTask.getValue().equals("")) 
                                   {
                                        Alert.show("Por favor asigne un nombre a su tarea");
                                   } 
                                   else 
                                   {
                                    Structure();
                                     
                                        
                                        Tree loTree =  moTaskGrid.getData();
                                        TreeNode[] loNodeTree =  loTree.getAllNodes();
                                        TreeNode[] loNodeData =  new TreeNode[loNodeTree.length];
                                        String lsParentString ;
                                        String lsOpen="<tree_option",lsClose="</tree_option>",lsFuenteOpen="<fuente><![CDATA[",lsFuenteClose="</fuente>",lsDestinoOpen="<destino>",lsDestinoClose="</destino>";//Cerrar Atributo Open ">"
                                        String lsDefaultParams = " prop1=\"A\" prop2=\"\" prop3=\"\" prop4=\"\" prop5=\"\" prop6=\"U\" prop7=\"Y\" prop8=\"Y\"";
                                        lsXMLString = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><tree_struct><tree_options>";
                                       
                                        //String [][] lsXMLSubmit = new String [loNodeTree.length][2];
                                         for (int lii = 0; lii < loNodeTree.length; lii++)
                                         {
                                            //lsXMLSubmit[lii][1]   ="";
                                            lsXMLString = lsXMLString + lsOpen;
                                            //lsXMLSubmit[lii][1] = lsXMLSubmit[lii][1] +lsOpen;   
                                             loNodeData[lii] = loNodeTree[lii];                             
                                              if (loNodeData[lii].getAttribute("parent_id").equals("null")) 
                                              {
                                                  lsParentString = "";
                                                 
                                              }
                                              else
                                              {
                                                  lsParentString = loNodeData[lii].getAttribute("parent_id");
                                                  
                                              }
                                             //lsXMLSubmit[lii][2] =  loNodeData[lii].getAttribute("option_id");
                                             lsXMLString = lsXMLString + " eliminar=\"" + loNodeData[lii].getAttribute("eliminar") +"\""+ " option_id=\""+ loNodeData[lii].getAttribute("option_id") +"\"" + " parent_id=\""+ lsParentString +"\""+ lsDefaultParams + " sorter=\""+ String.valueOf(lii+1) +"\"" + " tipo=\""+ loNodeData[lii].getAttribute("tipo") +"\"" + ">";
                                             //lsXMLSubmit[lii][1] = lsXMLSubmit[lii][1] + " eliminar=\"" + loNodeData[lii].getAttribute("eliminar") +"\""+ " option_id=\""+ loNodeData[lii].getAttribute("option_id") +"\"" + " parent_id=\""+ lsParentString +"\""+ lsDefaultParams + " sorter=\""+ String.valueOf(lii+1) +"\"" + " tipo=\""+ loNodeData[lii].getAttribute("tipo") +"\"" + ">";
                                             lsXMLString = lsXMLString + lsFuenteOpen + loNodeData[lii].getAttribute("fuente") +"]]>" + lsFuenteClose;
                                              //lsXMLSubmit[lii][1] = lsXMLSubmit[lii][1]  + lsFuenteOpen + loNodeData[lii].getAttribute("fuente") +"]]>" + lsFuenteClose;
                                             if(loNodeData[lii].getAttribute("tipo").equals("send") || loNodeData[lii].getAttribute("tipo").equals("receive"))
                                             {
                                                  
                                                  lsXMLString = lsXMLString + lsDestinoOpen +"<![CDATA[" + loNodeData[lii].getAttribute("destino") + "]]>" + lsDestinoClose;
                                                //  lsXMLSubmit[lii][1] = lsXMLSubmit[lii][1] + lsDestinoOpen +"<![CDATA[" + loNodeData[lii].getAttribute("destino") + "]]>" + lsDestinoClose;
                                             }
                                             else
                                             {
                                                 
                                                 lsXMLString = lsXMLString + lsDestinoOpen +lsDestinoClose;
                                                 //lsXMLSubmit[lii][1] = lsXMLSubmit[lii][1] + lsDestinoOpen +lsDestinoClose;
                                             }
                                            lsXMLString = lsXMLString + lsClose;
                                             //lsXMLSubmit[lii][1] = lsXMLSubmit[lii][1] + lsClose;
                                         }
                                         
                                         lsXMLString = lsXMLString + "</tree_options></tree_struct>";
                                       
                                      /*  Tree t = new Tree();
                                        t.setData(moTaskGrid.getData().getAllNodes());
                                        moTaskGrid.setData(t);
                                        
                                      Document loDOMData;
                                       loDOMData = XMLParser.parse(moTaskGrid.getXMLData());
                                    
                                       NodeList loNodeList = loDOMData.getElementsByTagName("tree_options");

                                       String loData = "";
                                        for (int i = 0; i < loNodeList.getLength(); i++) 
                                        {
                                             Element loElement = (Element)loNodeList.item(i);
                                             loData = loData + loElement.toString();
                                              
                                        }

                                        tmp.setValue(loData);
                                        //lsXMLString = loData; 
                                        //moTextDescription.setValue(lsXMLString);*/
                                         
                                         //moTextOther.setValue(lsXMLString);
                                         if(moTextIdTask.getValue().equals("")) 
                                         {
                                             //Alert.show("Ser� un insert");
                                               RemoteDBAccess loRequest = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                                                                 loRequest.executeDBRequest(new SQLDMLBatch("INSERT INTO it_snc_cat_task (task_name, task_desc, user_id, is_shared, status, xml_data) VALUES ('"+ moTextNameTask.getValue() +"','"+ moTextDescription.getValue()+"','"+ moUser +"','"+ liShared +"','"+ liStatus +"','"+ lsXMLString +"');", "jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {   
                                                                     @Override
                                                                     public void onSuccessAction(DBResponse poValue) {
                                                                         manageEndOfCall();
                                                                         clearTask();
                                                                     }   
                                                                     @Override
                                                                     public void onFailureAction(String psMessage) {
                                                                         manageEndOfCall();
                                                                         Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                                                                     }    
                                                                 });
                                        } 
                                        else 
                                        {
                                            //Alert.show("ser� un UPDATE");

                                             RemoteDBAccess loRequest = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                                                                loRequest.executeDBRequest(new SQLDMLBatch("UPDATE it_snc_cat_task SET task_name='"+ moTextNameTask.getValue() +"', task_desc='"+ moTextDescription.getValue() +"', user_id='"+ moUser +"', is_shared='"+ liShared +"', status='"+ liStatus +"', xml_data='"+ lsXMLString +"' WHERE task_id='"+ moTextIdTask.getValue() +"';", "jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {   
                                                                    @Override
                                                                    public void onSuccessAction(DBResponse poValue) {
                                                                       // manageEndOfCall();
                                                                        clearTask();
                                                                    }   
                                                                    @Override
                                                                    public void onFailureAction(String psMessage) {
                                                                        manageEndOfCall();
                                                                        Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                                                                    }    
                                                                });
                                             /*for (int i = 0; i < lsXMLSubmit.length; i++) {
                                                loRequest.executeDBRequest(new SQLDMLBatch("UPDATE it_snc_execute_submit SET command = '"+ lsXMLSubmit[i][1] +"' WHERE task_id = 1 AND row_task_id = "+ lsXMLSubmit[i][2] +";", "jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {   
                                                                    @Override
                                                                    public void onSuccessAction(DBResponse poValue) {
                                                                        manageEndOfCall();
                                                                        //clearTask();
                                                                    }   
                                                                    @Override
                                                                    public void onFailureAction(String psMessage) {
                                                                        manageEndOfCall();
                                                                        Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                                                                    }    
                                                                });
                                            }*/
                                                
                                        }
                                  }
                                   
                                }
                                else if(psType.equals("new"))
                                {
                                    //Alert.show("Nueva Tarea");
                                    
                                    moTextIdTask.setValue("");
                                    moTextNameTask.setValue("");
                                    moTextDescription.setValue("");
                                    moCheckShared.setValue(false);
                                    moCheckStatus.setValue(false);
                                    
                                    moTaskGrid.populateFromString("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n" +
                                                                    "<tree_struct>\n" +
                                                                    "  <tree_options>\n" +
                                                                    "    <tree_option eliminar=\"cancel\" option_id=\"1\" parent_id=\"\" prop1=\"A\" prop2=\"\" prop3=\"\" prop4=\"\" prop5=\"\" prop6=\"U\" prop7=\"Y\" prop8=\"Y\" sorter=\"1\" tipo=\""+ moTypeCmb.getValueAsString() +"\">\n" +
                                                                    "      <fuente><![CDATA[]]></fuente>\n" +
                                                                    "      <destino><![CDATA[]]></destino>\n" +
                                                                    "    </tree_option>\n" +
                                                                    "  </tree_options>\n" +
                                                                    "</tree_struct>"); 
                                    
                                }
                                else
                                {}
                                    
                                    
                                    
                            };
                        });

                        maHeaderButtons[liNodeIdx].setAutoFit(true);
                        maHeaderButtons[liNodeIdx].setAlign(Alignment.CENTER);
                    }
                }
                maHeaderButtons[liQueriesCount] = new ToolStripButton();
                maHeaderButtons[liQueriesCount].setTitle("No se ha seleccionado tarea");
                maHeaderButtons[liQueriesCount].setIcon("e3/ui/templates/edit.png");
                maHeaderButtons[liQueriesCount].setVisible(false);
            } 
        } catch(Exception poException) {
           maHeaderButtons = null;
        } 
      }
     
     
    private void showFileWindow(){
        moFileWindow.show();
    }
     
    private void hideFileWindow(){
        moFileWindow.hide();
    }
    
    public void createFileWindow(){
        System.out.println("\nCreando ventana...\n");
        moFileWindow = new Window();
        moFileWindow.setShowMinimizeButton(false);
        moFileWindow.setAutoCenter(true);
        moFileWindow.setCanDragReposition(true);
        moFileWindow.setCanDragResize(false);
        
       
        moBrand = new DynamicComboBoxItem();
        moFlag = 0;
        
        final FormPanel loFinalForm = drawForm();
        loFinalForm.setPixelSize(350,30);
        
        //final IButton loButton = new IButton("Cargar");
        //loButton.setIcon("e3/ui/customercare/upload.png");
        //loButton.setLayoutAlign(Alignment.CENTER);
        
        
        
        moFileWindow.addItem(loFinalForm);
       
       // moFileWindow.addItem(loButton); 
        moFileWindow.setTitle("Cargar Tarea");  
        moFileWindow.setWidth(560);  
        moFileWindow.setHeight(445);
       
        addChild(moFileWindow);
       /* loButton.addClickHandler(new ClickHandler() {
            public void onClick(ClickEvent event) {
               loFinalForm.submit();
            }
        }); */
        hideFileWindow();
        System.gc();
    }
    
    public class TaskTreeGrid extends XMLTree{
       public TaskTreeGrid(String psTitle, SQLQuery poSQLQuery) {
            super(psTitle,poSQLQuery, "", "");
       }

        @Override
        protected  void defineAttributes() {
            moAttributes.add("option_id");
            moAttributes.add("parent_id");
            moAttributes.add("level_id");
            moAttributes.add("tipo");
            moAttributes.add("fuente");
            moAttributes.add("destino");
            moAttributes.add("eliminar");
            
            
        }

        @Override
        protected void setCustomPropertiesBeforeRender() {
            //setWrapCells(true);
            setCellHeight(28);
            
            TreeGridField loType = new TreeGridField("tipo",30);
            loType.setType(ListGridFieldType.IMAGE);
            loType.setImageURLPrefix("e3/ui/sync/");
            loType.setImageURLSuffix(".png");
            TreeGridField loSrc = new TreeGridField("fuente", 500);
            loSrc.setEditorType(new TextAreaItem());
            loSrc.setCanEdit(true);
            TreeGridField loDst = new TreeGridField("destino", 300);
            loDst.setCanEdit(true);
            TreeGridField loDel = new TreeGridField("eliminar",50);
            loDel.setType(ListGridFieldType.IMAGE);
            loDel.setImageURLPrefix("e3/ui/templates/");
            loDel.setImageURLSuffix(".png");
            
            
            
             setFields(moHeaderField,loType,loSrc,loDst,loDel);
        }
       
    
        @Override
        protected void onAfterPopulateAction(){
            setAllAsFolder(getData().getChildren(getData().getRoot()));
            getData().openAll();
        }

        private void setAllAsFolder(TreeNode poTreeNodes[]){
            for (int li=0;li<poTreeNodes.length;li++){
                poTreeNodes[li].setIsFolder(true);
                //poTreeNodes[li].setCanDrag(false);
            }
        }

        @Override
        public void populateFromDB(SQLQuery poSQLQuery) {
            setSQLQuery(poSQLQuery);
            RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
            moRPCHandler = new RPCHandler<DBResponse>() {
                @Override
                public void onSuccessAction(DBResponse poResponse) {
                    moRPCHandler.setCanShowWaitWindow(false);
                    refreshData(poResponse.getResultAsString(0));
                    onAfterPopulateAction();
                }
                @Override
                public void onFailureAction(String psMessage) {
                    Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                }
            };
            loRDBA.setCanShowWaitWindow(false);
            moRPCHandler.setCanShowWaitWindow(false);
            loRDBA.executeDBRequest(poSQLQuery, moRPCHandler);
        }

    }
    
    
    public void populateGrid(DBResponse poResponse,ListGrid loLisGrid){
        ListGridField laQueryFields[] = null;
        laQueryFields = poResponse.getFieldsAsLGF();
        loLisGrid.setFields(laQueryFields);
        loLisGrid.setData(getGridData(poResponse,laQueryFields));
        //mbHasSeenPreview=true;
    }
    public ListGridRecord[] getGridData(DBResponse poResponse,ListGridField[] paGridFields) {
        String [][] laRawData = poResponse.getResult();
        ListGridRecord[] laGridData  = new ListGridRecord[laRawData.length];
        
        for (int liRecIndex = 0; liRecIndex <  laRawData.length; liRecIndex++) {
            laGridData[liRecIndex] = new ListGridRecord();
            for (int liFieldIndex = 0; liFieldIndex < laRawData[0].length; liFieldIndex++) {
                String lsFieldName = paGridFields[liFieldIndex].getName();
                laGridData[liRecIndex].setAttribute(lsFieldName, laRawData[liRecIndex][liFieldIndex]);
            }
        }
        return laGridData;
    }
    
    public void clearTask()
    {
        // Alert.show("Nueva Tarea");
                                    
                                    moTextIdTask.setValue("");
                                    moTextNameTask.setValue("");
                                    moTextDescription.setValue("");
                                    moCheckShared.setValue(false);
                                    moCheckStatus.setValue(false);
                                    
                                    moTaskGrid.populateFromString("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n" +
                                                                    "<tree_struct>\n" +
                                                                    "  <tree_options>\n" +
                                                                    "    <tree_option eliminar=\"cancel\" option_id=\"1\" parent_id=\"\" prop1=\"A\" prop2=\"\" prop3=\"\" prop4=\"\" prop5=\"\" prop6=\"U\" prop7=\"Y\" prop8=\"Y\" sorter=\"1\" tipo=\""+ moTypeCmb.getValueAsString() +"\">\n" +
                                                                    "      <fuente><![CDATA[]]></fuente>\n" +
                                                                    "      <destino><![CDATA[]]></destino>\n" +
                                                                    "    </tree_option>\n" +
                                                                    "  </tree_options>\n" +
                                                                    "</tree_struct>"); 
    }
    public void DeleteXmlRequest()
    {
        RemoteDBAccess loRequest = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                            loRequest.executeDBRequest(new SQLDMLBatch("DELETE FROM it_snc_cat_request_xml_task;", "jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {   
                                    @Override
                                    public void onSuccessAction(DBResponse poValue) {
                                        manageEndOfCall();
                                        //clearTask();
                                    }   
                                    @Override
                                    public void onFailureAction(String psMessage) {
                                        manageEndOfCall();
                                        Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                                    }    
       });
    }
    public void clearGrid()
    {
        RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                loRDBA.executeDBRequest(new SQLQuery("SELECT detail_id as id_detalle,detail_name as detalle,type_detail as tipo_detalle FROM it_snc_cat_task_detail WHERE task_id = "+ moTextIdTask.getValue() +";","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {
                    @Override
                    public void onSuccessAction(DBResponse poResponse) {
                        //printLOG("N",psStore);

                       if(poResponse.getResultAsString().equals(""))
                       {
                          
                       }
                       else
                       {

                            populateGrid(poResponse,moListTaskDetail);
                            moListTaskDetail.getField("tipo_detalle").setValueMap(moCmbValues);
                            //moListTaskDetail.getField("tipo_detalle").setWidth("110px");
                            moListTaskDetail.getField("id_detalle").setCanEdit(false);
                       }


                       }
                        @Override
                        public void onFailureAction(String psMessage) {
                            manageEndOfCall();
                            Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                        }
                });
    }
    public void Structure()
    {
        TreeNode []  loAllNodes = moTaskGrid.getData().getAllNodes();
   
                for (int lii = 0; lii < loAllNodes.length ; lii++) 
                {
                    loAllNodes[lii].setAttribute("option_id",(lii+1));
                    if(moTaskGrid.getData().hasChildren(loAllNodes[lii]) == true)
                    {
                        TreeNode []  loChildNodes = moTaskGrid.getData().getChildren(loAllNodes[lii]);
                       // Alert.show("Tiene Hijos,  son : " + String.valueOf(Ni.length));
                        for(int jii = 0; jii < loChildNodes.length; jii++)
                        {
                            loChildNodes[jii].setAttribute("parent_id", (lii+1));
                        }
                    }
                   
                }
    }
   

}


