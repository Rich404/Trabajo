/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yum.e3.client.development.apps.it.sync;

import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.NodeList;
import com.google.gwt.xml.client.XMLParser;
import com.smartgwt.client.types.Alignment;
import com.smartgwt.client.util.BooleanCallback;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.events.ClickEvent;
import com.smartgwt.client.widgets.events.ClickHandler;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.CheckboxItem;
import com.smartgwt.client.widgets.form.fields.FormItem;
import com.smartgwt.client.widgets.form.fields.TextAreaItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.fields.events.ChangedEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangedHandler;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.toolbar.ToolStripButton;
import yum.e3.client.SolutionFactory;
import yum.e3.client.generals.rpc.RPCHandler;
import yum.e3.client.generals.rpc.RemoteDBAccess;
import yum.e3.client.generals.rpc.data.DBResponse;
import yum.e3.client.generals.rpc.data.SQLDMLBatch;
import yum.e3.client.generals.rpc.data.SQLQuery;
import yum.e3.client.generals.templates.controls.CheckboxItemHandler;
import yum.e3.client.generals.templates.core.ABCRowControl;
import yum.e3.client.generals.templates.core.ReportHeader;
import yum.e3.client.generals.templates.core.SolutionHandler;
import yum.e3.client.generals.templates.ui.DynamicComboBoxItem;
import yum.e3.client.generals.utils.DataUtils;

/**
 *
 * @author DAB1379
 */
public class DBCopy extends VLayout{
    protected String msXMLData;
    protected Document moDOMData;
    protected ReportHeader moHeader;
    private boolean mbHasSeenPreview;
    private ToolStripButton maHeaderButtons[];
    private DynamicComboBoxItem moCmbStoreSrc;
    private DynamicComboBoxItem moCmbDBName;
    private DynamicComboBoxItem moCmbDBTable;
    private DynamicComboBoxItem moCmbStoreDest;
    private TextAreaItem moFilterItem;
    private TextAreaItem moFieldsItem;
    private CheckboxItem moDeleteItem;
    private TextAreaItem moDeleteFilterItem;
    private String maXMLConfigData[];
    private ListGrid moGrid;
      public static class Factory implements SolutionFactory {
        public Canvas create(SolutionHandler poSolutionHandler) {
            return new DBCopy(poSolutionHandler);
        }
    }
    public DBCopy(SolutionHandler poSolutionHander){
        buildLayout(poSolutionHander);
    }
    public void buildLayout(SolutionHandler poSolutionHandler){
        maXMLConfigData = poSolutionHandler.getXMLConfigDataArray();
        moDOMData = XMLParser.parse(maXMLConfigData[0]);
        moHeader = new ReportHeader(poSolutionHandler.getTitle(), poSolutionHandler.getDepartmentIcon());
        moHeader.setWidth100();
        getHeaderButtons();
        if(maHeaderButtons != null)moHeader.addButtons(maHeaderButtons);
        addMember(moHeader);
        DynamicForm loParamForm = new DynamicForm();
        loParamForm.setNumCols(8);
        moCmbStoreSrc = new DynamicComboBoxItem();
        moCmbStoreSrc.setTitle("CC Fuente");
        moCmbStoreSrc.populateFromDB(new SQLQuery("SELECT a.ip||'|'||CAST(a.store_id AS TEXT),b.store_member FROM it_grl_v3_store_control a INNER JOIN ss_org_cat_store b ON a.store_id = b.store_id ORDER BY a.store_id ","jdbc/masterStoreDBConnectionPool"));
        moCmbStoreSrc.setColSpan(1);
        moCmbStoreSrc.addChangedHandler(new ChangedHandler() {
            public void onChanged(ChangedEvent poEvent) {
               fillTableCmb();
               mbHasSeenPreview=false;
            }
        });
        moCmbDBName = new DynamicComboBoxItem();
        moCmbDBName.setTitle("BD");
        moCmbDBName.populateFromDB(new SQLQuery("SELECT 'dbeyum','dbeyum' UNION SELECT 'dbsec','dbsec'"));
        
        
        
        moCmbDBName.addChangedHandler(new ChangedHandler() {
            public void onChanged(ChangedEvent poEvent) {
               fillTableCmb();
               mbHasSeenPreview=false;
            }
        });
        moCmbDBTable = new DynamicComboBoxItem();
        moCmbDBTable.setTitle("Tabla");
        moCmbDBTable.setWidth(400);
        moCmbDBTable.addChangedHandler(new ChangedHandler() {
            public void onChanged(ChangedEvent poEvent) {
               mbHasSeenPreview=false;
            }
        });
        moCmbStoreDest = new DynamicComboBoxItem();
        moCmbStoreDest.setTitle("CC Destino");
        moCmbStoreDest.populateFromDB(new SQLQuery("SELECT a.ip||'|'||CAST(a.store_id AS TEXT),b.store_member FROM it_grl_v3_store_control a INNER JOIN ss_org_cat_store b ON a.store_id = b.store_id ORDER BY a.store_id ","jdbc/masterStoreDBConnectionPool"));
        moFilterItem = new TextAreaItem("Filtro");
        moFieldsItem = new TextAreaItem("Campos");
        moDeleteFilterItem = new TextAreaItem("Filtro_Borrado");
        moDeleteFilterItem.setTitle("Filtro Borrado");
        
        moFilterItem.setColSpan(2);
        moFieldsItem.setColSpan(2);
        moDeleteFilterItem.setColSpan(2);
        moFieldsItem.setDefaultValue("*");
        moDeleteItem = new CheckboxItem();
        moDeleteItem.setTitle("Borrar en destino");
        
        loParamForm.setFields(moCmbStoreSrc,moCmbDBName,moCmbDBTable,moCmbStoreDest,moFilterItem,moFieldsItem,moDeleteItem,moDeleteFilterItem);
        
        moGrid = new ListGrid();
        
        loParamForm.setHeight("20%");
        moGrid.setHeight("80%");
        addMember(loParamForm);
        addMember(moGrid);
        
    }
    private void fillTableCmb(){
        RPCHandler<DBResponse> loRPCHandler = null;
        String lsStoreSrcIP = getComboItemValidValue(moCmbStoreSrc);
        String lsDBStoreName = getComboItemValidValue(moCmbDBName);
        if(!lsStoreSrcIP.equals("") && !lsDBStoreName.equals("")){
               loRPCHandler = new RPCHandler<DBResponse>() {
                public void onSuccessAction(DBResponse poResponse) {
                    moCmbDBTable.finishLoad(poResponse);
                    moCmbDBTable.clearValue();
                }

                public void onFailureAction(String psMessage) {}
            };
            moCmbDBTable.populateFromDB(new SQLQuery("SELECT table_name_out,table_name_out FROM it_grl_sync_get_store_tables('"+lsStoreSrcIP+"'::TEXT,'"+lsDBStoreName+"'::TEXT) ORDER BY 1","jdbc/masterStoreDBConnectionPool"),loRPCHandler);
        } 
        else{
            //SC.warn("Es necesario seleccionar CC Fuente y Base de datos");
        }
    }
    private void cleanValues(){
        moCmbStoreSrc.clearValue();
        moCmbDBName.clearValue();
        moCmbDBTable.clearValue();
        moFilterItem.clearValue();
        moFieldsItem.clearValue();
        moCmbStoreDest.clearValue();
        moFieldsItem.setDefaultValue("*");
        moDeleteItem.clearValue();
        mbHasSeenPreview=false;
        moGrid.setData(new ListGridRecord[]{});
    }
    private void getTablePreview(){
        String lsStoreSrcIP = getComboItemValidValue(moCmbStoreSrc);
        String lsDBStoreName = getComboItemValidValue(moCmbDBName);
        String lsStoreTable = getComboItemValidValue(moCmbDBTable);
        String lsFilter = getTextItemValidValue(moFilterItem);
        String lsField = getTextItemValidValue(moFieldsItem);
        if(lsStoreSrcIP.equals("") || lsStoreTable.equals("") || lsDBStoreName.equals("")){
            SC.warn("Por favor indica CC Fuente, base de datos y la tabla a previsualizar");
        }else{
            RemoteDBAccess loRDBA = new RemoteDBAccess();
            RPCHandler<DBResponse> loRPCHandler = null;
            loRPCHandler = new RPCHandler<DBResponse>() {
                public void onSuccessAction(DBResponse poResponse) {
                    populateGrid(poResponse);
                }
                public void onFailureAction(String psMessage) {}
                };
            loRDBA.executeStoreDynamicDBRequest(new SQLQuery("SELECT "+lsField+" FROM "+lsStoreTable+" "+lsFilter,"jdbc/storeDynamicDBConnectionPool"),lsStoreSrcIP,lsDBStoreName, loRPCHandler);
        }
    }
    private String getTextItemValidValue(TextAreaItem poItem){
        return DataUtils.getValidValue(poItem.getValueAsString(), "");
    }
    private String getComboItemValidValue(DynamicComboBoxItem poItem){
        return DataUtils.getValidValue(poItem.getValueAsString(), "");
    }
    private void populateGrid(DBResponse poResponse){
        ListGridField laQueryFields[] = null;
        laQueryFields = poResponse.getFieldsAsLGF();
        moGrid.setFields(laQueryFields);
        moGrid.setData(getGridData(poResponse,laQueryFields));
        mbHasSeenPreview=true;
    }
    public ListGridRecord[] getGridData(DBResponse poResponse,ListGridField[] paGridFields) {
        String [][] laRawData = poResponse.getResult();
        ListGridRecord[] laGridData  = new ListGridRecord[laRawData.length];
        
        for (int liRecIndex = 0; liRecIndex <  laRawData.length; liRecIndex++) {
            laGridData[liRecIndex] = new ListGridRecord();
            for (int liFieldIndex = 0; liFieldIndex < laRawData[0].length; liFieldIndex++) {
                String lsFieldName = paGridFields[liFieldIndex].getName();
                laGridData[liRecIndex].setAttribute(lsFieldName, laRawData[liRecIndex][liFieldIndex]);
            }
        }
        return laGridData;
    }
    private void copyTable(){
        if(!mbHasSeenPreview){
            SC.warn("Por favor primero consulta la vista previa");
            return;
        }
        
        final String lsStoreSrcIP = getComboItemValidValue(moCmbStoreSrc);
        final String lsStoreDstIP = getComboItemValidValue(moCmbStoreDest);
        final String lsDBStoreName = getComboItemValidValue(moCmbDBName);
        final String lsStoreTable = getComboItemValidValue(moCmbDBTable);
        final String lsFilter = getTextItemValidValue(moFilterItem);
        final String lsField = getTextItemValidValue(moFieldsItem);
        final String lsDeleteFilter = getTextItemValidValue(moDeleteFilterItem);
        final boolean lbDelete = moDeleteItem.getValueAsBoolean();
       
        SC.ask("&iquest;Seguro que deseas copiar "+((lbDelete)?"<font color=red><b>y eliminar</b></font>":"")+" la tabla "+lsDBStoreName+"."+lsStoreTable+" del restaurante ["+moCmbStoreSrc.getSelectedRecord().getAttribute("store_member")+"] al restaurante ["+moCmbStoreDest.getSelectedRecord().getAttribute("store_member")+"]?",  
            new BooleanCallback() {
                public void execute(Boolean pbValue) {
                    RemoteDBAccess loRDBA = new RemoteDBAccess();
                    RPCHandler<DBResponse> loRPCHandler = null;
                    if (pbValue != null && pbValue) {
                        String lsQuery="";
                        String lsFields="";
                        if(lbDelete)lsQuery+="DELETE FROM "+lsStoreTable+" "+lsDeleteFilter+";";
                        lsQuery+="INSERT INTO "+lsStoreTable+"(";
                        for(int li=0;li<moGrid.getFields().length;li++){
                            if(li==moGrid.getFields().length-1){
                                lsQuery+=moGrid.getFields()[li].getName();
                                lsFields+="(rec)."+moGrid.getFields()[li].getName();
                            }else{
                                lsQuery+=moGrid.getFields()[li].getName()+",";
                                lsFields+="(rec)."+moGrid.getFields()[li].getName()+",";
                            }
                        }
                        lsQuery+=")";
                        lsQuery+="SELECT "+lsFields+" FROM dblink('hostaddr="+lsStoreSrcIP+" dbname="+lsDBStoreName+" user=postgres','SELECT a FROM "+lsStoreTable+" a "+lsFilter.replaceAll("'", "''")+"') AS t1(rec "+lsStoreTable+")";
                        loRPCHandler = new RPCHandler<DBResponse>() {
                        public void onSuccessAction(DBResponse poResponse) {
                            SC.say("La copia se realiz&oacute; de forma correcta");
                        }
                        public void onFailureAction(String psMessage) {}
                        };
                        
                        loRDBA.executeStoreDynamicDBRequest(new SQLDMLBatch(lsQuery,"jdbc/storeDynamicDBConnectionPool"),lsStoreDstIP,lsDBStoreName, loRPCHandler);
                    }
                 }
            });
        
        
    }
    protected void getHeaderButtons() {
        if (moDOMData==null) return;
        maHeaderButtons = null;

        try {
            NodeList loHeader = moDOMData.getElementsByTagName("header");
            int liHeadersCount = loHeader.getLength();
            if (liHeadersCount > 0) {
                Element loHeaderElement = ((Element)loHeader.item(0));
                NodeList loButtons = loHeaderElement.getElementsByTagName("button");
                int liQueriesCount = loButtons.getLength();
                maHeaderButtons = new ToolStripButton[liQueriesCount];

                if (liQueriesCount > 0) {
                    for (int liNodeIdx = 0; liNodeIdx < liQueriesCount; liNodeIdx++) {
                        Element loQNode = ((Element)loButtons.item(liNodeIdx));
                        final String lsType  = DataUtils.getValidValue(loQNode.getAttribute("type"),"");
                        maHeaderButtons[liNodeIdx] = new ToolStripButton();
                        String lsTitle = DataUtils.getValidValue(DataUtils.getXMLNodeData(loQNode, "title"),"N/A");
                        maHeaderButtons[liNodeIdx].setTitle(lsTitle.equals("")?null:lsTitle);
                        maHeaderButtons[liNodeIdx].setIcon(DataUtils.getValidValue(loQNode.getAttribute("icon"),""));
                        maHeaderButtons[liNodeIdx].setPrompt(DataUtils.getValidValue(DataUtils.getXMLNodeData(loQNode, "tooltip"),""));
                        maHeaderButtons[liNodeIdx].addClickHandler(new ClickHandler() {
                            public void onClick(ClickEvent poEvent) {
                                String psType = lsType.toLowerCase();
                                if (psType.equals("copy"))copyTable();
                                else if (psType.equals("look"))getTablePreview();
                                else if (psType.equals("delete"))cleanValues();
                            }
                        });

                        maHeaderButtons[liNodeIdx].setAutoFit(true);
                        maHeaderButtons[liNodeIdx].setAlign(Alignment.CENTER);
                    }
                }
                
            } 
        } catch(Exception poException) {
           maHeaderButtons = null;
        } 
      }
     
}
