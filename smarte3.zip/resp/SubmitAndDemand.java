/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yum.e3.client.development.apps.it.sync;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.i18n.client.impl.cldr.DateTimeFormatInfoImpl_es;
import com.google.gwt.user.client.Cookies;
import com.google.gwt.user.client.ui.FormPanel;
import com.google.gwt.user.client.ui.IsWidget;
import com.google.gwt.xml.client.CDATASection;
import com.google.gwt.xml.client.Comment;
import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.DocumentFragment;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.NamedNodeMap;
import com.google.gwt.xml.client.Node;
import com.google.gwt.xml.client.NodeList;
import com.google.gwt.xml.client.ProcessingInstruction;
import com.google.gwt.xml.client.Text;
import com.google.gwt.xml.client.XMLParser;
import com.smartgwt.client.data.DataSource;
import com.smartgwt.client.types.Encoding;
import com.smartgwt.client.types.FieldType;
import com.smartgwt.client.types.FormMethod;
import com.smartgwt.client.types.ListGridFieldType;
import com.smartgwt.client.types.SelectionStyle;
import com.smartgwt.client.types.Side;
import com.smartgwt.client.types.SortDirection;
import com.smartgwt.client.util.SC;
import com.smartgwt.client.widgets.Button;
import com.smartgwt.client.widgets.Canvas;
import com.smartgwt.client.widgets.Dialog;
import com.smartgwt.client.widgets.HTMLPane;
import com.smartgwt.client.widgets.IButton;
import com.smartgwt.client.widgets.Img;
import com.smartgwt.client.widgets.Label;
import com.smartgwt.client.widgets.Window;
import com.smartgwt.client.widgets.events.CloseClickHandler;
import com.smartgwt.client.widgets.events.CloseClientEvent;
import com.smartgwt.client.widgets.form.DynamicForm;
import com.smartgwt.client.widgets.form.fields.ButtonItem;
import com.smartgwt.client.widgets.form.fields.CheckboxItem;
import com.smartgwt.client.widgets.form.fields.ComboBoxItem;
import com.smartgwt.client.widgets.form.fields.DateItem;
import com.smartgwt.client.widgets.form.fields.FormItem;
import com.smartgwt.client.widgets.form.fields.PickerIcon;
import com.smartgwt.client.widgets.form.fields.SelectItem;
import com.smartgwt.client.widgets.form.fields.TextAreaItem;
import com.smartgwt.client.widgets.form.fields.TextItem;
import com.smartgwt.client.widgets.form.fields.events.BlurEvent;
import com.smartgwt.client.widgets.form.fields.events.BlurHandler;
import com.smartgwt.client.widgets.form.fields.events.ChangeEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangeHandler;
import com.smartgwt.client.widgets.form.fields.events.ChangedEvent;
import com.smartgwt.client.widgets.form.fields.events.ChangedHandler;
import com.smartgwt.client.widgets.form.fields.events.ClickEvent;
import com.smartgwt.client.widgets.form.fields.events.ClickHandler;
import com.smartgwt.client.widgets.form.fields.events.FormItemClickHandler;
import com.smartgwt.client.widgets.form.fields.events.FormItemIconClickEvent;
import com.smartgwt.client.widgets.grid.ListGrid;
import com.smartgwt.client.widgets.grid.ListGridField;
import com.smartgwt.client.widgets.grid.ListGridRecord;
import com.smartgwt.client.widgets.grid.events.RecordClickEvent;
import com.smartgwt.client.widgets.grid.events.RecordClickHandler;
import com.smartgwt.client.widgets.layout.VLayout;
import com.smartgwt.client.widgets.tab.Tab;
import com.smartgwt.client.widgets.tab.TabSet;
import com.smartgwt.client.widgets.tab.events.TabSelectedEvent;
import com.smartgwt.client.widgets.tab.events.TabSelectedHandler;
import com.smartgwt.client.widgets.tree.TreeGrid;
import com.smartgwt.client.widgets.tree.TreeGridField;
import com.smartgwt.client.widgets.tree.TreeNode;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import yum.e3.client.SolutionFactory;
import yum.e3.client.generals.AppHandler;
import yum.e3.client.generals.rpc.RPCHandler;
import yum.e3.client.generals.rpc.RemoteDBAccess;
import yum.e3.client.generals.rpc.data.DBResponse;
import yum.e3.client.generals.rpc.data.SQLDMLBatch;
import yum.e3.client.generals.rpc.data.SQLQuery;
import yum.e3.client.generals.rpc.data.WebServiceData;
import yum.e3.client.generals.rpc.data.WebServiceRequest;
import yum.e3.client.generals.templates.core.SolutionHandler;
import yum.e3.client.generals.templates.ui.DynamicComboBoxItem;
import yum.e3.client.generals.ui.XMLTree;
import yum.e3.client.generals.utils.Alert;



/**
 *
 * @author richie
 */
public class SubmitAndDemand  extends VLayout
{
    final private TabSet moTopTabSet = new TabSet();  
    private Tab  moTabSubmit,moTabDemand,moTabCalendar;
    public ComboBoxItem loTypecomboBox [] = new ComboBoxItem[8] ;
    private ListGrid moListGridTaskDetail;
    public RPCHandler<DBResponse> moRPCHandler = null;
    private TaskTreeGrid moTaskGrid;
    public String [] msXMLRow,msStores,msRowControl,msScheduledValues;
    public DynamicComboBoxItem loComboList,loComboQueue,loComboTask;
    public int miRowsCC;
    public int msIndex;
    public TextItem loTxtLista,loTxtTarea,loTxtQueue;
    
    
    
    //public TextAreaItem tmp ;
    
    //public String msIndex;
    
    public static class Factory implements SolutionFactory {
        public Canvas create(SolutionHandler poSolutionHandler) {
            return new SubmitAndDemand(poSolutionHandler);
        }
    }
    public SubmitAndDemand(SolutionHandler poSolutionHander){
        buildLayout(poSolutionHander);
    }
    public void buildLayout(SolutionHandler poSolutionHandler){
        
        // Alert.show(Cookies.getCookie("IdTask") + Cookies.getCookie("TaskName"));
        
      
        //TabSet**
        moTopTabSet.setTabBarPosition(Side.TOP);  
        moTopTabSet.setWidth(950);  
        moTopTabSet.setHeight(600);  
        
        //*** Elementos de Detalle 
        /*final TextItem loTxtIdDetail = new TextItem("TxtIdDetail","IdDetalle");
        loTxtIdDetail.setWidth(50);
        loTxtIdDetail.setAttribute("readOnly", true);
        final TextItem loTxtNameDetail =  new TextItem("txtNameDetail","Nombre");*/
        //tmp = new TextAreaItem("txt");
        
        /*ButtonItem TmploBtnSaveDetail  = new ButtonItem("btnSaveDetail","Guardar");
        TmploBtnSaveDetail.addClickHandler(new ClickHandler() {
            public void onClick(ClickEvent event) {
                setDocument();
            }
        });*/
        //*** Elementos de Detalle //
        moTabSubmit = new Tab("Submiteo", "e3/ui/templates/edited.png");
        final DynamicForm loformS = new DynamicForm();  
        loformS.setIsGroup(true);  
        loformS.setGroupTitle("Submiteo");  
        loformS.setNumCols(10);
        loformS.setWidth(905);
        loformS.setHeight(500);
        
        /*final ButtonItem loDetailAceptbutton = new ButtonItem("loBtnAceptDetail", "Aceptar");  
        loDetailAceptbutton.setStartRow(false);  
        loDetailAceptbutton.addClickHandler(new ClickHandler() {
            public void onClick(ClickEvent event) {
              
            }
        }); */
        final CheckboxItem loCheckCalen = new CheckboxItem("chek","Calendarizar  Tarea");
        loCheckCalen.setStartRow(false);
        loCheckCalen.addChangedHandler(new ChangedHandler() {
            public void onChanged(ChangedEvent event) {
                
            }
        });
        final ButtonItem loBtnAcept =  new ButtonItem("BtnAcept","Aceptar");
        loBtnAcept.setStartRow(false);
        final  PickerIcon[] loPickerBtnIcon = new PickerIcon[4]; 
        final Window lowindowList = new Window();  
        final Window loWindowTask = new Window();
        loWindowTask.setHeight(400);
        loWindowTask.setWidth(400);
        loWindowTask.setLeft(200);
        loWindowTask.hide();
        loWindowTask.setTitle("Tarea");
        lowindowList.setTop(180);
        lowindowList.setLeft(260);
        lowindowList.setWidth(300);
        lowindowList.setHeight(300);
        lowindowList.setAutoSize(true);  
        lowindowList.setCanDragReposition(true);  
        lowindowList.setCanDragResize(true);
        lowindowList.addCloseClickHandler(new CloseClickHandler() {
                   public void onCloseClick(CloseClientEvent event) {
                       lowindowList.hide();
                       lowindowList.clear();
                   }
        });
        final Window lowindowQueue = new Window();  
        
        lowindowQueue.setTop(180);
        lowindowQueue.setLeft(260);
        lowindowQueue.setWidth(300);
        lowindowQueue.setHeight(300);
        lowindowQueue.setAutoSize(true);  
        lowindowQueue.setCanDragReposition(true);  
        lowindowQueue.setCanDragResize(true);
        lowindowQueue.addCloseClickHandler(new CloseClickHandler() {
                   public void onCloseClick(CloseClientEvent event) {
                       lowindowQueue.hide();
                   }
        });
       
        final DateItem loDateDetail = new DateItem("DetailTypeDate","Fecha");
        loDateDetail.addChangedHandler(new ChangedHandler() {
            public void onChanged(ChangedEvent event) {
                Date loDate =  loDateDetail.getValueAsDate();
                String[] lsaDate = SplitDate(loDate.toGMTString());
                String lsmont = String.valueOf(getMonth(lsaDate[1]));
                if (lsmont.length() < 2) { lsmont = "0"+ lsmont; }
                if (lsaDate[0].length() < 2) { lsaDate[0] = "0"+ lsaDate[0]; }
                moListGridTaskDetail.getSelectedRecord().setAttribute("valor_detalle",lsaDate[2].substring(2,4)+"-"+lsmont+"-"+lsaDate[0]);
                //moListGridTaskDetail.getSelectedRecord().setAttribute("valor_detalle",lsaDate[2]+lsaDate[1]+lsaDate[0]);
                moListGridTaskDetail.refreshFields();  
            }
        });
        final TextItem loTxtTextType =  new TextItem("DetailTypeText","Texto");
        loTxtTextType.addChangedHandler(new ChangedHandler() {
            public void onChanged(ChangedEvent event) {
                moListGridTaskDetail.getSelectedRecord().setAttribute("valor_detalle",loTxtTextType.getValueAsString());
                moListGridTaskDetail.refreshFields();
            }
        });
        final TextItem loTxtIntegerType =  new TextItem("DetailTypeInteger","Valor");          
        loTxtIntegerType.setKeyPressFilter("[0-9]"); 
        loTxtIntegerType.addChangedHandler(new ChangedHandler() {
            public void onChanged(ChangedEvent event) {
                moListGridTaskDetail.getSelectedRecord().setAttribute("valor_detalle",loTxtIntegerType.getValueAsString());
                moListGridTaskDetail.refreshFields();
            }
        });
        
        final DynamicForm loformSTaskDetail = new DynamicForm();  
        loformSTaskDetail.setIsGroup(true);  
        loformSTaskDetail.setGroupTitle("Detalle de Tarea:");  
        loformSTaskDetail.setNumCols(6);
        loformSTaskDetail.setWidth(300);
        loformSTaskDetail.setTop(300);
        loformSTaskDetail.setBottom(10);
        loformSTaskDetail.setLeft(10);
        loformSTaskDetail.setHeight(150);
        loformSTaskDetail.hide();
        
        loPickerBtnIcon[0] =  new PickerIcon(PickerIcon.SEARCH,new FormItemClickHandler() {
            public void onFormItemClick(FormItemIconClickEvent event) {
             
             final ListGrid loList = new ListGrid();
             loList.setTop(25);
             loList.setLeft(10);
             loList.setWidth(280);
             loList.setHeight(300);
             RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                loRDBA.executeDBRequest(new SQLQuery("SELECT it_snc_distribution_list_store.store_id as Store,it_grl_vw_cat_store.store_member as Store_Name\n" +
                        "FROM it_snc_distribution_list_store\n" +
                        "INNER JOIN it_grl_vw_cat_store\n" +
                        "ON it_snc_distribution_list_store.store_id=it_grl_vw_cat_store.store_id\n" +
                        "WHERE  it_snc_distribution_list_store.list_id = (SELECT list_id FROM it_snc_cat_distribution_list WHERE list_name ='"+ loComboList.getValueAsString()+"' ) ;","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {
                    @Override
                    public void onSuccessAction(DBResponse poResponse) {
                        //printLOG("N",psStore);

                        if(poResponse.getResult() == null)
                        {
                           Alert.show("Regreso Vacio");
                        }
                        else
                        {
                            populateGrid(poResponse, loList);
                        }

                       }
                        @Override
                        public void onFailureAction(String psMessage) {
                          /* manageEndOfCall();
                            Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");*/
                        }
                    });
                lowindowList.setTitle("Lista");
                lowindowList.addChild(loList);
                lowindowList.show();
            
             
            }
        });
        loPickerBtnIcon[1] =  new PickerIcon(PickerIcon.SEARCH,new FormItemClickHandler() {
            public void onFormItemClick(FormItemIconClickEvent event) {
                
                loWindowTask.show();
              
            }
        });
        loPickerBtnIcon[2] =  new PickerIcon(PickerIcon.SEARCH,new FormItemClickHandler() {
            public void onFormItemClick(FormItemIconClickEvent event) {
              
             
             final ListGrid loQueue = new ListGrid();
             loQueue.setTop(25);
             loQueue.setLeft(10);
             loQueue.setWidth(280);
             loQueue.setHeight(300);
             RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                loRDBA.executeDBRequest(new SQLQuery("","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {
                    @Override
                    public void onSuccessAction(DBResponse poResponse) {
                        //printLOG("N",psStore);

                        if(poResponse.getResult() == null)
                        {
                           Alert.show("Regreso Vacio");
                        }
                        else
                        {
                            populateGrid(poResponse, loQueue);
                        }

                       }
                        @Override
                        public void onFailureAction(String psMessage) {
                          /* manageEndOfCall();
                            Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");*/
                        }
                    });
                lowindowQueue.setTitle("Lista");
                lowindowQueue.addChild(loQueue);
                lowindowQueue.show();
            }
        });
        
        loComboList = new DynamicComboBoxItem();
        loComboList.setIcons(loPickerBtnIcon[0]);
        loComboList.setTitle("Lista de Distribuci�n");
        loComboList.setWidth(200);
        loComboList.setName("comboList");
        loComboList.populateFromDB(new SQLQuery("SELECT list_name FROM it_snc_cat_distribution_list WHERE user_id = '"+ AppHandler.getUserData().getUserId() +"';","jdbc/masterStoreDBConnectionPool"));
        loTypecomboBox[0] = new ComboBoxItem ();
        loComboList.setEditorType(loTypecomboBox[0]);
        loComboList.addChangedHandler(new ChangedHandler() {
            public void onChanged(ChangedEvent event) {
               RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                loRDBA.executeDBRequest(new SQLQuery("SELECT store_id FROM it_snc_distribution_list_store WHERE list_id = (SELECT list_id FROM it_snc_cat_distribution_list WHERE  list_name = '"+ loComboList.getValueAsString() +"');","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {
                    @Override
                    public void onSuccessAction(DBResponse poResponse) {
                        
                       if(poResponse.getResult() == null)
                       {
                          Alert.show("Regreso Vacio");
                       }
                       else
                       {
                            miRowsCC =  poResponse.getResult().length;
                            
                            if(miRowsCC == 0)
                            {
                                 //manageEndOfCall();
                                // Alert.show("No hay tiendas para esta lista de distribuci�n");
                                 miRowsCC = 0;
                                 msStores = null;
                            }
                            else
                            {
                               msStores = new String[miRowsCC];
                                //Alert.show("Stores :" + liRows);
                                for (int lii = 0; lii < msStores.length; lii++) 
                                {                                         //[Row][Column]  
                                   msStores[lii] =  poResponse.getResult()[lii][0];
                                   
                                }
                               
                                
                            } 
                           
                       }


                       }
                        @Override
                        public void onFailureAction(String psMessage) {
                          manageEndOfCall();
                            Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                        }
                });
            }
        });
        
        
        loWindowTask.addCloseClickHandler(new CloseClickHandler() {
            public void onCloseClick(CloseClientEvent event) {
                loWindowTask.hide();
             }
        });
        
        loComboTask = new DynamicComboBoxItem();
        loComboTask.setIcons(loPickerBtnIcon[1]);
        loComboTask.setTitle("Tarea");
        loComboTask.setWidth(200);
        loComboTask.setName("comboTask");
        loComboTask.populateFromDB(new SQLQuery("SELECT task_name FROM it_snc_cat_task WHERE user_id = '"+ AppHandler.getUserData().getUserId() +"';","jdbc/masterStoreDBConnectionPool"));
        loTypecomboBox[1] = new ComboBoxItem ();
        loComboTask.setEditorType(loTypecomboBox[1]);
        loComboTask.addChangedHandler(new ChangedHandler() {
            public void onChanged(ChangedEvent event) {
                
                moTaskGrid =  new TaskTreeGrid("Tarea",new SQLQuery("select ('<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><tree_struct></tree_struct>') as xml_data ","jdbc/masterStoreDBConnectionPool"));
                moTaskGrid.setNodeIcon("e3/ui/sync/pointer.png");
                moTaskGrid.setHeight(350);
                moTaskGrid.setWidth(380);
                moTaskGrid.setTop(30);
                moTaskGrid.setLeft(5);   
                loWindowTask.addChild(moTaskGrid);
                RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                loRDBA.executeDBRequest(new SQLQuery("SELECT xml_data FROM it_snc_cat_task WHERE task_id = (SELECT task_id FROM it_snc_cat_task  WHERE task_name = '"+ loComboTask.getValueAsString() +"');","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() 
                {
                    @Override
                    public void onSuccessAction(DBResponse poResponse) 
                    {
                        //printLOG("N",psStore);
                           
                        if(poResponse.getResult().length == 0)
                        {
                          //Alert.show("Regreso Vacio");
                           moTaskGrid.populateFromString("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><tree_struct></tree_struct>");
                           
                        }
                        else
                        {
                            
                           //Alert.show("tiene XML");
                           moTaskGrid.refreshData(poResponse.getResult()[0][0]);
                           moTaskGrid.setNodeIcon("e3/ui/sync/pointer.png");
                           moTaskGrid.setHeight(350);
                           moTaskGrid.setWidth(380);
                           moTaskGrid.setTop(30);
                           moTaskGrid.setLeft(5);
                           moTaskGrid.getData().openAll();
                           loformSTaskDetail.show();
                           RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                           loRDBA.executeDBRequest(new SQLQuery("SELECT detail_id as id_detalle,detail_name as detalle,type_detail as tipo_detalle,'' as valor_detalle FROM it_snc_cat_task_detail WHERE task_id = (SELECT task_id FROM it_snc_cat_task WHERE task_name = '"+ loComboTask.getValueAsString()+"');","jdbc/masterStoreDBConnectionPool"),new RPCHandler<DBResponse>() 
                           {
                               @Override
                               public void onSuccessAction(DBResponse poValue) {
                                   
                                   if (poValue.getResult().length == 0) 
                                   {
                                    loDateDetail.hide();
                                    loTxtTextType.hide();
                                    loTxtIntegerType.hide();
                                    populateGrid(poValue, moListGridTaskDetail);
                                    moListGridTaskDetail.hideField("id_detalle");
                                    moListGridTaskDetail.hideField("tipo_detalle");
                                    
                                   } 
                                   else
                                   {
                                    populateGrid(poValue, moListGridTaskDetail);
                                    moListGridTaskDetail.hideField("id_detalle");
                                    moListGridTaskDetail.hideField("tipo_detalle");
                                   }
                                   
                               }

                               @Override
                               public void onFailureAction(String psMessage) {
                                 
                              }
                           });
                        }

                    }
                    @Override
                    public void onFailureAction(String psMessage) 
                    {
                           
                          //Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                    }
                });
                
            }
        });
        loComboQueue = new DynamicComboBoxItem();
        loComboQueue.setIcons(loPickerBtnIcon[2]);
        loComboQueue.setTitle("Colas");
        loComboQueue.setWidth(200);
        loComboQueue.setName("comboCola");
        loComboQueue.populateFromDB(new SQLQuery("SELECT queue_desc FROM it_snc_cat_task_queue where user_id = '"+AppHandler.getUserData().getUserId()+"';","jdbc/masterStoreDBConnectionPool"));
        loTypecomboBox[2] = new ComboBoxItem ();
        loComboQueue.setEditorType(loTypecomboBox[2]);

        loBtnAcept.addClickHandler(new ClickHandler() {
            public void onClick(ClickEvent event) {
               
                
                if(loComboTask.getValue() == null || loComboList.getValue() == null || loComboQueue.getValue() == null)
                {
                    Alert.show("Por favor seleccione una lista de distribuci�n, tarea y cola.");
                }
                else
                {
                    if(loCheckCalen.getValueAsBoolean()==true)
                    {
                     //Alert.show("Ser� Calendarizado");
                     moTopTabSet.selectTab(moTabCalendar);
                     loTxtTarea.setValue(loComboTask.getValueAsString());
                     loTxtLista.setValue(loComboList.getValueAsString());
                     loTxtQueue.setValue(loComboQueue.getValueAsString());
                     loComboQueue.setValue("");
                     loComboList.setValue("");
                     loComboTask.setValue("");
                     loCheckCalen.setValue(false);
                     moListGridTaskDetail.setData(new ListGridRecord[]{});
                     
                     
                    }
                    else
                    {
                     //Alert.show("Tarea Submit ");
                       String lsOptinId [] = getValuesFromTaskTree();
              
                       for(int jii = 0;jii < msStores.length;jii++)
                       {
                        getIndexRowControl(msStores[jii],loComboQueue.getValueAsString(),loComboTask.getValueAsString(),lsOptinId);

                       }
                    }
                    
                    
                    
                } 
           
            }
        });
         
        moListGridTaskDetail = new ListGrid();  
        moListGridTaskDetail.setWidth(200);  
        moListGridTaskDetail.setHeight(100);
        moListGridTaskDetail.setTop(35);
        moListGridTaskDetail.setLeft(20);
        moListGridTaskDetail.setShowAllRecords(true);  
        moListGridTaskDetail.setSelectionType(SelectionStyle.SINGLE);
        moListGridTaskDetail.setData(moListGridTaskDetail.getRecords());
        loformSTaskDetail.setItems(loDateDetail,loTxtTextType,loTxtIntegerType);
        loDateDetail.hide();
        loTxtTextType.hide();
        loTxtIntegerType.hide();
        //loDetailAceptbutton.hide();
        moListGridTaskDetail.addRecordClickHandler(new RecordClickHandler() {
            public void onRecordClick( RecordClickEvent poEvent) {
                 String lsStringType [] = new String[3];
                 
                 lsStringType[0] =  poEvent.getRecord().getAttribute("id_detalle");
                 lsStringType[1] =  poEvent.getRecord().getAttribute("detalle");
                 lsStringType[2] =  poEvent.getRecord().getAttribute("tipo_detalle");
                 loDateDetail.setValue("");
                 loTxtTextType.setValue("");
                 loTxtIntegerType.setValue("");
                 
                 if(lsStringType[2].equals("date"))
                 {
                    loDateDetail.show();
                    // loformSTaskDetail.setItems(loDateDetail);
                    loTxtTextType.hide();
                    loTxtIntegerType.hide();
                    //loDetailAceptbutton.show();
                    
                 }
                 else if(lsStringType[2].equals("text"))
                 {
                    //  loformSTaskDetail.setItems(loTxtTextType);
                     loTxtTextType.show();
                     loDateDetail.hide();
                     loTxtIntegerType.hide();
                     //loDetailAceptbutton.show(); 
                      
                 }
                 else if(lsStringType[2].equals("integer"))
                 {
                  //   loformSTaskDetail.setItems(loTxtIntegerType);
                     loTxtIntegerType.show();
                     loDateDetail.hide();
                     loTxtTextType.hide();
                     //loDetailAceptbutton.show();
                      
                   
                 }else{}
                 
                 
            }
        });
       
        
        
        
        
        
        loformSTaskDetail.addChild(moListGridTaskDetail);
        loformS.setItems(loComboList,loComboTask,loComboQueue,loBtnAcept,loCheckCalen);
        loformS.addChild(loformSTaskDetail);
        loformS.addChild(loWindowTask);
        //loformS.addChild(loBtnSendCalen);
        //loformS.addChild(loBtnAcept);
        
        moTabSubmit.setPane(loformS);
        
        
        
        moTabDemand = new Tab("Demanda", "e3/ui/templates/edited.png");
        final DynamicForm loformD = new DynamicForm();
        loformD.setIsGroup(true);  
        loformD.setGroupTitle("Demanda");  
        loformD.setNumCols(6);
        loformD.setWidth(650);
        loformD.setHeight(200);
        loformD.setCanSubmit(true);
        loformD.setEncoding(Encoding.NORMAL);
        loformD.setMethod(FormMethod.POST);
        loformD.setAction(GWT.getHostPageBaseURL()+"StoreSyncServlet");
        
        final DynamicComboBoxItem loComboListDisDemand = new DynamicComboBoxItem();
        loComboListDisDemand.setTitle("Lista de Distribuci�n");
        loComboListDisDemand.setWidth(200);
        loComboListDisDemand.setName("comboDemandList");
        loComboListDisDemand.populateFromDB(new SQLQuery("SELECT list_name FROM it_snc_cat_distribution_list WHERE user_id = '"+ AppHandler.getUserData().getUserId() +"';","jdbc/masterStoreDBConnectionPool"));
        loTypecomboBox[3] = new ComboBoxItem ();
        loComboListDisDemand.setEditorType(loTypecomboBox[3]);
        final DynamicComboBoxItem loComboQueueDemand = new DynamicComboBoxItem();
        loComboQueueDemand.setTitle("Colas");
        loComboQueueDemand.setWidth(200);
        loComboQueueDemand.setName("comboDemandCola");
        loComboQueueDemand.populateFromDB(new SQLQuery("SELECT queue_desc FROM it_snc_cat_task_queue where user_id = '"+AppHandler.getUserData().getUserId()+"';","jdbc/masterStoreDBConnectionPool"));
        loTypecomboBox[4] = new ComboBoxItem ();
        loComboQueueDemand.setEditorType(loTypecomboBox[4]);
        
        ButtonItem loBtnAceptDemand =  new ButtonItem("BtnAcept","Aceptar");
        loBtnAceptDemand.setStartRow(false);
        loBtnAceptDemand.addClickHandler(new ClickHandler() {
            public void onClick(ClickEvent event) {
                
                if (loComboListDisDemand.getValueAsString() == null || loComboQueueDemand.getValueAsString() == null  ) 
                {
                     Alert.show("Por favor seleccione una lista de distribuci�n y cola.");
                } 
                else 
                {
                    //loformD.submit();
                    RemoteDBAccess  loRDBA = null;
                    loRDBA = new RemoteDBAccess(); 
                    LinkedHashMap<String,String> loParams = new LinkedHashMap<String,String>();
                    loParams.put(loComboListDisDemand.getName(),loComboListDisDemand.getValueAsString());
                    loParams.put(loComboQueueDemand.getName(),loComboQueueDemand.getValueAsString());
                    loParams.put("SubmitType","Manual");
                    loRDBA.WebService(new WebServiceRequest(GWT.getHostPageBaseURL()+"StoreSyncServlet", loParams,"POST", ""),new RPCHandler<WebServiceData>() {

                        @Override
                        public void onSuccessAction(WebServiceData poValue) {
                            Alert.show("Porceso de Submiteo: " + poValue.getData()); //To change body of generated methods, choose Tools | Templates.
                            
                        }

                        @Override
                        public void onFailureAction(String psMessage) {
                            throw new UnsupportedOperationException(" Ha fallado la petici�n al servidor "); //To change body of generated methods, choose Tools | Templates.
                        }
                    });
                    loComboListDisDemand.setValue("");
                    loComboQueueDemand.setValue("");
                }
              
            }
        });
       
        loformD.setItems(loComboListDisDemand,loComboQueueDemand,loBtnAceptDemand);
        moTabDemand.setPane(loformD);
        
        moTabCalendar =  new Tab("Calendarizado","e3/ui/schedule/clock.png");
        
        final DynamicForm loformC = new DynamicForm();  
        loformC.setIsGroup(true);  
        loformC.setGroupTitle("Calendarizado");  
        loformC.setNumCols(7);
        loformC.setWidth(900);
        loformC.setHeight(500);
      
       
        final DynamicComboBoxItem loComboDay = new DynamicComboBoxItem();
        loComboDay.setTitle("D&iacutea");
        loComboDay.setWidth(50);
        loComboDay.setName("comboDay");
        loComboDay.populateFromDB(new SQLQuery("SELECT day_name FROM it_snc_cat_scheduled_days;","jdbc/masterStoreDBConnectionPool"));
        loTypecomboBox[5] = new ComboBoxItem ();
        loComboDay.setEditorType(loTypecomboBox[5]);
        
        /*LinkedHashMap<String ,String > loMapHour = new LinkedHashMap<String, String>();
        for (int lii = 0; lii < 24; lii++) {
            
            if(String.valueOf(lii).length() < 2){loMapHour.put("H"+String.valueOf(lii),"0"+String.valueOf(lii));}else{loMapHour.put("H"+String.valueOf(lii),String.valueOf(lii));}
            
        } */
        
        final DynamicComboBoxItem loComboHour = new DynamicComboBoxItem();
        loComboHour.setTitle("Hora");
        loComboHour.setWidth(50);
        loComboHour.setName("comboHours");
        loComboHour.populateFromDB(new SQLQuery("SELECT * FROM it_snc_cat_scheduled_hours;","jdbc/masterStoreDBConnectionPool"));
        loTypecomboBox[6] = new ComboBoxItem ();
        loComboHour.setEditorType(loTypecomboBox[6]);
        /*LinkedHashMap<String ,String > loMapMinutes = new LinkedHashMap<String, String>();
        int jii =0;
        while (jii < 60)
        {
            if(String.valueOf(jii).length() < 2){loMapMinutes.put("M"+String.valueOf(jii),"0"+String.valueOf(jii));}else{loMapMinutes.put("M"+String.valueOf(jii),String.valueOf(jii));}
            jii = jii +5;
           
           
        }*/
        final DynamicComboBoxItem loComboMinutes = new DynamicComboBoxItem();
        loComboMinutes.setTitle("Minutos");
        loComboMinutes.setWidth(50);
        loComboMinutes.setName("comboMinutes");
        loComboMinutes.populateFromDB(new SQLQuery("SELECT * FROM it_snc_cat_scheduled_minutes;","jdbc/masterStoreDBConnectionPool"));
        loTypecomboBox[7] = new ComboBoxItem ();
        loComboMinutes.setEditorType(loTypecomboBox[7]);
        
        final ButtonItem loBtnAceptCalendar = new ButtonItem("btnAceptCalen","Aceptar");
        loBtnAceptCalendar.setStartRow(false);
        loBtnAceptCalendar.addClickHandler(new ClickHandler() {
            public void onClick(ClickEvent event) {
                
               
                    if (loTxtLista.getValueAsString() == null || loTxtTarea.getValueAsString() == null || loTxtQueue.getValueAsString() == null || loComboDay.getValue() == null || loComboHour.getValue() == null || loComboMinutes.getValue() == null)
                    {
                          //Alert.show("Por favor seleccione una lista de distribuci&oacuten,tarea,cola y calendarice su operaci&oacuten.");  
                          Alert.show(loComboMinutes.getFieldName());
                    } 
                    else 
                    {
                       String lsOptinId [] = getValuesFromTaskTree();

                        for(int jii = 0;jii < msStores.length;jii++)
                        {
                            //getIndexRowControl(msStores[jii],loComboQueue.getValueAsString(),loComboTask.getValueAsString(),lsOptinId);
                               AssignSchedule(msStores[jii],loTxtQueue.getValueAsString(), loTxtTarea.getValueAsString(), lsOptinId,loComboDay.getDisplayValue(),loComboHour.getDisplayValue(),loComboMinutes.getDisplayValue(),loTxtLista.getValueAsString());

                        }
                        
                    }
                }
        });
        loTxtLista =  new TextItem("txtList"," ");
        loTxtLista.setTitle("Lista");
        loTxtLista.setAttribute("disabled","true");
        loTxtTarea =  new TextItem("txtTarea"," ");
        loTxtTarea.setTitle("Tarea");
        loTxtTarea.setAttribute("disabled","true");
        loTxtQueue =  new TextItem("txtQueue"," ");
        loTxtQueue.setTitle("Cola");
        loTxtQueue.setAttribute("disabled","true");
        final IButton loBtnviewDetail = new IButton("");
        loBtnviewDetail.setIcon("e3/ui/templates/find.png");
        loBtnviewDetail.setWidth("25");
        loBtnviewDetail.setLeft(760);
        loBtnviewDetail.setTop(8);
        loBtnviewDetail.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
            public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
                moTopTabSet.selectTab(moTabSubmit);
                loComboList.setValue(loTxtLista.getValue());
                loComboQueue.setValue(loTxtQueue.getValue());
                loComboTask.setValue(loTxtTarea.getValue());
                RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                loRDBA.executeDBRequest(new SQLQuery("SELECT detail_id as id_detalle,detail_name as detalle,type_detail as tipo_detalle,'' as valor_detalle FROM it_snc_cat_task_detail WHERE task_id = (SELECT task_id FROM it_snc_cat_task WHERE task_name = '"+ loComboTask.getValueAsString()+"');","jdbc/masterStoreDBConnectionPool"),new RPCHandler<DBResponse>() 
                {
                        @Override
                        public void onSuccessAction(DBResponse poValue) {

                            populateGrid(poValue, moListGridTaskDetail);
                            moListGridTaskDetail.hideField("id_detalle");
                            moListGridTaskDetail.hideField("tipo_detalle");
                            RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                            loRDBA.executeDBRequest(new SQLQuery("SELECT xml_data FROM it_snc_cat_task WHERE task_id = (SELECT task_id FROM it_snc_cat_task  WHERE task_name = '"+ loTxtTarea.getValueAsString() +"');","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() 
                            {
                                @Override
                                public void onSuccessAction(DBResponse poResponse) 
                                {
                                    moTaskGrid.refreshData(poResponse.getResult()[0][0]);
                                    moTaskGrid.getData().openAll();
                                }
                                @Override
                                public void onFailureAction(String psMessage)
                                {

                                }
                            });

                        }

                        @Override
                        public void onFailureAction(String psMessage) {

                       }
                });
                loCheckCalen.setValue(true);
            }
        });
        final IButton loBtnDeleted = new IButton("");
        loBtnDeleted.setIcon("e3/ui/templates/deleted.png");
        loBtnDeleted.setWidth("25");
        loBtnDeleted.setLeft(785);
        loBtnDeleted.setTop(8);
        loBtnDeleted.addClickHandler(new com.smartgwt.client.widgets.events.ClickHandler() {
            public void onClick(com.smartgwt.client.widgets.events.ClickEvent event) {
                loTxtLista.setValue("");
                loTxtQueue.setValue("");
                loTxtTarea.setValue("");
                loComboDay.clearValue();
                loComboHour.clearValue();
                loComboMinutes.clearValue();
            }
        });
        loformC.setItems(loTxtLista,loTxtTarea,loTxtQueue,loComboDay,loComboHour,loComboMinutes,loBtnAceptCalendar);
        loformC.addChild(loBtnviewDetail);
        loformC.addChild(loBtnDeleted);
        moTabCalendar.setPane(loformC);
        
        
        
        
        
        
        
        
        
        
        
        //TabSet**
        
        moTopTabSet.addTab(moTabSubmit);  
        moTopTabSet.addTab(moTabDemand); 
        moTopTabSet.addTab(moTabCalendar);
        
        //*** VLayout ****//
        setMembersMargin(15);  
        addMember(moTopTabSet);    
        setHeight("*"); 
        
    }
    public void populateGrid(DBResponse poResponse,ListGrid loLisGrid){
        ListGridField laQueryFields[] = null;
        laQueryFields = poResponse.getFieldsAsLGF();
        loLisGrid.setFields(laQueryFields);
        loLisGrid.setData(getGridData(poResponse,laQueryFields));
        //mbHasSeenPreview=true;
    }
    public ListGridRecord[] getGridData(DBResponse poResponse,ListGridField[] paGridFields) {
        String [][] laRawData = poResponse.getResult();
        ListGridRecord[] laGridData  = new ListGridRecord[laRawData.length];
        
        for (int liRecIndex = 0; liRecIndex <  laRawData.length; liRecIndex++) {
            laGridData[liRecIndex] = new ListGridRecord();
            for (int liFieldIndex = 0; liFieldIndex < laRawData[0].length; liFieldIndex++) {
                String lsFieldName = paGridFields[liFieldIndex].getName();
                laGridData[liRecIndex].setAttribute(lsFieldName, laRawData[liRecIndex][liFieldIndex]);
            }
        }
        return laGridData;
    }
    
    public class TaskTreeGrid extends XMLTree{
       public TaskTreeGrid(String psTitle, SQLQuery poSQLQuery) {
            super(psTitle,poSQLQuery, "", "");
       }

        @Override
        protected  void defineAttributes() {
            moAttributes.add("option_id");
            moAttributes.add("parent_id");
            moAttributes.add("level_id");
            moAttributes.add("tipo");
            moAttributes.add("fuente");
            moAttributes.add("destino");
            moAttributes.add("eliminar");
            
            
        }

        @Override
        protected void setCustomPropertiesBeforeRender() {
            //setWrapCells(true);
            setCellHeight(28);
            
            TreeGridField loType = new TreeGridField("tipo",30);
            loType.setType(ListGridFieldType.IMAGE);
            loType.setImageURLPrefix("e3/ui/sync/");
            loType.setImageURLSuffix(".png");
            TreeGridField loSrc = new TreeGridField("fuente", 500);
            loSrc.setEditorType(new TextAreaItem());
            loSrc.setCanEdit(true);
            TreeGridField loDst = new TreeGridField("destino", 300);
            loDst.setCanEdit(true);
            TreeGridField loDel = new TreeGridField("eliminar",50);
            loDel.setType(ListGridFieldType.IMAGE);
            loDel.setImageURLPrefix("e3/ui/templates/");
            loDel.setImageURLSuffix(".png");
            
            
            
             setFields(moHeaderField,loType,loSrc,loDst,loDel);
        }
       
    
        @Override
        protected void onAfterPopulateAction(){
            setAllAsFolder(getData().getChildren(getData().getRoot()));
            getData().openAll();
        }

        private void setAllAsFolder(TreeNode poTreeNodes[]){
            for (int li=0;li<poTreeNodes.length;li++){
                poTreeNodes[li].setIsFolder(true);
                //poTreeNodes[li].setCanDrag(false);
            }
        }

        @Override
        public void populateFromDB(SQLQuery poSQLQuery) {
            setSQLQuery(poSQLQuery);
            RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
            moRPCHandler = new RPCHandler<DBResponse>() {
                @Override
                public void onSuccessAction(DBResponse poResponse) {
                    moRPCHandler.setCanShowWaitWindow(false);
                    refreshData(poResponse.getResultAsString(0));
                    onAfterPopulateAction();
                }
                @Override
                public void onFailureAction(String psMessage) {
                    Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                }
            };
            loRDBA.setCanShowWaitWindow(false);
            moRPCHandler.setCanShowWaitWindow(false);
            loRDBA.executeDBRequest(poSQLQuery, moRPCHandler);
        }

    }
    public String[] getValuesFromTaskTree ()
    {
           Document moDOMData;
           
           Date lorightNow= new Date();
           String  lsDate = String.valueOf(lorightNow.getTime());
           
           
           /*for (int ii = 0; ii < moListGridTaskDetail.getRecords().length; ii++) 
           {
               //Remplazar Valores de detalle
               lsXMLDATAtmp =  lsXMLDATAtmp.replace(moListGridTaskDetail.getRecord(ii).getAttribute("detalle"),moListGridTaskDetail.getRecord(ii).getAttribute("valor_detalle"));
           
           } */ 
           
           moDOMData = XMLParser.parse(ToAssignDetailValues());
           NodeList loNodeList = moDOMData.getElementsByTagName("tree_option");
       
           String loOptionId[] =  new String[loNodeList.getLength()];
           msXMLRow = new String[loNodeList.getLength()];
           for (int lii = 0; lii < loNodeList.getLength(); lii++) 
           {
                   
                Element loElement = (Element)loNodeList.item(lii);
                loElement.setAttribute("option_id",loElement.getAttribute("option_id")+"."+lsDate);
                if (!loElement.getAttribute("parent_id").equals("")) {loElement.setAttribute("parent_id",loElement.getAttribute("parent_id")+"."+lsDate);}
                msXMLRow[lii] = loElement.toString();
                loOptionId[lii] = loElement.getAttribute("option_id");
                 
           }
           return loOptionId;
    }
    
    public void getIndexRowControl(final String lsStore,final String lsQueue,final String lsTaskName,final String lsOptionId[])
    {
        
         RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                loRDBA.executeDBRequest(new SQLQuery("SELECT row_control FROM it_snc_execute_submit WHERE store_id  = "+ lsStore +"  ORDER BY row_control DESC LIMIT 1;","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {
                    @Override
                    public void onSuccessAction(DBResponse poResponse) {
                        //printLOG("N",psStore);

                            if(poResponse.getResultAsString() == null)
                            {
                               Alert.show("esta vacio");
                               msIndex = 0;
                            }
                            else
                            {
                                msIndex = Integer.parseInt(poResponse.getResultAsString());   
                                //Alert.show(String.valueOf(msIndex));
                                 for (int lii = 0; lii < msXMLRow.length; lii++) 
                                        {
                                            RemoteDBAccess loRequest = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                                            loRequest.executeDBRequest(new SQLDMLBatch("INSERT INTO it_snc_execute_submit VALUES ("+ lsStore +",(SELECT queue_id FROM it_snc_cat_task_queue WHERE queue_desc = '"+ lsQueue +"'),"+ (msIndex+1) +",'"+ msXMLRow[lii]+ "','0',(SELECT task_id FROM it_snc_cat_task WHERE task_name = '"+ lsTaskName +"'),"+(lii+1)+",'"+ lsOptionId[lii] +"');", "jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {   
                                                @Override
                                                public void onSuccessAction(DBResponse poValue) {
                                                   Alert.show("Exito al insertar");

                                                }   
                                                @Override
                                                public void onFailureAction(String psMessage) {
                                                    manageEndOfCall();
                                                    Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                                                }    
                                            }); 
                                          msIndex ++;
                                        }
                            }


                       }
                        @Override
                        public void onFailureAction(String psMessage) {
                            manageEndOfCall();
                            msIndex = 0;
                           //Alert.show("sin valor " +  String.valueOf(msIndex));
                              for (int lii = 0; lii < msXMLRow.length; lii++) 
                                        {
                                            RemoteDBAccess loRequest = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                                            loRequest.executeDBRequest(new SQLDMLBatch("INSERT INTO it_snc_execute_submit VALUES ("+ lsStore +",(SELECT queue_id FROM it_snc_cat_task_queue WHERE queue_desc = '"+ lsQueue +"'),"+ (lii+1) +",'"+ msXMLRow[lii]+ "','0',(SELECT task_id FROM it_snc_cat_task WHERE task_name = '"+ lsTaskName +"'),"+(lii+1)+",'"+ lsOptionId[lii] +"');", "jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {   
                                                @Override
                                                public void onSuccessAction(DBResponse poValue) {
                                                   Alert.show("Exito al insertar");

                                                }   
                                                @Override
                                                public void onFailureAction(String psMessage) {
                                                    manageEndOfCall();
                                                    Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                                                }    
                                            }); 

                                        }
                        }
                });
               
    }
    public void AssignSchedule(final String lsStore,final String lsQueue,final String lsTaskName,final String lsOptionId[],final String lsDay,final String lsHour,final String lsMinute,final String lsDistribListName)
    {
        
         RemoteDBAccess loRDBA = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                loRDBA.executeDBRequest(new SQLQuery("SELECT row_control FROM it_snc_execute_scheduled_submit WHERE store_id  = "+ lsStore +"  ORDER BY row_control DESC LIMIT 1;","jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {
                    @Override
                    public void onSuccessAction(DBResponse poResponse) {
                        //printLOG("N",psStore);

                            if(poResponse.getResultAsString() == null)
                            {
                               Alert.show("esta vacio");
                               msIndex = 0;
                            }
                            else
                            {
                                msIndex = Integer.parseInt(poResponse.getResultAsString());   
                                //Alert.show(String.valueOf(msIndex));
                                 for (int lii = 0; lii < msXMLRow.length; lii++) 
                                        {
                                            RemoteDBAccess loRequest = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                                            loRequest.executeDBRequest(new SQLDMLBatch("INSERT INTO it_snc_execute_scheduled_submit VALUES ("+ lsStore +",(SELECT queue_id FROM it_snc_cat_task_queue WHERE queue_desc = '"+ lsQueue +"'),"+ (msIndex+1) +",'"+ msXMLRow[lii]+ "','0',(SELECT task_id FROM it_snc_cat_task WHERE task_name = '"+ lsTaskName +"'),"+(lii+1)+",'"+ lsOptionId[lii] +"',(SELECT id_day FROM it_snc_cat_scheduled_days WHERE day_name = '"+ lsDay +"'),'"+ lsHour+"','"+lsMinute+"',(SELECT list_id FROM it_snc_cat_distribution_list WHERE list_name = '"+ lsDistribListName +"'));", "jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {   
                                                @Override
                                                public void onSuccessAction(DBResponse poValue) {
                                                   Alert.show("Exito al insertar");

                                                }   
                                                @Override
                                                public void onFailureAction(String psMessage) {
                                                    manageEndOfCall();
                                                    Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                                                }    
                                            }); 
                                          msIndex ++;
                                        }
                            }


                       }
                        @Override
                        public void onFailureAction(String psMessage) {
                            manageEndOfCall();
                            msIndex = 0;
                           //Alert.show("sin valor " +  String.valueOf(msIndex));
                              for (int lii = 0; lii < msXMLRow.length; lii++) 
                                        {
                                            RemoteDBAccess loRequest = new RemoteDBAccess("jdbc/masterStoreDBConnectionPool");
                                            loRequest.executeDBRequest(new SQLDMLBatch("INSERT INTO it_snc_execute_scheduled_submit VALUES ("+ lsStore +",(SELECT queue_id FROM it_snc_cat_task_queue WHERE queue_desc = '"+ lsQueue +"'),"+ (lii+1) +",'"+ msXMLRow[lii]+ "','0',(SELECT task_id FROM it_snc_cat_task WHERE task_name = '"+ lsTaskName +"'),"+(lii+1)+",'"+ lsOptionId[lii] +"',(SELECT id_day FROM it_snc_cat_scheduled_days WHERE day_name = '"+ lsDay +"'),'"+ lsHour+"','"+lsMinute+"',(SELECT list_id FROM it_snc_cat_distribution_list WHERE list_name = '"+ lsDistribListName +"'));", "jdbc/masterStoreDBConnectionPool"), new RPCHandler<DBResponse>() {   
                                                @Override
                                                public void onSuccessAction(DBResponse poValue) {
                                                   Alert.show("Exito al insertar");

                                                }   
                                                @Override
                                                public void onFailureAction(String psMessage) {
                                                    manageEndOfCall();
                                                    Alert.show("Ha ocurrido un error al solicitar informaci�n al servidor. ");
                                                }    
                                            }); 

                                        }
                        }
                });
               
    }
    public String ToAssignDetailValues()
    {
        String  lsXMLDATAtmp = moTaskGrid.getXMLData();
        if ( moListGridTaskDetail.getRecords().length == 0) 
        {
            return lsXMLDATAtmp;
        }
        else
        {
            for (int lii = 0; lii < moListGridTaskDetail.getRecords().length; lii++) 
            {
                
               /* if(moListGridTaskDetail.getRecord(lii).getAttribute("detalle").contains("$Y$M$D"))
                {
                    
                    String[] loDateTmp = SplitDate(moListGridTaskDetail.getRecord(lii).getAttribute("valor_detalle"));
                    lsXMLDATAtmp =  lsXMLDATAtmp.replace("$D",loDateTmp[0]);
                    lsXMLDATAtmp =  lsXMLDATAtmp.replace("$M",loDateTmp[1]);
                    lsXMLDATAtmp =  lsXMLDATAtmp.replace("$Y",loDateTmp[2]);
    
                }
                else
                {*/
                    
                lsXMLDATAtmp =  lsXMLDATAtmp.replace(moListGridTaskDetail.getRecord(lii).getAttribute("detalle"),moListGridTaskDetail.getRecord(lii).getAttribute("valor_detalle"));

                //}
            }
            
            return lsXMLDATAtmp;
        }
     
     
    }
    public String[] SplitDate(String loDate)
    {
        
        String [] loArrayDate = loDate.split(" ");
        
        return loArrayDate;
    }
    public int getMonth(String lsMonthWord)
    {
        String [] lsMonthArray = new String[]{"Jan","Feb","Mar",
                                              "Apr","May","Jun",
                                              "Jul","Aug","Sep",
                                              "Oct","Nov","Dec"};
        int lsMonthTmp = 0;
        int lii=0;
        while (lii < lsMonthArray.length) 
        {            
            if (lsMonthArray[lii].equals(lsMonthWord)) 
            {
                //System.out.println("es igual"+lsMonthArray[i] + " -- " + i);
                lsMonthTmp = lii + 1;
                //System.out.println("Num mes: "+lsMonthTmp);
               
            }
            //System.out.println(lsMonthArray[i] + " -- " + i);
            lii++;
        }
        return lsMonthTmp;
    }
    
   /* public void setDocument()
    {
        
        Document moDOMData;
        try
        {   
           moDOMData = XMLParser.parse(moTaskGrid.getXMLData());
           NodeList loNodeList = moDOMData.getElementsByTagName("tree_option");
          
           String t = "";
           msXMLRow = new String[loNodeList.getLength()];
            for (int i = 0; i < loNodeList.getLength(); i++) 
            {
                 Element loElement = (Element)loNodeList.item(i);
                 msXMLRow[i] = loElement.toString();
                 t = t + msXMLRow[i];
            }
            
          
            //tmp.setValue(t);
        } 
        catch(Exception poException) 
        {
            ExceptionHandler.addException(poException, "<br><br>");
            Alert.show(poException.toString());
        }
    }   */
    
    
    
}
